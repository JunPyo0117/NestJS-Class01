# Part 21. Custom Decorator

## 목차
1. [Custom Decorator 이론](#1-custom-decorator-이론)
2. [User Custom Param Decorator 생성하기](#2-user-custom-param-decorator-생성하기)
3. [Query Runner Custom Param Decorator 생성하기](#3-query-runner-custom-param-decorator-생성하기)
   - [왜 QueryRunner 데코레이터가 필요한가?](#31-왜-queryrunner-데코레이터가-필요한가)

---

## 1. Custom Decorator 이론

### 1.1 Decorator란?

**Decorator(데코레이터)**는 클래스, 메서드, 프로퍼티, 파라미터 등에 메타데이터를 추가하거나 동작을 변경하는 기능입니다.

#### NestJS의 내장 데코레이터

NestJS는 많은 내장 데코레이터를 제공합니다:

- `@Controller()`: 컨트롤러 클래스
- `@Get()`, `@Post()`, `@Patch()`, `@Delete()`: HTTP 메서드
- `@Body()`, `@Param()`, `@Query()`: 요청 데이터 추출
- `@Injectable()`: 의존성 주입 가능한 클래스

### 1.2 Custom Decorator의 필요성

#### 문제 상황

1. **반복적인 코드**: 여러 컨트롤러에서 동일한 로직 반복
2. **가독성 저하**: `req.user.sub`, `req.queryRunner` 같은 반복적인 접근
3. **타입 안정성**: Request 객체에서 직접 추출 시 타입 체크 어려움

#### 해결책: Custom Decorator

커스텀 데코레이터를 만들어서:
- 반복 코드 제거
- 가독성 향상
- 타입 안정성 확보
- 재사용성 향상

### 1.3 Param Decorator 생성

NestJS는 `createParamDecorator` 함수를 제공하여 커스텀 파라미터 데코레이터를 만들 수 있습니다.

```typescript
import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export const CustomParam = createParamDecorator(
  (data: unknown, context: ExecutionContext) => {
    // 데코레이터 로직
    return value;
  },
);
```

#### createParamDecorator 파라미터

- **data**: 데코레이터에 전달된 데이터 (선택적)
- **context**: 실행 컨텍스트 (요청 정보 포함)

---

## 2. User Custom Param Decorator 생성하기

### 2.1 문제 상황

인증된 사용자의 ID를 가져올 때마다 다음과 같은 코드를 반복해야 합니다:

```typescript
@Post()
createMovie(@Body() body: CreateMovieDto, @Request() req) {
  const userId = req.user.sub;  // 반복적인 코드
  return this.movieService.create(body, userId);
}
```

### 2.2 UserId Decorator 생성

사용자 ID를 추출하는 커스텀 데코레이터를 만듭니다.

```typescript:src/user/decorator/user-id.decorator.ts
import {
  createParamDecorator,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';

export const UserId = createParamDecorator(
  (data: unknown, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest();

    if (!request || !request.user || !request.user.sub) {
      throw new UnauthorizedException('사용자 정보를 찾을 수 없습니다.');
    }
    return request.user.sub;
  },
);
```

#### 코드 설명

1. **createParamDecorator**: 커스텀 파라미터 데코레이터 생성
2. **ExecutionContext**: 요청 컨텍스트 정보 접근
3. **request.user.sub**: JWT 토큰에서 추출한 사용자 ID
4. **에러 처리**: 사용자 정보가 없으면 `UnauthorizedException` 발생

### 2.3 사용 방법

컨트롤러에서 `@UserId()` 데코레이터를 사용합니다.

```typescript:src/movie/movie.controller.ts
import { UserId } from 'src/user/decorator/user-id.decorator';

@Post()
@RBAC(Role.admin)
@UseInterceptors(TransactionInterceptor)
createMovie(
  @Body() body: CreateMovieDto,
  @QueryRunner() queryRunner: QR,
  @UserId() userId: number,  // 깔끔하게 사용자 ID 추출
) {
  return this.movieService.create(body, queryRunner, userId);
}
```

#### 장점

- **가독성 향상**: `@UserId()`로 의도가 명확함
- **타입 안정성**: `number` 타입으로 명시
- **에러 처리**: 데코레이터 내부에서 일관된 에러 처리
- **재사용성**: 여러 컨트롤러에서 재사용 가능

### 2.4 동작 흐름

1. **요청 도착**: 클라이언트가 요청을 보냄
2. **인증 미들웨어**: `BearerTokenMiddleware`가 JWT 토큰 검증
3. **사용자 정보 설정**: `req.user`에 사용자 정보 저장
4. **데코레이터 실행**: `@UserId()` 데코레이터가 `req.user.sub` 추출
5. **컨트롤러 메서드**: `userId` 파라미터로 전달

---

## 3. Query Runner Custom Param Decorator 생성하기

### 3.1 왜 QueryRunner 데코레이터가 필요한가?

#### 문제 상황: TransactionInterceptor와의 연동

트랜잭션을 사용할 때 `TransactionInterceptor`가 QueryRunner를 생성하고 `request` 객체에 저장합니다:

```typescript:src/common/interceptor/transaction.interceptor.ts
@Injectable()
export class TransactionInterceptor implements NestInterceptor {
  constructor(private readonly dataSource: DataSource) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const req = context.switchToHttp().getRequest();
    const qr = this.dataSource.createQueryRunner();

    await qr.connect();
    await qr.startTransaction();

    req.queryRunner = qr;  // request 객체에 QueryRunner 저장

    return next.handle().pipe(
      catchError(async (e) => {
        await qr.rollbackTransaction();
        await qr.release();
        throw e;
      }),
      tap(async () => {
        await qr.commitTransaction();
        await qr.release();
      }),
    );
  }
}
```

#### 기존 방식의 문제점

데코레이터 없이 사용하면:

```typescript
@Post()
@UseInterceptors(TransactionInterceptor)
createMovie(@Body() body: CreateMovieDto, @Request() req) {
  const queryRunner = req.queryRunner;  // 반복적인 코드
  return this.movieService.create(body, queryRunner);
}
```

**문제점:**
1. **반복 코드**: 매번 `req.queryRunner` 접근
2. **타입 안정성 부족**: `any` 타입으로 추론될 수 있음
3. **에러 처리 누락**: QueryRunner가 없을 때 체크하지 않음
4. **가독성 저하**: 의도가 명확하지 않음

### 3.2 QueryRunner Decorator 생성

QueryRunner를 추출하는 커스텀 데코레이터를 만듭니다.

```typescript:src/common/decorator/query-runner.decorator.ts
import {
  ExecutionContext,
  InternalServerErrorException,
  createParamDecorator,
} from '@nestjs/common';

export const QueryRunner = createParamDecorator(
  (data: any, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest();

    if (!request || !request.queryRunner) {
      throw new InternalServerErrorException(
        'Query runner를 찾을 수 없습니다.',
      );
    }
    return request.queryRunner;
  },
);
```

#### 코드 설명

1. **request.queryRunner**: `TransactionInterceptor`가 설정한 QueryRunner 추출
2. **에러 처리**: QueryRunner가 없으면 명확한 에러 메시지
3. **타입 안정성**: TypeORM의 `QueryRunner` 타입 반환

### 3.3 사용 방법

컨트롤러에서 `@QueryRunner()` 데코레이터를 사용합니다.

```typescript:src/movie/movie.controller.ts
import type { QueryRunner as QR } from 'typeorm';
import { QueryRunner } from 'src/common/decorator/query-runner.decorator';

@Post()
@RBAC(Role.admin)
@UseInterceptors(TransactionInterceptor)  // QueryRunner 생성
createMovie(
  @Body() body: CreateMovieDto,
  @QueryRunner() queryRunner: QR,  // 깔끔하게 QueryRunner 추출
  @UserId() userId: number,
) {
  return this.movieService.create(body, queryRunner, userId);
}
```

#### 주의사항: import type 사용

TypeScript의 `isolatedModules` 옵션이 활성화되어 있으면, 타입으로만 사용하는 import는 `import type`을 사용해야 합니다:

```typescript
// ❌ 에러 발생
import { QueryRunner as QR } from 'typeorm';

// ✅ 올바른 방법
import type { QueryRunner as QR } from 'typeorm';
```

### 3.4 동작 흐름

1. **요청 도착**: 클라이언트가 요청을 보냄
2. **TransactionInterceptor 실행**: 
   - QueryRunner 생성
   - 트랜잭션 시작
   - `req.queryRunner = qr` 설정
3. **QueryRunner 데코레이터 실행**: 
   - `req.queryRunner` 추출
   - 없으면 에러 발생
4. **컨트롤러 메서드**: `queryRunner` 파라미터로 전달
5. **Service에서 사용**: 같은 QueryRunner로 모든 DB 작업 수행
6. **트랜잭션 완료**: 
   - 성공 시: `commitTransaction()`
   - 실패 시: `rollbackTransaction()`

### 3.5 왜 이 방식이 필요한가?

#### 1. Interceptor와 Decorator의 협력

```
┌─────────────────────────────────────────┐
│  TransactionInterceptor                 │
│  - QueryRunner 생성                     │
│  - req.queryRunner = qr 설정            │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  @QueryRunner() Decorator               │
│  - req.queryRunner 추출                 │
│  - 컨트롤러 파라미터로 주입             │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Controller Method                      │
│  - queryRunner 파라미터로 받음          │
│  - Service에 전달                      │
└─────────────────────────────────────────┘
```

#### 2. 관심사의 분리

- **Interceptor**: QueryRunner 생성 및 트랜잭션 관리
- **Decorator**: QueryRunner 추출 및 주입
- **Controller**: 비즈니스 로직 호출
- **Service**: 실제 데이터 처리

#### 3. 타입 안정성

```typescript
// ❌ 타입 추론 어려움
@Request() req  // req.queryRunner의 타입이 명확하지 않음

// ✅ 명확한 타입
@QueryRunner() queryRunner: QR  // QueryRunner 타입 명시
```

#### 4. 에러 처리

```typescript
// ❌ 에러 처리 누락 가능
const qr = req.queryRunner;  // undefined일 수 있음

// ✅ 데코레이터에서 검증
@QueryRunner() queryRunner: QR  // 없으면 에러 발생
```

### 3.6 실제 사용 예시

#### Movie 생성 예시

```typescript:src/movie/movie.controller.ts
@Post()
@RBAC(Role.admin)
@UseInterceptors(TransactionInterceptor)
createMovie(
  @Body() body: CreateMovieDto,
  @QueryRunner() queryRunner: QR,
  @UserId() userId: number,
) {
  return this.movieService.create(body, queryRunner, userId);
}
```

```typescript:src/movie/movie.service.ts
async create(
  CreateMovieDto: CreateMovieDto,
  qr: QueryRunner,  // 같은 QueryRunner 사용
  userId: number,
) {
  // 모든 DB 작업이 같은 트랜잭션 내에서 실행됨
  const movieDetail = await qr.manager.insert(MovieDetail, {...});
  const movie = await qr.manager.insert(Movie, {...});
  // ...
}
```

---

## 정리

### Custom Decorator의 장점

| 구분 | 기존 방식 | Custom Decorator |
|------|----------|-----------------|
| **가독성** | `req.user.sub` | `@UserId()` |
| **타입 안정성** | `any` 추론 가능 | 명시적 타입 |
| **에러 처리** | 수동 체크 필요 | 데코레이터 내부 처리 |
| **재사용성** | 코드 복사 | 한 번 정의, 여러 곳 사용 |
| **유지보수** | 여러 곳 수정 필요 | 한 곳만 수정 |

### Decorator 생성 패턴

```typescript
export const CustomParam = createParamDecorator(
  (data: unknown, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest();
    
    // 1. 데이터 추출
    const value = request.someProperty;
    
    // 2. 검증
    if (!value) {
      throw new SomeException('에러 메시지');
    }
    
    // 3. 반환
    return value;
  },
);
```

### Interceptor와 Decorator의 관계

- **Interceptor**: 요청/응답 전후 처리, 공통 로직 실행
- **Decorator**: 파라미터 추출 및 주입, 타입 안정성 확보
- **협력**: Interceptor가 설정한 값을 Decorator가 추출하여 주입

### 사용 예시 비교

#### Before (데코레이터 없이)

```typescript
@Post()
createMovie(@Body() body: CreateMovieDto, @Request() req) {
  const userId = req.user?.sub;
  const queryRunner = req.queryRunner;
  
  if (!userId) {
    throw new UnauthorizedException('사용자 정보 없음');
  }
  if (!queryRunner) {
    throw new InternalServerErrorException('QueryRunner 없음');
  }
  
  return this.movieService.create(body, queryRunner, userId);
}
```

#### After (데코레이터 사용)

```typescript
@Post()
createMovie(
  @Body() body: CreateMovieDto,
  @QueryRunner() queryRunner: QR,
  @UserId() userId: number,
) {
  return this.movieService.create(body, queryRunner, userId);
}
```

**개선점:**
- 코드 라인 수 감소
- 가독성 향상
- 타입 안정성 확보
- 에러 처리 일관성

커스텀 데코레이터는 반복적인 코드를 제거하고, 가독성과 유지보수성을 크게 향상시킵니다. 특히 Interceptor와 함께 사용하면 강력한 시너지를 발휘합니다.
