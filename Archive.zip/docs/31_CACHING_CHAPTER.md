# Part 23. 캐싱

## 목차
1. [캐싱 이론](#1-캐싱-이론)
2. [Cache Manager 기본 사용법](#2-cache-manager-기본-사용법)
3. [Cache Interceptor 사용해보기](#3-cache-interceptor-사용해보기)
4. [캐시 실제 사용 사례 실습](#4-캐시-실제-사용-사례-실습)
   - [토큰 캐싱으로 인증 프로세스 간소화하기](#41-토큰-캐싱으로-인증-프로세스-간소화하기)
   - [캐시로 토큰 블락하기](#42-캐시로-토큰-블락하기)
   - [캐시로 Throttling 구현하기](#43-캐시로-throttling-구현하기)
5. [Redis를 활용한 캐싱](#5-redis를-활용한-캐싱)

---

## 1. 캐싱 이론

### 1.1 캐싱이란?

**캐싱(Caching)**은 자주 사용되는 데이터를 빠른 저장소에 임시로 저장하여, 동일한 요청에 대해 빠르게 응답하는 기술입니다.

#### 캐싱의 목적

1. **성능 향상**: 데이터베이스 조회 시간 단축
2. **부하 감소**: 데이터베이스 서버 부하 감소
3. **응답 시간 개선**: 사용자 경험 향상

### 1.2 캐싱의 동작 원리

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ 1. 요청
       ↓
┌─────────────┐
│  Controller │
└──────┬──────┘
       │ 2. 캐시 확인
       ↓
┌─────────────┐      ┌─────────────┐
│   Cache     │─────>│  Database   │
│  (Memory)   │      │             │
└─────────────┘      └─────────────┘
   │ 3. 캐시 있음        │ 4. 캐시 없음
   │    → 즉시 반환      │    → DB 조회
   │                     │    → 캐시 저장
```

### 1.3 캐싱 전략

#### 1. Cache-Aside (Lazy Loading)

가장 일반적인 캐싱 전략입니다.

```typescript
// 1. 캐시 확인
const cached = await cache.get(key);
if (cached) {
  return cached;  // 캐시 있으면 반환
}

// 2. 캐시 없으면 DB 조회
const data = await db.query();

// 3. 캐시에 저장
await cache.set(key, data);

return data;
```

#### 2. Write-Through

데이터를 저장할 때 캐시와 DB에 동시에 저장합니다.

#### 3. Write-Back

데이터를 먼저 캐시에 저장하고, 나중에 DB에 저장합니다.

### 1.4 캐시의 종류

#### 1. 메모리 캐시 (In-Memory Cache)

- **장점**: 매우 빠름
- **단점**: 서버 재시작 시 데이터 손실, 메모리 제한

#### 2. 분산 캐시 (Distributed Cache)

- **예시**: Redis, Memcached
- **장점**: 여러 서버 간 공유 가능, 영속성
- **단점**: 네트워크 지연 가능

### 1.5 TTL (Time To Live)

**TTL**은 캐시 데이터의 유효 기간입니다. TTL이 지나면 캐시가 자동으로 만료됩니다.

```typescript
// 3초 후 만료
CacheModule.register({
  ttl: 3000,  // 밀리초 단위
})
```

---

## 2. Cache Manager 기본 사용법

### 2.1 CacheModule 설치 및 설정

#### 패키지 설치

```bash
npm install @nestjs/cache-manager cache-manager
```

#### Module에 등록

```typescript:src/movie/movie.module.ts
import { CacheModule } from '@nestjs/cache-manager';

@Module({
  imports: [
    // ... other imports
    CacheModule.register({
      ttl: 3000,  // 기본 TTL: 3초 (밀리초)
    }),
  ],
  // ...
})
export class MovieModule {}
```

#### 설정 옵션

- **ttl**: 기본 캐시 유효 시간 (밀리초)
- **max**: 최대 캐시 항목 수
- **store**: 캐시 저장소 (기본값: 메모리)

### 2.2 CacheManager 주입

Service에서 `CACHE_MANAGER`를 주입받아 사용합니다.

```typescript:src/movie/movie.service.ts
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';

@Injectable()
export class MovieService {
  constructor(
    // ... other dependencies
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
  ) {}
}
```

### 2.3 캐시 사용 예시

#### findRecent 메서드 구현

```typescript:src/movie/movie.service.ts
async findRecent() {
  // 1. 캐시에서 데이터 조회
  const cacheData = await this.cacheManager.get('MOVIE_RECENT');

  if (cacheData) {
    console.log('캐시에서 데이터 반환');
    return cacheData;
  }

  // 2. 캐시에 없으면 DB 조회
  console.log('DB에서 데이터 조회');
  const data = await this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres')
    .orderBy('movie.createdAt', 'DESC')
    .take(10)
    .getMany();

  // 3. 캐시에 저장 (TTL: 3초)
  await this.cacheManager.set('MOVIE_RECENT', data);

  return data;
}
```

### 2.4 CacheManager 메서드

#### 주요 메서드

| 메서드 | 설명 | 예시 |
|--------|------|------|
| `get(key)` | 캐시에서 데이터 조회 | `await cache.get('key')` |
| `set(key, value, ttl?)` | 캐시에 데이터 저장 | `await cache.set('key', data, 5000)` |
| `del(key)` | 캐시에서 데이터 삭제 | `await cache.del('key')` |
| `reset()` | 모든 캐시 삭제 | `await cache.reset()` |

#### TTL 설정

```typescript
// 기본 TTL 사용 (모듈에서 설정한 값)
await this.cacheManager.set('key', data);

// 특정 TTL 설정 (밀리초)
await this.cacheManager.set('key', data, 5000);  // 5초

// TTL 없음 (영구 저장 - 메모리 제한까지)
await this.cacheManager.set('key', data, 0);
```

### 2.5 동작 흐름

#### 첫 번째 요청

```
1. Client → GET /movie/recent
2. Service.findRecent() 호출
3. cache.get('MOVIE_RECENT') → null
4. DB 조회
5. cache.set('MOVIE_RECENT', data)
6. 데이터 반환
```

#### 두 번째 요청 (3초 이내)

```
1. Client → GET /movie/recent
2. Service.findRecent() 호출
3. cache.get('MOVIE_RECENT') → data (캐시 히트!)
4. 데이터 반환 (DB 조회 없음)
```

#### 세 번째 요청 (3초 이후)

```
1. Client → GET /movie/recent
2. Service.findRecent() 호출
3. cache.get('MOVIE_RECENT') → null (TTL 만료)
4. DB 조회
5. cache.set('MOVIE_RECENT', data)
6. 데이터 반환
```

### 2.6 캐시 키 전략

#### 단순 키

```typescript
await this.cacheManager.set('MOVIE_RECENT', data);
```

#### 파라미터 기반 키

```typescript
const key = `MOVIE_${movieId}`;
await this.cacheManager.set(key, movie);
```

#### 복합 키

```typescript
const key = `MOVIE_${movieId}_USER_${userId}`;
await this.cacheManager.set(key, likeStatus);
```

---

## 3. Cache Interceptor 사용해보기

### 3.1 Cache Interceptor란?

**Cache Interceptor**는 NestJS에서 제공하는 인터셉터로, 자동으로 응답을 캐싱하고 재사용합니다.

#### 장점

- **코드 간소화**: Service에서 캐시 로직 제거
- **자동 캐싱**: GET 요청 자동 캐싱
- **유연한 설정**: 메서드별로 다른 캐시 키와 TTL 설정 가능

### 3.2 기본 사용법

#### Controller에 적용

```typescript:src/movie/movie.controller.ts
import {
  CacheInterceptor as CI,
  CacheKey,
  CacheTTL,
} from '@nestjs/cache-manager';

@Get('recent')
@UseInterceptors(CI)  // Cache Interceptor 적용
getMoviesRecent() {
  console.log('getMoviesRecent() 호출');
  return this.movieService.findRecent();
}
```

#### 동작 방식

1. **첫 번째 요청**: Service 메서드 실행 → 응답 캐싱
2. **두 번째 요청**: 캐시에서 응답 반환 (Service 메서드 실행 안 됨)

### 3.3 캐시 키 설정

기본적으로 Cache Interceptor는 요청 URL을 캐시 키로 사용합니다.

#### 커스텀 캐시 키 설정

```typescript:src/movie/movie.controller.ts
@Get('recent')
@UseInterceptors(CI)
@CacheKey('getMoviesRecent')  // 커스텀 캐시 키
getMoviesRecent() {
  return this.movieService.findRecent();
}
```

#### 캐시 키의 중요성

- **기본 동작**: `GET /movie/recent` → 키: `GET-/movie/recent`
- **커스텀 키**: `@CacheKey('getMoviesRecent')` → 키: `getMoviesRecent`

**주의사항:**
- 같은 키를 사용하면 캐시가 공유됩니다
- 다른 엔드포인트와 키가 겹치지 않도록 주의

### 3.4 TTL 설정

#### 메서드별 TTL 설정

```typescript:src/movie/movie.controller.ts
@Get('recent')
@UseInterceptors(CI)
@CacheKey('getMoviesRecent')
@CacheTTL(3000)  // 3초 (밀리초)
getMoviesRecent() {
  return this.movieService.findRecent();
}
```

#### TTL 우선순위

1. `@CacheTTL()` 데코레이터 (가장 높음)
2. `CacheModule.register({ ttl })` 설정
3. 기본값 (무제한)

### 3.5 Service 메서드 수정

Cache Interceptor를 사용하면 Service에서 캐시 로직을 제거할 수 있습니다.

#### Before (수동 캐싱)

```typescript
async findRecent() {
  const cacheData = await this.cacheManager.get('MOVIE_RECENT');
  if (cacheData) {
    return cacheData;
  }
  
  const data = await this.movieRepository.find(...);
  await this.cacheManager.set('MOVIE_RECENT', data);
  return data;
}
```

#### After (Interceptor 사용)

```typescript
async findRecent() {
  // 캐시 로직 제거, 순수한 비즈니스 로직만
  return await this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres')
    .orderBy('movie.createdAt', 'DESC')
    .take(10)
    .getMany();
}
```

### 3.6 동작 확인

#### 첫 번째 요청

```bash
GET /movie/recent

# 콘솔 출력
getMoviesRecent() 호출  # Service 메서드 실행됨
```

#### 두 번째 요청 (TTL 내)

```bash
GET /movie/recent

# 콘솔 출력 없음  # Service 메서드 실행 안 됨 (캐시에서 반환)
```

#### 세 번째 요청 (TTL 만료 후)

```bash
GET /movie/recent

# 콘솔 출력
getMoviesRecent() 호출  # Service 메서드 다시 실행됨
```

### 3.7 주의사항

#### 1. GET 요청만 캐싱

Cache Interceptor는 기본적으로 GET 요청만 캐싱합니다.

```typescript
// ✅ 캐싱됨
@Get('recent')
@UseInterceptors(CI)
getMoviesRecent() { ... }

// ❌ 캐싱 안 됨
@Post('recent')
@UseInterceptors(CI)
createRecent() { ... }
```

#### 2. 동적 파라미터 처리

URL 파라미터가 있으면 자동으로 캐시 키에 포함됩니다.

```typescript
@Get(':id')
@UseInterceptors(CI)
getMovie(@Param('id') id: number) {
  // 캐시 키: GET-/movie/1, GET-/movie/2, ...
}
```

#### 3. 캐시 무효화

데이터가 변경되면 캐시를 수동으로 삭제해야 합니다.

```typescript
@Post()
createMovie(@Body() dto: CreateMovieDto) {
  // 영화 생성 후 관련 캐시 삭제
  await this.cacheManager.del('getMoviesRecent');
  return this.movieService.create(dto);
}
```

### 3.8 커스텀 Cache Interceptor

기본 Cache Interceptor 대신 커스텀 Interceptor를 만들 수도 있습니다.

```typescript:src/common/interceptor/cache.interceptor.ts
import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable, of, tap } from 'rxjs';

export class CacheInterceptor implements NestInterceptor {
  private cache = new Map<string, any>();

  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<any> | Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest();

    // 캐시 키 생성
    const key = `${request.method}-${request.path}`;

    // 캐시 확인
    if (this.cache.has(key)) {
      return of(this.cache.get(key));
    }

    // 캐시 없으면 실행하고 캐시에 저장
    return next.handle().pipe(
      tap((response) => this.cache.set(key, response))
    );
  }
}
```

**차이점:**
- 기본 Interceptor: `@nestjs/cache-manager`의 `CacheManager` 사용
- 커스텀 Interceptor: 메모리 `Map` 사용 (서버 재시작 시 초기화)

---

## 정리

### 캐싱 방식 비교

| 구분 | CacheManager 직접 사용 | Cache Interceptor |
|------|----------------------|-------------------|
| **코드 위치** | Service | Controller |
| **캐시 로직** | 수동 작성 | 자동 처리 |
| **유연성** | 높음 (세밀한 제어) | 중간 (설정으로 제어) |
| **코드 간소화** | 낮음 | 높음 |
| **사용 시기** | 복잡한 캐시 로직 필요 시 | 간단한 GET 요청 캐싱 |

### CacheManager 메서드 요약

```typescript
// 조회
const data = await cacheManager.get('key');

// 저장 (기본 TTL)
await cacheManager.set('key', data);

// 저장 (커스텀 TTL)
await cacheManager.set('key', data, 5000);

// 삭제
await cacheManager.del('key');

// 전체 삭제
await cacheManager.reset();
```

### Cache Interceptor 데코레이터

```typescript
@UseInterceptors(CacheInterceptor)  // Interceptor 적용
@CacheKey('custom-key')              // 커스텀 캐시 키
@CacheTTL(3000)                      // 커스텀 TTL
```

### 캐싱 전략

1. **자주 조회되는 데이터**: 최근 영화 목록, 인기 영화 등
2. **변경이 적은 데이터**: 장르 목록, 감독 목록 등
3. **계산 비용이 큰 데이터**: 통계, 집계 데이터 등

### 주의사항

1. **캐시 무효화**: 데이터 변경 시 관련 캐시 삭제 필요
2. **메모리 관리**: 무제한 캐시는 메모리 부족 유발
3. **데이터 일관성**: 캐시와 DB 데이터 불일치 가능성
4. **TTL 설정**: 너무 길면 오래된 데이터, 너무 짧으면 캐시 효과 감소

캐싱은 성능 향상의 핵심 기술이지만, 적절한 사용과 관리가 중요합니다.

---

## 4. 캐시 실제 사용 사례 실습

### 4.1 토큰 캐싱으로 인증 프로세스 간소화하기

#### 문제 상황

매 요청마다 JWT 토큰을 검증하는 것은 비용이 큽니다:
- 토큰 디코딩
- 서명 검증
- 시크릿 키 조회
- 페이로드 파싱

#### 해결 방법: 토큰 캐싱

검증된 토큰의 페이로드를 캐시에 저장하여, 다음 요청에서는 캐시에서 바로 사용합니다.

#### BearerTokenMiddleware 구현

```typescript:src/auth/middleware/bearer-token.middleware.ts
@Injectable()
export class BearerTokenMiddleware implements NestMiddleware {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
      next();
      return;
    }

    const token = this.validateBearerToken(authHeader);
    const tokenKey = `TOKEN_${token}`;

    // 1. 캐시에서 토큰 페이로드 확인
    const cachePayload = await this.cacheManager.get(tokenKey);

    if (cachePayload) {
      console.log('cache 토큰 사용');
      req.user = cachePayload;
      return next();  // 캐시에서 가져왔으므로 검증 생략
    }

    // 2. 캐시에 없으면 토큰 검증
    const decodedPayload = this.jwtService.decode(token);

    if (decodedPayload.type !== 'refresh' && decodedPayload.type !== 'access') {
      throw new BadRequestException('Invalid token');
    }

    try {
      const secretKey = this.configService.get<string>(
        decodedPayload.type === 'refresh'
          ? envVariableKeys.refreshTokenSecret
          : envVariableKeys.accessTokenSecret,
      )!;
      
      const payload = await this.jwtService.verifyAsync(token, {
        secret: secretKey,
      });

      // 3. 토큰 만료 시간 계산하여 캐시에 저장
      const expiryDate = +new Date(payload['exp'] * 1000);
      const now = +new Date();
      const diffrenceInSeconds = (expiryDate - now) / 1000;

      await this.cacheManager.set(
        tokenKey,
        payload,
        Math.max((diffrenceInSeconds - 30) * 1000, 1),  // 30초 여유
      );

      req.user = payload;
      next();
    } catch (e) {
      if (e.name === 'JsonWebTokenError') {
        throw new UnauthorizedException('토큰이 만료되었습니다');
      }
      next();
    }
  }
}
```

#### 동작 흐름

**첫 번째 요청:**
```
1. 토큰 추출
2. 캐시 확인 → 없음
3. JWT 검증 (비용 큰 작업)
4. 페이로드 캐시에 저장 (TTL: 만료 시간 - 30초)
5. req.user 설정
```

**두 번째 요청 (같은 토큰):**
```
1. 토큰 추출
2. 캐시 확인 → 있음!
3. 캐시에서 페이로드 가져오기 (빠름)
4. req.user 설정 (검증 생략)
```

#### 성능 개선

- **검증 비용**: JWT 검증은 암호화 연산이 필요하므로 비용이 큼
- **캐시 조회**: 메모리에서 읽는 것은 매우 빠름
- **TTL 설정**: 토큰 만료 시간보다 30초 짧게 설정하여 안전성 확보

#### 주의사항

1. **토큰 만료 시간**: 캐시 TTL은 토큰 만료 시간보다 짧게 설정
2. **메모리 사용**: 많은 사용자가 있으면 메모리 사용량 증가
3. **토큰 무효화**: 로그아웃 시 캐시 삭제 필요

---

### 4.2 캐시로 토큰 블락하기

#### 문제 상황

로그아웃하거나 토큰을 무효화해야 할 때, JWT는 stateless이므로 서버에서 직접 무효화할 수 없습니다.

#### 해결 방법: 블랙리스트 캐싱

무효화된 토큰을 캐시에 저장하여, 해당 토큰으로의 요청을 차단합니다.

#### tokenBlock 메서드 구현

```typescript:src/auth/auth.service.ts
async tokenBlock(token: string) {
  const payload = await this.jwtService.decode(token);

  if (!payload || !payload['exp']) {
    throw new BadRequestException('Invalid token');
  }

  // 토큰 만료 시간 계산
  const expiryDate = +new Date(payload['exp'] * 1000);
  const now = +new Date();
  const diffrenceInSeconds = (expiryDate - now) / 1000;

  // 블랙리스트에 추가 (토큰 만료 시간까지 유지)
  await this.cacheManager.set(
    `BLOCK_TOKEN_${token}`,
    payload,
    Math.max(diffrenceInSeconds * 1000, 1),
  );

  return true;
}
```

#### Controller 엔드포인트

```typescript:src/auth/auth.controller.ts
@Post('token/block')
blockToken(@Body('token') token: string) {
  return this.authService.tokenBlock(token);
}
```

#### Middleware에서 블록 확인

```typescript:src/auth/middleware/bearer-token.middleware.ts
const token = this.validateBearerToken(authHeader);
const tokenKey = `TOKEN_${token}`;

// 블랙리스트 확인
const blockToken = await this.cacheManager.get(`BLOCK_TOKEN_${token}`);

if (blockToken) {
  throw new UnauthorizedException('토큰이 만료되었습니다');
}

// ... 나머지 로직
```

#### 동작 흐름

**토큰 블록:**
```
1. POST /auth/token/block { token: "..." }
2. 토큰 디코딩하여 만료 시간 확인
3. BLOCK_TOKEN_{token} 키로 캐시에 저장
4. TTL: 토큰 만료 시간까지
```

**블록된 토큰으로 요청:**
```
1. BearerTokenMiddleware 실행
2. BLOCK_TOKEN_{token} 확인
3. 캐시에 있으면 → 401 Unauthorized
4. 캐시에 없으면 → 정상 처리
```

#### 장점

1. **즉시 무효화**: 로그아웃 시 즉시 토큰 무효화
2. **자동 만료**: 토큰 만료 시간과 함께 캐시도 만료
3. **메모리 효율**: 만료된 토큰은 자동으로 삭제

#### 사용 예시

```bash
# 1. 로그인
POST /auth/login
→ { accessToken: "eyJhbGci..." }

# 2. 토큰으로 요청
GET /movie
Authorization: Bearer eyJhbGci...
→ 정상 응답

# 3. 토큰 블록
POST /auth/token/block
{ "token": "eyJhbGci..." }
→ true

# 4. 같은 토큰으로 요청
GET /movie
Authorization: Bearer eyJhbGci...
→ 401 Unauthorized (토큰이 만료되었습니다)
```

---

### 4.3 캐시로 Throttling 구현하기

#### Throttling이란?

**Throttling(제한)**은 특정 시간 동안 요청 횟수를 제한하는 기능입니다. DDoS 공격 방지, API 사용량 제한 등에 사용됩니다.

#### Throttle Decorator 생성

```typescript:src/common/decorator/throttle.decorator.ts
import { Reflector } from '@nestjs/core';

export const Throttle = Reflector.createDecorator<{
  count: number;      // 허용 횟수
  unit: 'minute';     // 시간 단위
  ttl: number;        // 캐시 TTL (밀리초)
}>();
```

#### ThrottleInterceptor 구현

```typescript:src/common/interceptor/throttle.interceptor.ts
@Injectable()
export class ThrottleInterceptor implements NestInterceptor {
  constructor(
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
    private readonly reflector: Reflector,
  ) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler<any>,
  ): Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest();
    const userId = request?.user?.sub;

    // 사용자 ID가 없으면 제한 없음
    if (!userId) {
      return next.handle();
    }

    // Throttle 데코레이터에서 설정 가져오기
    const throttleOptions = this.reflector.get<{
      count: number;
      unit: 'minute';
      ttl: number;
    }>(Throttle, context.getHandler());

    if (!throttleOptions) {
      return next.handle();
    }

    // 캐시 키 생성: METHOD_PATH_USERID_MINUTE
    const date = new Date();
    const minute = date.getMinutes();
    const key = `${request.method}_${request.path}_${userId}_${minute}`;

    // 현재 요청 횟수 확인
    const count = await this.cacheManager.get<number>(key);

    if (count && count >= throttleOptions.count) {
      throw new ForbiddenException('요청 가능 횟수를 초과했습니다.');
    }

    // 요청 처리 후 카운트 증가
    return next.handle().pipe(
      tap(() => {
        void (async () => {
          const currentCount = (await this.cacheManager.get<number>(key)) ?? 0;
          await this.cacheManager.set(key, currentCount + 1, throttleOptions.ttl);
        })();
      }),
    );
  }
}
```

#### AppModule에 등록

```typescript:src/app.module.ts
@Module({
  providers: [
    // ... other providers
    {
      provide: APP_INTERCEPTOR,
      useClass: ThrottleInterceptor,
    },
  ],
})
export class AppModule {}
```

#### Controller에서 사용

```typescript:src/movie/movie.controller.ts
@Get()
@Public()
@Throttle({ count: 5, unit: 'minute', ttl: 60000 })  // 분당 5회 제한
getMovies(@Query() dto: GetMoviesDto, @UserId() UserId?: number) {
  return this.movieService.findAll(dto, UserId);
}
```

#### 동작 흐름

**첫 번째 요청:**
```
1. GET /movie 요청
2. 캐시 키: GET-/movie_1_45 (사용자 ID: 1, 분: 45)
3. 캐시 확인 → 없음 (count = 0)
4. 요청 처리
5. 캐시에 저장: count = 1, TTL = 60초
```

**두 번째 요청 (같은 분):**
```
1. GET /movie 요청
2. 캐시 키: GET-/movie_1_45
3. 캐시 확인 → count = 1
4. 1 < 5 → 요청 처리
5. 캐시 업데이트: count = 2
```

**6번째 요청 (같은 분):**
```
1. GET /movie 요청
2. 캐시 키: GET-/movie_1_45
3. 캐시 확인 → count = 5
4. 5 >= 5 → 403 Forbidden (요청 가능 횟수를 초과했습니다.)
```

**7번째 요청 (다음 분):**
```
1. GET /movie 요청
2. 캐시 키: GET-/movie_1_46 (분이 바뀜)
3. 캐시 확인 → 없음
4. 요청 처리
5. 캐시에 저장: count = 1
```

#### 캐시 키 전략

```
{method}_{path}_{userId}_{minute}
```

- **method**: HTTP 메서드 (GET, POST 등)
- **path**: 요청 경로 (/movie)
- **userId**: 사용자 ID
- **minute**: 현재 분 (0-59)

**예시:**
- `GET-/movie_1_45`: 사용자 1이 45분에 GET /movie 요청
- `POST-/movie_1_45`: 사용자 1이 45분에 POST /movie 요청
- `GET-/movie_1_46`: 사용자 1이 46분에 GET /movie 요청 (새로운 윈도우)

#### 주의사항

1. **분 단위 윈도우**: 같은 분 내에서만 카운트가 유지됨
2. **사용자별 제한**: 각 사용자마다 독립적으로 카운트
3. **경로별 제한**: 다른 경로는 별도로 카운트
4. **비동기 처리**: `tap` 내부에서 async 작업은 `void`로 처리

---

## 5. Redis를 활용한 캐싱

### 5.1 Redis란?

**Redis (Remote Dictionary Server)**는 인메모리 데이터 구조 저장소입니다. 캐싱, 세션 저장, 메시지 큐 등에 사용됩니다.

#### Redis의 장점

1. **빠른 속도**: 메모리 기반으로 매우 빠름
2. **영속성**: 디스크에 저장 가능 (RDB, AOF)
3. **분산 캐시**: 여러 서버 간 캐시 공유
4. **다양한 데이터 타입**: String, List, Set, Hash, Sorted Set

### 5.2 Redis 설치 및 설정

#### Redis 설치

```bash
# macOS
brew install redis

# Ubuntu
sudo apt-get install redis-server

# Docker
docker run -d -p 6379:6379 redis
```

#### NestJS에서 Redis 사용

```typescript
import { CacheModule } from '@nestjs/cache-manager';
import { redisStore } from 'cache-manager-redis-store';

@Module({
  imports: [
    CacheModule.register({
      store: redisStore,
      host: 'localhost',
      port: 6379,
      ttl: 3000,
    }),
  ],
})
export class AppModule {}
```

### 5.3 메모리 캐시 vs Redis

| 구분 | 메모리 캐시 | Redis |
|------|------------|-------|
| **속도** | 매우 빠름 | 빠름 |
| **영속성** | 없음 (서버 재시작 시 손실) | 있음 |
| **분산** | 불가능 | 가능 |
| **설정** | 간단 | 복잡 |
| **사용 시기** | 단일 서버, 개발 환경 | 프로덕션, 분산 환경 |

### 5.4 Redis 사용 시나리오

1. **분산 캐싱**: 여러 서버 간 캐시 공유
2. **세션 저장**: 사용자 세션 관리
3. **실시간 데이터**: 실시간 카운터, 랭킹 등
4. **메시지 큐**: 작업 큐, 이벤트 처리

### 5.5 현재 프로젝트에서의 사용

현재 프로젝트는 메모리 캐시를 사용하고 있습니다:

```typescript:src/movie/movie.module.ts
CacheModule.register({
  ttl: 3000,  // 메모리 캐시
})
```

프로덕션 환경에서는 Redis로 전환하는 것을 권장합니다.

---

## 정리 (추가)

### 캐싱 사용 사례 요약

| 사례 | 목적 | 구현 위치 |
|------|------|----------|
| **토큰 캐싱** | 인증 성능 향상 | `BearerTokenMiddleware` |
| **토큰 블록** | 로그아웃 처리 | `AuthService.tokenBlock` |
| **Throttling** | 요청 제한 | `ThrottleInterceptor` |
| **데이터 캐싱** | 조회 성능 향상 | `CacheInterceptor` |

### 성능 개선 효과

1. **토큰 캐싱**: JWT 검증 비용 절감 (약 90% 시간 단축)
2. **데이터 캐싱**: DB 조회 비용 절감 (약 80% 시간 단축)
3. **Throttling**: 서버 부하 방지

### 캐시 키 네이밍 규칙

```
TOKEN_{token}              // 토큰 페이로드
BLOCK_TOKEN_{token}        // 블록된 토큰
MOVIE_RECENT               // 최근 영화 목록
{method}_{path}_{userId}_{minute}  // Throttling 카운트
```

캐싱은 성능 향상의 핵심 기술이지만, 적절한 사용과 관리가 중요합니다.
