# Mapped Types

## 목차
1. [Mapped Types란?](#mapped-types란)
2. [PartialType 사용하기](#partialtype-사용하기)
3. [다른 Mapped Types](#다른-mapped-types)

---

## Mapped Types란?

### Mapped Types의 정의

**Mapped Types**는 TypeScript의 유틸리티 타입을 기반으로, 기존 타입을 변환하여 새로운 타입을 만드는 기능입니다. NestJS는 `@nestjs/mapped-types` 패키지를 통해 DTO를 쉽게 변환할 수 있는 유틸리티 함수를 제공합니다.

### Mapped Types를 사용하는 이유

1. **코드 중복 제거**: CreateDto와 UpdateDto가 거의 동일할 때 중복 코드를 줄일 수 있습니다.
2. **유지보수성**: CreateDto를 수정하면 UpdateDto도 자동으로 반영됩니다.
3. **타입 안정성**: TypeScript의 타입 시스템을 활용하여 타입 안정성을 보장합니다.

---

## PartialType 사용하기

### PartialType이란?

`PartialType`은 기존 DTO의 모든 속성을 선택적(optional)으로 만드는 Mapped Type입니다.

### 사용 예시

#### 기존 방식 (수동 작성)

```typescript
// create-movie.dto.ts
export class CreateMovieDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  detail: string;

  @IsNotEmpty()
  @IsNumber()
  directorId: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  genreIds: number[];
}

// update-movie.dto.ts (수동 작성)
export class UpdateMovieDto {
  @IsNotEmpty()
  @IsOptional()  // 모든 필드에 @IsOptional() 추가 필요
  @IsString()
  title?: string;

  @IsNotEmpty()
  @IsOptional()
  @IsString()
  detail?: string;

  @IsNotEmpty()
  @IsOptional()
  @IsNumber()
  directorId?: number;

  @IsArray()
  @IsNotEmpty()
  @IsOptional()
  @IsNumber({}, { each: true })
  genreIds?: number[];
}
```

**문제점**:
- CreateDto와 거의 동일한 코드 중복
- 필드 추가/수정 시 두 파일 모두 수정 필요
- 유지보수가 어려움

#### PartialType 사용 방식

**파일**: `src/movie/dto/create-movie.dto.ts`

```typescript
import {
  ArrayNotEmpty,
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsString,
} from 'class-validator';

export class CreateMovieDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  detail: string;

  @IsNotEmpty()
  @IsNumber()
  directorId: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  genreIds: number[];
}
```

**파일**: `src/movie/dto/update-movie.dto.ts`

```typescript
import { PartialType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';

export class UpdateMovieDto extends PartialType(CreateMovieDto) {}
```

**설명**:
- `PartialType(CreateMovieDto)`: `CreateMovieDto`의 모든 속성을 선택적으로 만듦
- 모든 필드에 `@IsOptional()` 데코레이터가 자동으로 추가됨
- 코드가 매우 간결해짐

**결과**:
```typescript
// UpdateMovieDto는 다음과 같이 변환됨
export class UpdateMovieDto {
  @IsNotEmpty()
  @IsOptional()  // 자동 추가
  @IsString()
  title?: string;

  @IsNotEmpty()
  @IsOptional()  // 자동 추가
  @IsString()
  detail?: string;

  @IsNotEmpty()
  @IsOptional()  // 자동 추가
  @IsNumber()
  directorId?: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsOptional()  // 자동 추가
  @IsNumber({}, { each: true })
  genreIds?: number[];
}
```

### 프로젝트에서의 사용

#### Movie DTO

**파일**: `src/movie/dto/update-movie.dto.ts`

```typescript
import { PartialType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';

export class UpdateMovieDto extends PartialType(CreateMovieDto) {}
```

#### Director DTO

**파일**: `src/director/dto/update-director.dto.ts`

```typescript
import { PartialType } from '@nestjs/mapped-types';
import { CreateDirectorDto } from './create-director.dto';

export class UpdateDirectorDto extends PartialType(CreateDirectorDto) {}
```

#### Genre DTO

**파일**: `src/genre/dto/update-genre.dto.ts`

```typescript
import { PartialType } from '@nestjs/mapped-types';
import { CreateGenreDto } from './create-genre.dto';

export class UpdateGenreDto extends PartialType(CreateGenreDto) {}
```

---

## 다른 Mapped Types

NestJS는 `PartialType` 외에도 여러 Mapped Types를 제공합니다.

### 1. PickType

기존 DTO에서 특정 속성만 선택합니다.

```typescript
import { PickType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';

export class MovieTitleDto extends PickType(CreateMovieDto, ['title'] as const) {}
```

**결과**:
```typescript
export class MovieTitleDto {
  @IsNotEmpty()
  @IsString()
  title: string;
}
```

### 2. OmitType

기존 DTO에서 특정 속성을 제외합니다.

```typescript
import { OmitType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';

export class MovieWithoutDetailDto extends OmitType(CreateMovieDto, ['detail'] as const) {}
```

**결과**:
```typescript
export class MovieWithoutDetailDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsNumber()
  directorId: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  genreIds: number[];
  // detail은 제외됨
}
```

### 3. IntersectionType

여러 DTO를 결합합니다.

```typescript
import { IntersectionType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';
import { BaseDto } from './base.dto';

export class CreateMovieWithBaseDto extends IntersectionType(
  CreateMovieDto,
  BaseDto,
) {}
```

**결과**: `CreateMovieDto`와 `BaseDto`의 모든 속성을 포함

### 4. PartialType + PickType 조합

```typescript
import { PartialType, PickType } from '@nestjs/mapped-types';
import { CreateMovieDto } from './create-movie.dto';

export class UpdateMovieTitleDto extends PartialType(
  PickType(CreateMovieDto, ['title'] as const),
) {}
```

**결과**:
```typescript
export class UpdateMovieTitleDto {
  @IsNotEmpty()
  @IsOptional()
  @IsString()
  title?: string;
}
```

---

## Mapped Types 비교

| Mapped Type | 설명 | 예시 |
|------------|------|------|
| `PartialType` | 모든 속성을 선택적으로 만듦 | `UpdateDto extends PartialType(CreateDto)` |
| `PickType` | 특정 속성만 선택 | `PickType(CreateDto, ['title'])` |
| `OmitType` | 특정 속성 제외 | `OmitType(CreateDto, ['detail'])` |
| `IntersectionType` | 여러 DTO 결합 | `IntersectionType(Dto1, Dto2)` |

---

## 프로젝트 파일 구조

```
src/
├── movie/
│   └── dto/
│       ├── create-movie.dto.ts        # CreateDto 정의
│       └── update-movie.dto.ts        # PartialType 사용
├── director/
│   └── dto/
│       ├── create-director.dto.ts     # CreateDto 정의
│       └── update-director.dto.ts     # PartialType 사용
└── genre/
    └── dto/
        ├── create-genre.dto.ts        # CreateDto 정의
        └── update-genre.dto.ts        # PartialType 사용
```

---

## 핵심 개념 정리

### 1. PartialType의 장점

- **코드 중복 제거**: CreateDto를 재사용
- **유지보수성**: CreateDto 수정 시 UpdateDto 자동 반영
- **간결성**: 한 줄로 UpdateDto 생성

### 2. 사용 방법

```typescript
import { PartialType } from '@nestjs/mapped-types';
import { CreateDto } from './create-dto';

export class UpdateDto extends PartialType(CreateDto) {}
```

### 3. 동작 원리

- `PartialType`은 TypeScript의 `Partial<T>` 유틸리티 타입을 기반으로 작동
- 모든 속성을 선택적으로 만들고, `@IsOptional()` 데코레이터를 자동 추가
- 기존 데코레이터는 그대로 유지

### 4. 주의사항

- `@nestjs/mapped-types` 패키지가 설치되어 있어야 함
- `as const`를 사용하여 배열 리터럴 타입 보장 (PickType, OmitType 사용 시)

---

## 참고사항

1. **패키지 설치**: `@nestjs/mapped-types`는 NestJS에 기본 포함되어 있습니다.
2. **타입 안정성**: Mapped Types는 컴파일 타임에 타입 체크를 수행합니다.
3. **데코레이터 유지**: 기존 validation 데코레이터가 그대로 유지됩니다.
4. **조합 사용**: 여러 Mapped Types를 조합하여 사용할 수 있습니다.

---

## 실전 팁

### 1. UpdateDto는 항상 PartialType 사용

```typescript
// ✅ 좋은 예
export class UpdateMovieDto extends PartialType(CreateMovieDto) {}

// ❌ 나쁜 예
export class UpdateMovieDto {
  @IsOptional()
  @IsString()
  title?: string;
  // ... 모든 필드 수동 작성
}
```

### 2. 특정 필드만 업데이트 가능하게 하기

```typescript
// title만 업데이트 가능
export class UpdateMovieTitleDto extends PartialType(
  PickType(CreateMovieDto, ['title'] as const),
) {}
```

### 3. 특정 필드 제외하기

```typescript
// detail을 제외한 모든 필드
export class UpdateMovieWithoutDetailDto extends PartialType(
  OmitType(CreateMovieDto, ['detail'] as const),
) {}
```

---

## 참고 자료

- [NestJS Mapped Types 공식 문서](https://docs.nestjs.com/mapped-types)
