# Part 28. Testing 이론

## 목차
1. [테스트 이론 (개요 및 Matcher 함수)](#1-테스트-이론-개요-및-matcher-함수)
2. [Mock vs Stub vs Fake 이론](#2-mock-vs-stub-vs-fake-이론)
3. [Mock Function 이론](#3-mock-function-이론)
4. [Testing의 종류 이론](#4-testing의-종류-이론)
5. [Test 코드 예제 이론](#5-test-코드-예제-이론)
6. [NestJS Test 세팅하기](#6-nestjs-test-세팅하기)
7. [Coverage 설정하기](#7-coverage-설정하기)
8. [첫 테스트 작성해 보기](#8-첫-테스트-작성해-보기)
9. [에러 던지는 케이스 테스트하기](#9-에러-던지는-케이스-테스트하기)
10. [remove() 함수 테스트하기](#10-remove-함수-테스트하기)
11. [create() 함수 테스트하기](#11-create-함수-테스트하기)
12. [update() 함수 테스트하기](#12-update-함수-테스트하기)
13. [UserController 테스트하기](#13-usercontroller-테스트하기)

---

## 1. 테스트 이론 (개요 및 Matcher 함수)

### 1.1 테스트란?

**테스트(Test)**는 소프트웨어의 기능이 의도한 대로 작동하는지 확인하는 과정입니다. 코드의 정확성, 안정성, 품질을 보장하기 위해 작성됩니다.

#### 테스트의 목적

1. **버그 조기 발견**: 코드 변경 시 예상치 못한 오류를 빠르게 발견
2. **리팩토링 안전성**: 코드 구조를 개선할 때 기존 기능이 깨지지 않음을 보장
3. **문서화**: 테스트 코드 자체가 코드의 사용법을 설명하는 문서 역할
4. **신뢰성 향상**: 배포 전에 코드의 정확성을 검증

### 1.2 Jest란?

**Jest**는 Facebook에서 개발한 JavaScript 테스트 프레임워크입니다. NestJS는 기본적으로 Jest를 사용합니다.

#### Jest의 특징

- **Zero Configuration**: 별도 설정 없이 바로 사용 가능
- **Fast**: 병렬 실행으로 빠른 테스트 수행
- **Snapshot Testing**: 컴포넌트의 출력을 저장하고 비교
- **Mocking**: 함수, 모듈, 타이머 등을 쉽게 모킹
- **Coverage**: 코드 커버리지 자동 측정

### 1.3 Jest 기본 구조

```typescript
describe('테스트 그룹 이름', () => {
  it('테스트 케이스 설명', () => {
    // Arrange (준비)
    const input = 1;
    
    // Act (실행)
    const result = functionToTest(input);
    
    // Assert (검증)
    expect(result).toBe(2);
  });
});
```

#### 주요 함수

- **`describe()`**: 테스트 그룹을 정의
- **`it()` 또는 `test()`**: 개별 테스트 케이스 정의
- **`expect()`**: 검증할 값을 지정
- **`beforeEach()`**: 각 테스트 전에 실행되는 설정
- **`afterEach()`**: 각 테스트 후에 실행되는 정리
- **`beforeAll()`**: 모든 테스트 전에 한 번 실행
- **`afterAll()`**: 모든 테스트 후에 한 번 실행

### 1.4 Matcher 함수

**Matcher**는 `expect()`와 함께 사용하여 값을 검증하는 함수입니다.

#### 기본 Matcher

##### 1. **`toBe()`** - 정확한 값 비교 (Object.is 사용)

```typescript
expect(1 + 1).toBe(2);
expect('hello').toBe('hello');
expect(true).toBe(true);
```

**주의**: 객체 비교에는 사용하지 않음 (참조 비교)

```typescript
// ❌ 실패
expect({ name: 'John' }).toBe({ name: 'John' });

// ✅ 성공
expect({ name: 'John' }).toEqual({ name: 'John' });
```

##### 2. **`toEqual()`** - 객체의 깊은 비교

```typescript
expect({ name: 'John', age: 30 }).toEqual({ name: 'John', age: 30 });
expect([1, 2, 3]).toEqual([1, 2, 3]);
```

##### 3. **`toBeTruthy()` / `toBeFalsy()`** - Truthy/Falsy 값 검증

```typescript
expect(1).toBeTruthy();
expect(0).toBeFalsy();
expect('').toBeFalsy();
expect(null).toBeFalsy();
expect(undefined).toBeFalsy();
```

##### 4. **`toBeNull()` / `toBeUndefined()`** - null/undefined 검증

```typescript
expect(null).toBeNull();
expect(undefined).toBeUndefined();
```

##### 5. **`toBeDefined()`** - 정의되었는지 검증

```typescript
const value = 1;
expect(value).toBeDefined();
```

#### 숫자 관련 Matcher

##### 6. **`toBeGreaterThan()` / `toBeLessThan()`** - 크기 비교

```typescript
expect(10).toBeGreaterThan(5);
expect(5).toBeLessThan(10);
```

##### 7. **`toBeGreaterThanOrEqual()` / `toBeLessThanOrEqual()`** - 크거나 같음/작거나 같음

```typescript
expect(10).toBeGreaterThanOrEqual(10);
expect(5).toBeLessThanOrEqual(5);
```

##### 8. **`toBeCloseTo()`** - 부동소수점 근사값 비교

```typescript
expect(0.1 + 0.2).toBeCloseTo(0.3); // 부동소수점 오차 해결
```

#### 문자열 관련 Matcher

##### 9. **`toMatch()`** - 정규식 매칭

```typescript
expect('Hello World').toMatch(/World/);
expect('test@example.com').toMatch(/^[\w-]+@[\w-]+\.[\w-]+$/);
```

##### 10. **`toContain()`** - 배열/문자열 포함 여부

```typescript
expect(['apple', 'banana', 'orange']).toContain('banana');
expect('Hello World').toContain('World');
```

#### 배열 관련 Matcher

##### 11. **`toHaveLength()`** - 길이 검증

```typescript
expect([1, 2, 3]).toHaveLength(3);
expect('hello').toHaveLength(5);
```

##### 12. **`toContainEqual()`** - 배열에 객체 포함 여부

```typescript
expect([{ id: 1 }, { id: 2 }]).toContainEqual({ id: 1 });
```

#### 객체 관련 Matcher

##### 13. **`toHaveProperty()`** - 속성 존재 여부

```typescript
expect({ name: 'John', age: 30 }).toHaveProperty('name');
expect({ name: 'John', age: 30 }).toHaveProperty('age', 30);
```

##### 14. **`toMatchObject()`** - 객체 부분 매칭

```typescript
expect({ name: 'John', age: 30, city: 'Seoul' })
  .toMatchObject({ name: 'John', age: 30 });
```

#### 예외 처리 Matcher

##### 15. **`toThrow()`** - 예외 발생 검증

```typescript
function throwError() {
  throw new Error('Something went wrong');
}

expect(() => throwError()).toThrow();
expect(() => throwError()).toThrow('Something went wrong');
expect(() => throwError()).toThrow(Error);
```

**주의**: 함수를 직접 호출하지 않고 화살표 함수로 감싸야 함

```typescript
// ❌ 잘못된 사용
expect(throwError()).toThrow(); // 이미 에러가 발생함

// ✅ 올바른 사용
expect(() => throwError()).toThrow();
```

#### 부정 Matcher

모든 Matcher 앞에 `.not`을 붙여 반대 검증 가능

```typescript
expect(1).not.toBe(2);
expect(null).not.toBeDefined();
expect([1, 2, 3]).not.toContain(4);
```

### 1.5 비동기 테스트

#### Promise 반환

```typescript
it('should return a promise', async () => {
  const result = await asyncFunction();
  expect(result).toBe(expectedValue);
});
```

#### Promise Rejection 검증

```typescript
it('should throw an error', async () => {
  await expect(asyncFunction()).rejects.toThrow(Error);
});

// 또는 return 사용
it('should throw an error', () => {
  return expect(asyncFunction()).rejects.toThrow(Error);
});
```

### 1.6 테스트 작성 패턴 (AAA Pattern)

**AAA Pattern**은 테스트를 세 단계로 나누는 패턴입니다:

1. **Arrange (준비)**: 테스트에 필요한 데이터와 객체 준비
2. **Act (실행)**: 테스트할 함수나 메서드 실행
3. **Assert (검증)**: 결과를 검증

```typescript
it('should add two numbers', () => {
  // Arrange
  const a = 1;
  const b = 2;
  
  // Act
  const result = add(a, b);
  
  // Assert
  expect(result).toBe(3);
});
```

---

## 2. Mock vs Stub vs Fake 이론

### 2.1 테스트 더블(Test Double)이란?

**테스트 더블**은 실제 객체를 대체하여 테스트를 더 쉽게 만드는 객체입니다. 실제 객체를 사용하기 어려운 경우(데이터베이스, 네트워크, 파일 시스템 등)에 사용합니다.

### 2.2 Mock

**Mock**은 호출을 기록하고 검증하는 객체입니다. 메서드가 호출되었는지, 몇 번 호출되었는지, 어떤 인자로 호출되었는지 확인할 수 있습니다.

#### Mock의 특징

- **행위 검증**: 메서드 호출 여부와 호출 방식 검증
- **상호작용 테스트**: 객체 간의 상호작용을 테스트
- **호출 기록**: 모든 호출을 기록하고 나중에 검증

#### Mock 예제

```typescript
const mockUserService = {
  create: jest.fn(),
  findAll: jest.fn(),
};

// Mock 설정
mockUserService.create.mockResolvedValue({ id: 1, name: 'John' });

// 사용
await userController.create({ name: 'John' });

// 검증
expect(mockUserService.create).toHaveBeenCalled();
expect(mockUserService.create).toHaveBeenCalledWith({ name: 'John' });
expect(mockUserService.create).toHaveBeenCalledTimes(1);
```

### 2.3 Stub

**Stub**은 미리 정의된 응답을 반환하는 객체입니다. 실제 로직은 없고, 테스트에 필요한 값만 반환합니다.

#### Stub의 특징

- **상태 검증**: 반환값을 검증
- **간단한 구현**: 최소한의 구현만 제공
- **예측 가능한 응답**: 항상 동일한 응답 반환

#### Stub 예제

```typescript
const stubUserRepository = {
  findOne: jest.fn().mockResolvedValue({ id: 1, name: 'John' }),
  findAll: jest.fn().mockResolvedValue([
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' },
  ]),
};

// 사용 - 항상 동일한 값 반환
const user = await stubUserRepository.findOne({ where: { id: 1 } });
expect(user).toEqual({ id: 1, name: 'John' });
```

### 2.4 Fake

**Fake**는 실제 구현과 유사하지만 단순화된 버전입니다. 실제 로직을 구현하지만 프로덕션 환경에서는 사용하지 않습니다.

#### Fake의 특징

- **실제 로직 구현**: 실제 객체와 유사한 동작
- **단순화**: 복잡한 부분은 제거
- **인메모리 구현**: 데이터베이스 대신 메모리 사용

#### Fake 예제

```typescript
class FakeUserRepository {
  private users: User[] = [];

  async save(user: User): Promise<User> {
    const newUser = { ...user, id: this.users.length + 1 };
    this.users.push(newUser);
    return newUser;
  }

  async findOne(options: { where: { id: number } }): Promise<User | null> {
    return this.users.find(u => u.id === options.where.id) || null;
  }

  async findAll(): Promise<User[]> {
    return [...this.users];
  }
}
```

### 2.5 비교표

| 구분 | Mock | Stub | Fake |
|------|------|------|------|
| **목적** | 호출 검증 | 값 반환 | 실제 로직 구현 |
| **검증 방식** | 행위 검증 | 상태 검증 | 상태 검증 |
| **구현 복잡도** | 낮음 | 낮음 | 높음 |
| **사용 시기** | 상호작용 테스트 | 단순 값 반환 | 실제 로직 필요 |

### 2.6 언제 무엇을 사용할까?

#### Mock 사용 시기

- 메서드가 호출되었는지 확인하고 싶을 때
- 호출 횟수나 인자를 검증하고 싶을 때
- 외부 의존성과의 상호작용을 테스트할 때

```typescript
it('should call userService.create', async () => {
  const mockUserService = { create: jest.fn() };
  await userController.create({ name: 'John' });
  expect(mockUserService.create).toHaveBeenCalled();
});
```

#### Stub 사용 시기

- 특정 값을 반환해야 할 때
- 외부 의존성의 응답을 시뮬레이션할 때
- 테스트를 빠르게 실행하고 싶을 때

```typescript
it('should return user list', async () => {
  const stubUserService = {
    findAll: jest.fn().mockResolvedValue([{ id: 1, name: 'John' }]),
  };
  const result = await userController.findAll();
  expect(result).toEqual([{ id: 1, name: 'John' }]);
});
```

#### Fake 사용 시기

- 실제 로직이 필요할 때
- 통합 테스트를 작성할 때
- 실제 객체와 유사한 동작이 필요할 때

```typescript
it('should save and retrieve user', async () => {
  const fakeRepository = new FakeUserRepository();
  const user = await fakeRepository.save({ name: 'John' });
  const found = await fakeRepository.findOne({ where: { id: user.id } });
  expect(found).toEqual(user);
});
```

---

## 3. Mock Function 이론

### 3.1 Mock Function이란?

**Mock Function**은 실제 함수를 대체하여 호출을 추적하고 제어할 수 있는 함수입니다. Jest는 `jest.fn()`을 제공합니다.

### 3.2 jest.fn() 기본 사용법

```typescript
const mockFn = jest.fn();

// 호출
mockFn();
mockFn('arg1', 'arg2');

// 검증
expect(mockFn).toHaveBeenCalled();
expect(mockFn).toHaveBeenCalledTimes(2);
expect(mockFn).toHaveBeenCalledWith('arg1', 'arg2');
expect(mockFn).toHaveBeenNthCalledWith(1); // 첫 번째 호출
expect(mockFn).toHaveBeenNthCalledWith(2, 'arg1', 'arg2'); // 두 번째 호출
```

### 3.3 Mock 구현 설정

#### mockReturnValue - 동기 값 반환

```typescript
const mockFn = jest.fn();
mockFn.mockReturnValue(42);

expect(mockFn()).toBe(42);
```

#### mockResolvedValue - Promise resolve

```typescript
const mockFn = jest.fn();
mockFn.mockResolvedValue({ id: 1, name: 'John' });

const result = await mockFn();
expect(result).toEqual({ id: 1, name: 'John' });
```

#### mockRejectedValue - Promise reject

```typescript
const mockFn = jest.fn();
mockFn.mockRejectedValue(new Error('Something went wrong'));

await expect(mockFn()).rejects.toThrow('Something went wrong');
```

#### mockImplementation - 커스텀 구현

```typescript
const mockFn = jest.fn();
mockFn.mockImplementation((a, b) => a + b);

expect(mockFn(1, 2)).toBe(3);
```

#### mockImplementationOnce - 한 번만 특정 구현

```typescript
const mockFn = jest.fn();
mockFn
  .mockImplementationOnce(() => 'first call')
  .mockImplementationOnce(() => 'second call')
  .mockReturnValue('default');

expect(mockFn()).toBe('first call');
expect(mockFn()).toBe('second call');
expect(mockFn()).toBe('default');
```

### 3.4 jest.spyOn() - 기존 함수 감시

**`jest.spyOn()`**은 기존 객체의 메서드를 감시하면서 원래 구현을 유지하거나 대체할 수 있습니다.

#### 기본 사용법

```typescript
const obj = {
  method: () => 'original',
};

const spy = jest.spyOn(obj, 'method');

// 원래 구현 유지
expect(obj.method()).toBe('original');
expect(spy).toHaveBeenCalled();

// 구현 대체
spy.mockReturnValue('mocked');
expect(obj.method()).toBe('mocked');

// 원래 구현 복원
spy.mockRestore();
expect(obj.method()).toBe('original');
```

#### 실제 사용 예제

```typescript
describe('UserService', () => {
  let userService: UserService;
  let userRepository: Repository<User>;

  beforeEach(() => {
    // Repository의 findOne 메서드를 spy
    jest.spyOn(userRepository, 'findOne').mockResolvedValue({
      id: 1,
      name: 'John',
    });
  });

  it('should find user', async () => {
    const user = await userService.findOne(1);
    expect(userRepository.findOne).toHaveBeenCalledWith({ where: { id: 1 } });
    expect(user).toEqual({ id: 1, name: 'John' });
  });
});
```

### 3.5 Mock 초기화 및 정리

#### mockClear() - 호출 기록만 지움

```typescript
mockFn.mockClear(); // 호출 기록만 지움, 구현은 유지
```

#### mockReset() - 호출 기록과 구현 모두 초기화

```typescript
mockFn.mockReset(); // 호출 기록과 구현 모두 초기화
```

#### mockRestore() - 원래 구현 복원 (spy만)

```typescript
const spy = jest.spyOn(obj, 'method');
spy.mockRestore(); // 원래 구현으로 복원
```

#### clearAllMocks() - 모든 mock의 호출 기록 지움

```typescript
beforeEach(() => {
  jest.clearAllMocks();
});
```

#### resetAllMocks() - 모든 mock 초기화

```typescript
beforeEach(() => {
  jest.resetAllMocks();
});
```

#### restoreAllMocks() - 모든 spy 복원

```typescript
afterEach(() => {
  jest.restoreAllMocks();
});
```

### 3.6 Mock 함수의 속성

```typescript
const mockFn = jest.fn();

// 호출 정보 접근
mockFn.mock.calls; // 모든 호출의 인자 배열
mockFn.mock.results; // 모든 호출의 결과 배열
mockFn.mock.instances; // 모든 호출의 this 컨텍스트

// 예제
mockFn('arg1', 'arg2');
mockFn('arg3');

console.log(mockFn.mock.calls);
// [[ 'arg1', 'arg2' ], [ 'arg3' ]]

console.log(mockFn.mock.results);
// [{ type: 'return', value: undefined }, { type: 'return', value: undefined }]
```

### 3.7 모듈 Mock

#### jest.mock() - 모듈 전체 Mock

```typescript
jest.mock('./user.service', () => ({
  UserService: jest.fn().mockImplementation(() => ({
    create: jest.fn(),
    findAll: jest.fn(),
  })),
}));
```

#### 부분 Mock

```typescript
jest.mock('bcrypt', () => ({
  hash: jest.fn(),
  compare: jest.fn(),
}));
```

---

## 4. Testing의 종류 이론

### 4.1 테스트 피라미드

테스트는 일반적으로 피라미드 형태로 구성됩니다:

```
        /\
       /  \  E2E Tests (소수)
      /____\
     /      \  Integration Tests (중간)
    /________\
   /          \  Unit Tests (다수)
  /____________\
```

### 4.2 Unit Test (단위 테스트)

**Unit Test**는 개별 함수나 메서드를 독립적으로 테스트합니다.

#### 특징

- **빠름**: 실행 시간이 매우 짧음
- **격리**: 다른 코드와 독립적으로 실행
- **다수**: 가장 많은 테스트
- **Mock 사용**: 외부 의존성은 Mock으로 대체

#### 예제

```typescript
describe('Calculator', () => {
  it('should add two numbers', () => {
    expect(add(1, 2)).toBe(3);
  });

  it('should subtract two numbers', () => {
    expect(subtract(5, 2)).toBe(3);
  });
});
```

### 4.3 Integration Test (통합 테스트)

**Integration Test**는 여러 컴포넌트가 함께 작동하는지 테스트합니다.

#### 특징

- **상호작용**: 여러 모듈 간의 상호작용 테스트
- **실제 의존성**: 일부 실제 의존성 사용 (예: 테스트 데이터베이스)
- **중간 속도**: Unit Test보다 느리지만 E2E보다 빠름

#### 예제

```typescript
describe('UserService Integration', () => {
  it('should create and find user', async () => {
    // 실제 데이터베이스 사용
    const user = await userService.create({ name: 'John' });
    const found = await userService.findOne(user.id);
    expect(found).toEqual(user);
  });
});
```

### 4.4 E2E Test (End-to-End Test)

**E2E Test**는 전체 시스템을 사용자 관점에서 테스트합니다.

#### 특징

- **전체 시스템**: 모든 레이어 포함
- **실제 환경**: 실제 데이터베이스, 실제 API 사용
- **느림**: 가장 느린 테스트
- **소수**: 가장 적은 수의 테스트

#### 예제 (NestJS)

```typescript
describe('User E2E', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/user (POST)', () => {
    return request(app.getHttpServer())
      .post('/user')
      .send({ name: 'John' })
      .expect(201)
      .expect({ id: 1, name: 'John' });
  });
});
```

### 4.5 테스트 종류 비교표

| 구분 | Unit Test | Integration Test | E2E Test |
|------|-----------|------------------|----------|
| **범위** | 단일 함수/메서드 | 여러 모듈 | 전체 시스템 |
| **속도** | 매우 빠름 | 중간 | 느림 |
| **의존성** | 모두 Mock | 일부 실제 | 모두 실제 |
| **개수** | 많음 | 중간 | 적음 |
| **목적** | 로직 검증 | 상호작용 검증 | 사용자 시나리오 검증 |

### 4.6 테스트 전략

#### 1. Unit Test 우선

- 가장 많은 테스트 작성
- 빠른 피드백 제공
- 버그 조기 발견

#### 2. Integration Test 보완

- 중요한 상호작용 테스트
- 실제 의존성과의 통합 검증

#### 3. E2E Test 핵심 시나리오

- 주요 사용자 플로우만 테스트
- 회귀 테스트에 활용

---

## 5. Test 코드 예제 이론

### 5.1 NestJS 테스트 구조

NestJS는 Jest를 기본 테스트 프레임워크로 사용하며, `@nestjs/testing` 패키지를 제공합니다.

### 5.2 Service 테스트 예제

#### 기본 구조

```typescript
import { Test, TestingModule } from '@nestjs/testing';
import { UserService } from './user.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { User } from './entity/user.entity';

describe('UserService', () => {
  let service: UserService;
  let repository: Repository<User>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserService,
        {
          provide: getRepositoryToken(User),
          useValue: {
            findOne: jest.fn(),
            save: jest.fn(),
            find: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<UserService>(UserService);
    repository = module.get<Repository<User>>(getRepositoryToken(User));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
```

#### 실제 테스트 예제

```typescript
describe('UserService', () => {
  let service: UserService;
  const mockRepository = {
    findOne: jest.fn(),
    save: jest.fn(),
    find: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserService,
        {
          provide: getRepositoryToken(User),
          useValue: mockRepository,
        },
      ],
    }).compile();

    service = module.get<UserService>(UserService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('create', () => {
    it('should create a user', async () => {
      const createUserDto = { email: 'test@test.com', password: '123' };
      const savedUser = { id: 1, ...createUserDto };

      mockRepository.findOne.mockResolvedValue(null);
      mockRepository.save.mockResolvedValue(savedUser);
      mockRepository.findOne.mockResolvedValue(savedUser);

      const result = await service.create(createUserDto);

      expect(result).toEqual(savedUser);
      expect(mockRepository.save).toHaveBeenCalled();
    });
  });
});
```

### 5.3 Controller 테스트 예제

```typescript
import { Test, TestingModule } from '@nestjs/testing';
import { UserController } from './user.controller';
import { UserService } from './user.service';

describe('UserController', () => {
  let controller: UserController;
  const mockUserService = {
    create: jest.fn(),
    findAll: jest.fn(),
    findOne: jest.fn(),
    update: jest.fn(),
    remove: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserController],
      providers: [
        {
          provide: UserService,
          useValue: mockUserService,
        },
      ],
    }).compile();

    controller = module.get<UserController>(UserController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('should create a user', async () => {
      const createUserDto = { email: 'test@test.com', password: '123' };
      const user = { id: 1, ...createUserDto };

      mockUserService.create.mockResolvedValue(user);

      const result = await controller.create(createUserDto);

      expect(result).toEqual(user);
      expect(mockUserService.create).toHaveBeenCalledWith(createUserDto);
    });
  });
});
```

### 5.4 테스트 작성 Best Practices

#### 1. 명확한 테스트 이름

```typescript
// ❌ 나쁜 예
it('test create', () => { ... });

// ✅ 좋은 예
it('should create a user and return it', () => { ... });
it('should throw BadRequestException if email already exists', () => { ... });
```

#### 2. 하나의 테스트는 하나의 동작만 검증

```typescript
// ❌ 나쁜 예
it('should create and update user', () => {
  // create 테스트
  // update 테스트
});

// ✅ 좋은 예
it('should create a user', () => { ... });
it('should update a user', () => { ... });
```

#### 3. Arrange-Act-Assert 패턴 사용

```typescript
it('should add two numbers', () => {
  // Arrange
  const a = 1;
  const b = 2;
  
  // Act
  const result = add(a, b);
  
  // Assert
  expect(result).toBe(3);
});
```

#### 4. Mock 초기화 및 정리

```typescript
beforeEach(() => {
  jest.clearAllMocks();
});

afterEach(() => {
  jest.restoreAllMocks();
});
```

#### 5. 테스트 격리

각 테스트는 독립적으로 실행되어야 하며, 다른 테스트의 영향을 받지 않아야 합니다.

```typescript
describe('UserService', () => {
  const mockRepository = {
    findOne: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks(); // 각 테스트 전에 초기화
  });
});
```

### 5.5 커버리지 (Coverage)

#### 커버리지 종류

1. **Statements (문장 커버리지)**: 실행된 코드 문장의 비율
2. **Branches (분기 커버리지)**: if/else, switch 등 분기문의 비율
3. **Functions (함수 커버리지)**: 호출된 함수의 비율
4. **Lines (라인 커버리지)**: 실행된 코드 라인의 비율

#### 커버리지 확인

```bash
npm test -- --coverage
```

#### 커버리지 목표

- **Statements**: 80% 이상
- **Branches**: 75% 이상
- **Functions**: 80% 이상
- **Lines**: 80% 이상

### 5.6 테스트 실행

#### 모든 테스트 실행

```bash
npm test
```

#### 특정 파일만 실행

```bash
npm test -- user.service.spec.ts
```

#### Watch 모드

```bash
npm test -- --watch
```

#### 커버리지와 함께 실행

```bash
npm test -- --coverage
```

---

## 정리

### 주요 개념

1. **테스트**: 소프트웨어의 기능 검증
2. **Jest**: JavaScript 테스트 프레임워크
3. **Matcher**: 값을 검증하는 함수
4. **Mock/Stub/Fake**: 테스트 더블의 종류
5. **Mock Function**: 함수를 대체하고 추적
6. **Unit/Integration/E2E Test**: 테스트의 종류

### 테스트 작성 원칙

1. **명확한 이름**: 무엇을 테스트하는지 명확히
2. **독립성**: 각 테스트는 독립적으로 실행
3. **빠른 실행**: 테스트는 빠르게 실행되어야 함
4. **반복 가능**: 항상 동일한 결과
5. **자동화**: CI/CD 파이프라인에 통합

### 실전 팁

1. **AAA 패턴 사용**: Arrange-Act-Assert
2. **Mock 적절히 사용**: 필요한 곳에만 사용
3. **커버리지 목표 설정**: 80% 이상 유지
4. **테스트 격리**: beforeEach/afterEach 활용
5. **명확한 검증**: expect 문을 명확하게 작성

---

## 6. NestJS Test 세팅하기

### 6.1 NestJS 테스트 환경

NestJS는 기본적으로 Jest를 사용하며, `@nestjs/testing` 패키지를 통해 테스트 모듈을 생성합니다.

### 6.2 필요한 패키지

NestJS 프로젝트를 생성하면 자동으로 설치됩니다:

```json
{
  "devDependencies": {
    "@nestjs/testing": "^11.0.1",
    "@types/jest": "^30.0.0",
    "jest": "^30.0.0",
    "ts-jest": "^29.2.5"
  }
}
```

### 6.3 Jest 설정 (package.json)

프로젝트의 `package.json`에 Jest 설정이 포함되어 있습니다:

```json:package.json
{
  "jest": {
    "moduleFileExtensions": ["js", "json", "ts"],
    "roots": ["src"],
    "testRegex": ".*\\.spec\\.ts$",
    "transform": {
      "^.+\\.(t|j)s$": "ts-jest"
    },
    "collectCoverageFrom": ["**/*.(t|j)s"],
    "coveragePathIgnorePatterns": [
      "module.ts",
      "dto.ts",
      "entity.ts"
    ],
    "coverageDirectory": "./coverage",
    "testEnvironment": "node",
    "moduleNameMapper": {
      "^src/(.*)$": "<rootDir>/src/$1"
    }
  }
}
```

#### 주요 설정 설명

- **`testRegex`**: `*.spec.ts` 파일을 테스트 파일로 인식
- **`roots`**: `src` 디렉토리에서 테스트 파일 검색
- **`transform`**: TypeScript 파일을 Jest가 실행할 수 있도록 변환
- **`moduleNameMapper`**: `src/` 경로를 절대 경로로 매핑
- **`coveragePathIgnorePatterns`**: 커버리지에서 제외할 파일 패턴

### 6.4 테스트 스크립트

```json:package.json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch",
    "test:cov": "jest --coverage",
    "test:user": "jest --testPathPatterns=src/user --coverage --collectCoverageFrom=src/user/**"
  }
}
```

#### 스크립트 설명

- **`test`**: 모든 테스트 실행
- **`test:watch`**: 파일 변경 시 자동으로 테스트 재실행
- **`test:cov`**: 커버리지 리포트 생성
- **`test:user`**: 특정 경로의 테스트만 실행하고 커버리지 측정

### 6.5 테스트 모듈 생성

NestJS에서는 `Test.createTestingModule()`을 사용하여 테스트 모듈을 생성합니다:

```typescript
import { Test, TestingModule } from '@nestjs/testing';

describe('UserService', () => {
  let service: UserService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserService,
        // Mock providers
      ],
    }).compile();

    service = module.get<UserService>(UserService);
  });
});
```

---

## 7. Coverage 설정하기

### 7.1 커버리지란?

**커버리지(Coverage)**는 테스트가 실행한 코드의 비율을 나타냅니다. 코드의 어느 부분이 테스트되었는지 확인할 수 있습니다.

### 7.2 커버리지 종류

1. **Statements (문장 커버리지)**: 실행된 코드 문장의 비율
2. **Branches (분기 커버리지)**: if/else, switch 등 분기문의 비율
3. **Functions (함수 커버리지)**: 호출된 함수의 비율
4. **Lines (라인 커버리지)**: 실행된 코드 라인의 비율

### 7.3 커버리지 설정

#### package.json 설정

```json:package.json
{
  "jest": {
    "collectCoverageFrom": [
      "**/*.(t|j)s"
    ],
    "coveragePathIgnorePatterns": [
      "module.ts",
      "dto.ts",
      "entity.ts"
    ],
    "coverageDirectory": "./coverage"
  }
}
```

#### 설정 설명

- **`collectCoverageFrom`**: 커버리지를 수집할 파일 패턴
- **`coveragePathIgnorePatterns`**: 커버리지에서 제외할 파일
  - `module.ts`: 모듈 정의 파일 (의존성 주입만 담당)
  - `dto.ts`: 데이터 전송 객체 (검증 로직만)
  - `entity.ts`: 엔티티 정의 (타입 정의만)
- **`coverageDirectory`**: 커버리지 리포트 저장 경로

### 7.4 커버리지 실행

```bash
# 전체 커버리지
npm test -- --coverage

# 특정 모듈만 커버리지
npm run test:user
```

### 7.5 커버리지 리포트 확인

커버리지를 실행하면 `coverage` 디렉토리에 HTML 리포트가 생성됩니다:

```
coverage/
  ├── lcov-report/
  │   └── index.html  # 브라우저에서 열어서 확인
  └── lcov.info
```

#### 커버리지 목표

일반적으로 다음 목표를 설정합니다:

- **Statements**: 80% 이상
- **Branches**: 75% 이상
- **Functions**: 80% 이상
- **Lines**: 80% 이상

---

## 8. 첫 테스트 작성해 보기

### 8.1 기본 테스트 구조

가장 간단한 테스트는 서비스가 정의되었는지 확인하는 것입니다.

#### UserService 기본 테스트

```typescript:src/user/user.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { UserService } from './user.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { User } from './entity/user.entity';
import { ConfigService } from '@nestjs/config';

const mockUserRepository = {
  findOne: jest.fn(),
  save: jest.fn(),
  find: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
};

const mockConfigService = {
  get: jest.fn(),
};

describe('UserService', () => {
  let userService: UserService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserService,
        {
          provide: getRepositoryToken(User),
          useValue: mockUserRepository,
        },
        {
          provide: ConfigService,
          useValue: mockConfigService,
        },
      ],
    }).compile();

    userService = module.get<UserService>(UserService);
  });

  it('should be defined', () => {
    expect(userService).toBeDefined();
  });
});
```

### 8.2 Mock Repository 설정

TypeORM Repository를 Mock으로 대체합니다:

```typescript
const mockUserRepository = {
  findOne: jest.fn(),
  save: jest.fn(),
  find: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
};
```

#### getRepositoryToken 사용

```typescript
{
  provide: getRepositoryToken(User),
  useValue: mockUserRepository,
}
```

`getRepositoryToken()`은 TypeORM이 내부적으로 사용하는 토큰을 생성합니다.

### 8.3 findAll() 테스트

가장 간단한 메서드부터 테스트합니다:

```typescript:src/user/user.service.spec.ts
describe('findAll', () => {
  it('should return all users', async () => {
    const users = [
      {
        id: 1,
        email: 'test@codefactory.ai',
      },
    ];
    mockUserRepository.find.mockResolvedValue(users);

    const result = await userService.findAll();

    expect(result).toEqual(users);
    expect(mockUserRepository.find).toHaveBeenCalled();
  });
});
```

#### 테스트 단계

1. **Arrange**: Mock 데이터 준비 및 Mock 함수 설정
2. **Act**: 테스트할 메서드 실행
3. **Assert**: 결과 검증 및 Mock 호출 확인

---

## 9. 에러 던지는 케이스 테스트하기

### 9.1 예외 처리 테스트

메서드가 예외를 던지는 경우를 테스트합니다.

### 9.2 findOne() 에러 케이스

사용자를 찾을 수 없을 때 `NotFoundException`을 던지는지 테스트:

```typescript:src/user/user.service.spec.ts
describe('findOne', () => {
  it('should throw a NotFoundException if user is not found', async () => {
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(null);

    expect(userService.findOne(999)).rejects.toThrow(NotFoundException);
    expect(mockUserRepository.findOne).toHaveBeenCalledWith({
      where: {
        id: 999,
      },
    });
  });
});
```

#### 주요 포인트

- **`mockResolvedValue(null)`**: Repository가 `null`을 반환하도록 설정
- **`rejects.toThrow()`**: Promise가 reject되고 특정 예외를 던지는지 검증
- **`toHaveBeenCalledWith()`**: 올바른 인자로 호출되었는지 확인

### 9.3 create() 에러 케이스

이메일이 이미 존재할 때 `BadRequestException`을 던지는지 테스트:

```typescript:src/user/user.service.spec.ts
describe('create', () => {
  it('should throw a BadRequestException if email already exists', () => {
    const createUserDto: CreateUserDto = {
      email: 'test@codefactory.ai',
      password: '123123',
    };

    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue({
      id: 1,
      email: createUserDto.email,
    });

    expect(userService.create(createUserDto)).rejects.toThrow(
      BadRequestException,
    );
    expect(mockUserRepository.findOne).toHaveBeenCalledWith({
      where: { email: createUserDto.email },
    });
  });
});
```

### 9.4 예외 테스트 패턴

#### Promise Rejection 테스트

```typescript
// 방법 1: return 사용
it('should throw error', () => {
  return expect(asyncFunction()).rejects.toThrow(Error);
});

// 방법 2: async/await 사용
it('should throw error', async () => {
  await expect(asyncFunction()).rejects.toThrow(Error);
});
```

---

## 10. remove() 함수 테스트하기

### 10.1 remove() 메서드 분석

```typescript:src/user/user.service.ts
async remove(id: number) {
  const user = await this.userRepository.findOne({ where: { id } });

  if (!user) {
    throw new NotFoundException(`User with ID ${id} not found`);
  }
  await this.userRepository.delete(id);

  return id;
}
```

### 10.2 성공 케이스 테스트

사용자가 존재할 때 삭제하고 ID를 반환하는지 테스트:

```typescript:src/user/user.service.spec.ts
describe('remove', () => {
  it('should delete a user by id', async () => {
    const id = 999;

    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue({
      id: 1,
    });

    const result = await userService.remove(id);

    expect(result).toEqual(id);
    expect(mockUserRepository.findOne).toHaveBeenCalledWith({
      where: {
        id,
      },
    });
  });
});
```

#### 테스트 검증

1. **반환값 검증**: `id`가 반환되는지 확인
2. **호출 검증**: `findOne`이 올바른 인자로 호출되었는지 확인
3. **삭제 호출**: `delete` 메서드가 호출되었는지 확인 (선택적)

### 10.3 에러 케이스 테스트

사용자가 없을 때 `NotFoundException`을 던지는지 테스트:

```typescript:src/user/user.service.spec.ts
it('should throw a NotFoundException if user to delete is not found', () => {
  jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(null);

  expect(userService.remove(999)).rejects.toThrow(NotFoundException);
  expect(mockUserRepository.findOne).toHaveBeenCalledWith({
    where: {
      id: 999,
    },
  });
});
```

---

## 11. create() 함수 테스트하기

### 11.1 create() 메서드 분석

```typescript:src/user/user.service.ts
async create(createUserDto: CreateUserDto) {
  const { email, password } = createUserDto;

  const user = await this.userRepository.findOne({ where: { email } });

  if (user) {
    throw new BadRequestException('User already exists');
  }

  const hash = await bcrypt.hash(
    password,
    this.configService.get<number>(envVariableKeys.hashRounds)!,
  );

  await this.userRepository.save({ email, password: hash });

  return this.userRepository.findOne({ where: { email } });
}
```

### 11.2 Mock 설정

`create()` 메서드는 여러 의존성을 사용하므로 Mock 설정이 필요합니다:

```typescript:src/user/user.service.spec.ts
jest.mock('bcrypt', () => ({
  hash: jest.fn(),
}));

const mockConfigService = {
  get: jest.fn(),
};
```

### 11.3 성공 케이스 테스트

```typescript:src/user/user.service.spec.ts
describe('create', () => {
  it('should create a new user and return it', async () => {
    const createUserDto: CreateUserDto = {
      email: 'test@codefactory.ai',
      password: '123123',
    };
    const hashRounds = 10;
    const hashedPassword = 'hashashhashhcivhasdf';
    const result = {
      id: 1,
      email: createUserDto.email,
      password: hashedPassword,
    };

    // 첫 번째 findOne: 이메일 중복 체크 (null 반환)
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValueOnce(null);
    
    // ConfigService Mock
    jest.spyOn(mockConfigService, 'get').mockReturnValue(hashRounds);
    
    // bcrypt.hash Mock
    jest.spyOn(bcrypt, 'hash').mockImplementation(() => hashedPassword);
    
    // 두 번째 findOne: 생성된 사용자 반환
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValueOnce(result);

    const createdUser = await userService.create(createUserDto);

    // 검증
    expect(createdUser).toEqual(result);
    expect(mockUserRepository.findOne).toHaveBeenNthCalledWith(1, {
      where: { email: createUserDto.email },
    });
    expect(mockUserRepository.findOne).toHaveBeenNthCalledWith(2, {
      where: { email: createUserDto.email },
    });
    expect(mockConfigService.get).toHaveBeenCalledWith(expect.anything());
    expect(bcrypt.hash).toHaveBeenCalledWith(
      createUserDto.password,
      hashRounds,
    );
    expect(mockUserRepository.save).toHaveBeenCalledWith({
      email: createUserDto.email,
      password: hashedPassword,
    });
  });
});
```

#### 주요 포인트

1. **`mockResolvedValueOnce()`**: 각 호출마다 다른 값을 반환
2. **`toHaveBeenNthCalledWith()`**: N번째 호출의 인자 검증
3. **`expect.anything()`**: 어떤 값이든 허용
4. **bcrypt Mock**: `jest.mock()`으로 모듈 전체 Mock

### 11.4 에러 케이스 테스트

이메일이 이미 존재할 때:

```typescript:src/user/user.service.spec.ts
it('should throw a BadRequestException if email already exists', () => {
  const createUserDto: CreateUserDto = {
    email: 'test@codefactory.ai',
    password: '123123',
  };

  jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue({
    id: 1,
    email: createUserDto.email,
  });

  expect(userService.create(createUserDto)).rejects.toThrow(
    BadRequestException,
  );
  expect(mockUserRepository.findOne).toHaveBeenCalledWith({
    where: { email: createUserDto.email },
  });
});
```

---

## 12. update() 함수 테스트하기

### 12.1 update() 메서드 분석

```typescript:src/user/user.service.ts
async update(id: number, updateUserDto: UpdateUserDto) {
  const user = await this.userRepository.findOne({ where: { id } });

  if (!user) {
    throw new NotFoundException(`User with ID ${id} not found`);
  }

  const { password, ...rest } = updateUserDto;

  const updateData: Partial<User> = { ...rest };

  if (password) {
    const hash = await bcrypt.hash(
      password,
      this.configService.get<number>(envVariableKeys.hashRounds)!,
    );
    updateData.password = hash;
  }

  await this.userRepository.update({ id }, updateData);

  return this.userRepository.findOne({ where: { id } });
}
```

### 12.2 성공 케이스 테스트 (password 포함)

```typescript:src/user/user.service.spec.ts
describe('update', () => {
  it('should update a user if it exists and return the updated user', async () => {
    const updateUserDto: UpdateUserDto = {
      email: 'test@codefactory.ai',
      password: '123123',
    };
    const hashRounds = 10;
    const hashedPassword = 'hashashndvizxcjnvkolisadf';
    const user = {
      id: 1,
      email: updateUserDto.email,
    };

    // 첫 번째 findOne: 사용자 존재 확인
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValueOnce(user);
    
    // ConfigService Mock
    jest.spyOn(mockConfigService, 'get').mockReturnValue(hashRounds);
    
    // bcrypt.hash Mock
    jest.spyOn(bcrypt, 'hash').mockImplementation(() => hashedPassword);
    
    // update Mock
    jest.spyOn(mockUserRepository, 'update').mockResolvedValue(undefined);
    
    // 두 번째 findOne: 업데이트된 사용자 반환
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValueOnce({
      ...user,
      password: hashedPassword,
    });

    const result = await userService.update(1, updateUserDto);

    expect(result).toEqual({
      ...user,
      password: hashedPassword,
    });
    expect(mockUserRepository.findOne).toHaveBeenCalledWith({
      where: {
        id: 1,
      },
    });
    expect(bcrypt.hash).toHaveBeenCalledWith(
      updateUserDto.password,
      hashRounds,
    );
    expect(mockUserRepository.update).toHaveBeenCalledWith(
      {
        id: 1,
      },
      {
        ...updateUserDto,
        password: hashedPassword,
      },
    );
  });
});
```

### 12.3 에러 케이스 테스트

사용자가 없을 때:

```typescript:src/user/user.service.spec.ts
it('should throw a NotFoundException if user to update is not found', async () => {
  jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(null);

  const updateUserDto: UpdateUserDto = {
    email: 'test@codefactory.ai',
    password: '123123',
  };

  expect(userService.update(999, updateUserDto)).rejects.toThrow(
    NotFoundException,
  );
  expect(mockUserRepository.findOne).toHaveBeenCalledWith({
    where: {
      id: 999,
    },
  });
  expect(mockUserRepository.update).not.toHaveBeenCalled();
});
```

#### 주요 포인트

- **`not.toHaveBeenCalled()`**: 메서드가 호출되지 않았는지 검증
- **조건부 로직**: `password`가 있을 때만 해시하는 로직 테스트

---

## 13. UserController 테스트하기

### 13.1 Controller 테스트 구조

Controller는 Service에 의존하므로 Service를 Mock으로 대체합니다.

### 13.2 기본 설정

```typescript:src/user/user.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

const mockedUserService = {
  create: jest.fn(),
  findAll: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  remove: jest.fn(),
};

describe('UserController', () => {
  let userController: UserController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserController],
      providers: [
        {
          provide: UserService,
          useValue: mockedUserService,
        },
      ],
    }).compile();

    userController = module.get<UserController>(UserController);
  });

  it('should be defined', () => {
    expect(userController).toBeDefined();
  });
});
```

### 13.3 create() 테스트

```typescript:src/user/user.controller.spec.ts
describe('create', () => {
  it('should return correct value', async () => {
    const createUserDto: CreateUserDto = {
      email: 'test@codefactory.ai',
      password: '123123',
    };

    const user = {
      id: 1,
      ...createUserDto,
      password: 'asdvixczjvilsjadf',
    };

    jest.spyOn(userService, 'create').mockResolvedValue(user as User);

    const result = await userController.create(createUserDto);

    expect(userService.create).toHaveBeenCalledWith(createUserDto);
    expect(result).toEqual(user);
  });
});
```

### 13.4 findAll() 테스트

```typescript:src/user/user.controller.spec.ts
describe('findAll', () => {
  it('should return a list of users', async () => {
    const users = [
      {
        id: 1,
        email: 'test@codefactory.ai',
      },
      {
        id: 2,
        email: 'jc@codefactory.ai',
      },
    ];

    jest.spyOn(userService, 'findAll').mockResolvedValue(users as User[]);

    const result = await userController.findAll();

    expect(userService.findAll).toHaveBeenCalled();
    expect(result).toEqual(users);
  });
});
```

### 13.5 findOne() 테스트

```typescript:src/user/user.controller.spec.ts
describe('findOne', () => {
  it('should return a single user', async () => {
    const user = {
      id: 1,
      email: 'test@codefactory.ai',
    };

    jest.spyOn(userService, 'findOne').mockResolvedValue(user as User);

    const result = await userController.findOne(1);

    expect(userService.findOne).toHaveBeenCalledWith(1);
    expect(result).toEqual(user);
  });
});
```

### 13.6 update() 테스트

```typescript:src/user/user.controller.spec.ts
describe('update', () => {
  it('should return the updated user', async () => {
    const id = 1;
    const updateUserDto: UpdateUserDto = {
      email: 'admin@codefactory.ai',
    };
    const user = {
      id,
      ...updateUserDto,
    };

    jest.spyOn(userService, 'update').mockResolvedValue(user as User);

    const result = await userController.update(1, updateUserDto);

    expect(userService.update).toHaveBeenCalledWith(1, updateUserDto);
    expect(result).toEqual(user);
  });
});
```

### 13.7 remove() 테스트

```typescript:src/user/user.controller.spec.ts
describe('remove', () => {
  it('should return the deleted user id', async () => {
    const id = 1;

    jest.spyOn(userService, 'remove').mockResolvedValue(id);

    const result = await userController.remove(1);

    expect(userService.remove).toHaveBeenCalledWith(1);
    expect(result).toEqual(id);
  });
});
```

### 13.8 Controller 테스트 특징

#### Service Mock 사용

Controller 테스트에서는 Service의 내부 로직을 테스트하지 않고, Controller가 Service를 올바르게 호출하는지만 확인합니다.

```typescript
// Service의 실제 구현은 테스트하지 않음
// Controller가 Service를 올바르게 호출하는지만 확인
expect(userService.create).toHaveBeenCalledWith(createUserDto);
```

#### Mock vs Spy

- **Mock 객체**: `mockedUserService`로 provider 제공
- **Spy**: `jest.spyOn()`으로 호출 추적

---

## 정리

### User Module 테스트 요약

1. **Service 테스트**: 비즈니스 로직과 예외 처리 검증
2. **Controller 테스트**: Service 호출과 응답 전달 검증
3. **Mock 활용**: Repository, ConfigService, bcrypt 등 외부 의존성 Mock
4. **커버리지**: 중요한 로직은 높은 커버리지 유지

### 테스트 작성 순서

1. 기본 테스트 (should be defined)
2. 간단한 메서드 (findAll)
3. 에러 케이스 (NotFoundException, BadRequestException)
4. 복잡한 메서드 (create, update)
5. Controller 테스트

### Best Practices

1. **Mock 초기화**: `afterEach`에서 `jest.clearAllMocks()` 사용
2. **명확한 테스트 이름**: 무엇을 테스트하는지 명확히
3. **AAA 패턴**: Arrange-Act-Assert 구조 유지
4. **독립성**: 각 테스트는 독립적으로 실행 가능해야 함
5. **커버리지 목표**: 80% 이상 유지

---

## 16. Genre Module Unit Test

### 16.1 GenreService 테스트하기

Genre Module은 영화 장르 정보를 관리하는 모듈입니다. CRUD 기능을 테스트합니다.

#### 테스트 모듈 설정

```typescript:src/genre/genre.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { GenreService } from './genre.service';
import { Repository } from 'typeorm';
import { Genre } from './entity/genre.entity';
import { getRepositoryToken } from '@nestjs/typeorm';
import { NotFoundException } from '@nestjs/common';

const mockGenreRepository = {
  save: jest.fn(),
  find: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
};

describe('GenreService', () => {
  let service: GenreService;
  let repository: Repository<Genre>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GenreService,
        {
          provide: getRepositoryToken(Genre),
          useValue: mockGenreRepository,
        },
      ],
    }).compile();

    service = module.get<GenreService>(GenreService);
    repository = module.get<Repository<Genre>>(getRepositoryToken(Genre));
  });

  afterAll(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
```

#### create() 테스트

```typescript:src/genre/genre.service.spec.ts
describe('create', () => {
  it('should create a genre successfully', async () => {
    const createGenreDto = { name: 'Fantasy' };
    const savedGenre = { id: 1, ...createGenreDto };

    jest.spyOn(repository, 'save').mockResolvedValue(savedGenre as Genre);

    const result = await service.create(createGenreDto);

    expect(repository.save).toHaveBeenCalledWith(createGenreDto);
    expect(result).toEqual(savedGenre);
  });
});
```

**주의**: 실제 서비스 코드에서는 중복 체크를 하지만, 테스트에서는 간단하게 작성할 수 있습니다.

#### findAll() 테스트

```typescript:src/genre/genre.service.spec.ts
describe('findAll', () => {
  it('should return an array of genres', async () => {
    const genres = [
      {
        id: 1,
        name: 'Fantasy',
      },
    ];
    jest.spyOn(repository, 'find').mockResolvedValue(genres as Genre[]);

    const result = await service.findAll();

    expect(repository.find).toHaveBeenCalled();
    expect(result).toEqual(genres);
  });
});
```

#### findOne() 테스트

```typescript:src/genre/genre.service.spec.ts
describe('findOne', () => {
  it('should return a genre if found', async () => {
    const genre = { id: 1, name: 'Fantasy' };

    jest.spyOn(repository, 'findOne').mockResolvedValue(genre as Genre);

    const result = await service.findOne(genre.id);

    expect(repository.findOne).toHaveBeenCalledWith({
      where: {
        id: genre.id,
      },
    });
    expect(result).toEqual(genre);
  });

  it('should throw NotFoundException if genre is not found', async () => {
    jest.spyOn(repository, 'findOne').mockResolvedValue(null);

    await expect(service.findOne(1)).rejects.toThrow(NotFoundException);
  });
});
```

#### update() 테스트

```typescript:src/genre/genre.service.spec.ts
describe('update', () => {
  it('should update and return the genre if it exists', async () => {
    const updateGenreDto = {
      name: 'Updated Fantasy',
    };
    const existingGenre = {
      id: 1,
      name: 'Fantasy',
    };
    const updatedGenre = {
      id: 1,
      ...updateGenreDto,
    };

    jest
      .spyOn(repository, 'findOne')
      .mockResolvedValueOnce(existingGenre as Genre)
      .mockResolvedValueOnce(updatedGenre as Genre);

    const result = await service.update(1, updateGenreDto);

    expect(repository.findOne).toHaveBeenCalledWith({
      where: {
        id: 1,
      },
    });
    expect(repository.update).toHaveBeenCalledWith(
      { id: 1 },
      updateGenreDto,
    );
    expect(result).toEqual(updatedGenre);
  });

  it('should throw NotFoundException if genre to update does not exist', async () => {
    jest.spyOn(repository, 'findOne').mockResolvedValue(null);

    await expect(
      service.update(1, { name: 'Updated Fantasy' }),
    ).rejects.toThrow(NotFoundException);
  });
});
```

#### remove() 테스트

```typescript:src/genre/genre.service.spec.ts
describe('remove', () => {
  it('should delete a genre and return the id', async () => {
    const genre = {
      id: 1,
      name: 'Fantasy',
    };

    jest.spyOn(repository, 'findOne').mockResolvedValue(genre as Genre);

    const result = await service.remove(1);

    expect(repository.findOne).toHaveBeenCalledWith({
      where: {
        id: 1,
      },
    });
    expect(repository.delete).toHaveBeenCalledWith(1);
    expect(result).toBe(1);
  });

  it('should throw NotFoundException if genre to delete does not exist', async () => {
    jest.spyOn(repository, 'findOne').mockResolvedValue(null);

    await expect(service.remove(1)).rejects.toThrow(NotFoundException);
  });
});
```

---

### 16.2 GenreController 테스트하기

#### 기본 설정

```typescript:src/genre/genre.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { GenreController } from './genre.controller';
import { GenreService } from './genre.service';
import { CreateGenreDto } from './dto/create-genre.dto';
import { UpdateGenreDto } from './dto/update-genre.dto';

const mockGenreService = {
  create: jest.fn(),
  findAll: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  remove: jest.fn(),
};

describe('GenreController', () => {
  let controller: GenreController;
  let service: GenreService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GenreController],
      providers: [
        {
          provide: GenreService,
          useValue: mockGenreService,
        },
      ],
    }).compile();

    controller = module.get<GenreController>(GenreController);
    service = module.get<GenreService>(GenreService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
```

#### CRUD 메서드 테스트

```typescript:src/genre/genre.controller.spec.ts
describe('create', () => {
  it('should call genreService.create with correct parameter', async () => {
    const createGenreDto = { name: 'Fantasy' };
    const result = { id: 1, ...createGenreDto };

    jest
      .spyOn(service, 'create')
      .mockResolvedValue(result as CreateGenreDto & Genre);

    expect(controller.create(createGenreDto)).resolves.toEqual(result);
    expect(service.create).toHaveBeenCalledWith(createGenreDto);
  });
});

describe('findAll', () => {
  it('should call genreService.findAll and return an array of genres', async () => {
    const result = [{ id: 1, name: 'Fantasy' }];

    jest.spyOn(service, 'findAll').mockResolvedValue(result as Genre[]);

    expect(controller.findAll()).resolves.toEqual(result);
    expect(service.findAll).toHaveBeenCalled();
  });
});

describe('findOne', () => {
  it('should call genreService.findOne with correct id and return the genre', async () => {
    const id = 1;
    const result = { id: 1, name: 'Fantasy' };

    jest.spyOn(service, 'findOne').mockResolvedValue(result as Genre);

    expect(controller.findOne(id)).resolves.toEqual(result);
    expect(service.findOne).toHaveBeenCalledWith(id);
  });
});

describe('update', () => {
  it('should call genreService.update with correct parameters and return updated genre', async () => {
    const id = 1;
    const updateGenreDto = { name: 'UpdatedFantasy' };
    const result = { id: 1, ...updateGenreDto };

    jest.spyOn(service, 'update').mockResolvedValue(result as Genre);

    expect(controller.update(id, updateGenreDto)).resolves.toEqual(result);
    expect(service.update).toHaveBeenCalledWith(id, updateGenreDto);
  });
});

describe('remove', () => {
  it('should call genreService.remove with correct id and return id of the removed genre', async () => {
    const id = 1;

    jest.spyOn(service, 'remove').mockResolvedValue(id);

    expect(controller.remove(id)).resolves.toBe(id);
    expect(service.remove).toHaveBeenCalledWith(id);
  });
});
```

---

## 17. Movie Module Unit Test

### 17.1 Automock 사용해보기

Movie Module은 복잡한 의존성을 가지고 있어 `@automock/jest`를 사용하여 테스트를 더 쉽게 작성할 수 있습니다.

#### Automock이란?

**Automock**은 NestJS 테스트에서 의존성을 자동으로 Mock으로 대체해주는 라이브러리입니다. 수동으로 Mock 객체를 만들 필요가 없습니다.

#### 설치

```bash
pnpm add -D @automock/jest
```

#### 기본 사용법

```typescript:src/movie/movie.service.spec.ts
import { TestBed } from '@automock/jest';
import { MovieService } from './movie.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Movie } from './entity/movie.entity';

describe('MovieService', () => {
  let movieService: MovieService;
  let movieRepository: jest.Mocked<Repository<Movie>>;

  beforeEach(async () => {
    const { unit, unitRef } = TestBed.create(MovieService).compile();

    movieService = unit;
    movieRepository = unitRef.get(getRepositoryToken(Movie) as string);
  });

  it('should be defined', () => {
    expect(movieService).toBeDefined();
  });
});
```

#### Automock의 장점

1. **자동 Mock 생성**: 모든 의존성이 자동으로 Mock으로 생성됨
2. **타입 안전성**: `jest.Mocked<T>` 타입으로 타입 안전성 보장
3. **간결한 코드**: Mock 객체를 수동으로 만들 필요 없음
4. **복잡한 의존성 처리**: 여러 Repository, Service 등을 쉽게 처리

#### Automock vs 수동 Mock

**수동 Mock (기존 방식)**:
```typescript
const mockRepository = {
  findOne: jest.fn(),
  save: jest.fn(),
};

const module = await Test.createTestingModule({
  providers: [
    MovieService,
    {
      provide: getRepositoryToken(Movie),
      useValue: mockRepository,
    },
  ],
}).compile();
```

**Automock (새로운 방식)**:
```typescript
const { unit, unitRef } = TestBed.create(MovieService).compile();

movieService = unit;
movieRepository = unitRef.get(getRepositoryToken(Movie) as string);
// 이미 Mock으로 생성되어 있음
```

---

### 17.2 MovieService 테스트하기 1 (findRecent, findAll)

#### findRecent() 테스트

캐시를 사용하는 최근 영화 조회 기능을 테스트합니다.

```typescript:src/movie/movie.service.spec.ts
describe('findRecent', () => {
  it('should return recent movies from cache', async () => {
    const cachedMovies = [
      {
        id: 1,
        title: 'Movie 1',
      },
    ];
    jest.spyOn(cacheManager, 'get').mockResolvedValue(cachedMovies);
    
    const result = await movieService.findRecent();
    
    expect(cacheManager.get).toHaveBeenCalledWith('MOVIE_RECENT');
    expect(result).toEqual(cachedMovies);
  });

  it('should return recent movies from database if not cached', async () => {
    const recentMovies = [{ id: 1, title: 'Movie 1' }];
    jest.spyOn(cacheManager, 'get').mockResolvedValue(null);
    jest
      .spyOn(movieRepository, 'find')
      .mockResolvedValue(recentMovies as Movie[]);
    
    const result = await movieService.findRecent();
    
    expect(cacheManager.get).toHaveBeenCalledWith('MOVIE_RECENT');
    expect(cacheManager.set).toHaveBeenCalledWith(
      'MOVIE_RECENT',
      recentMovies,
    );
    expect(result).toEqual(recentMovies);
  });
});
```

#### findAll() 테스트

영화 목록 조회 기능을 테스트합니다. QueryBuilder와 커서 페이지네이션을 사용합니다.

```typescript:src/movie/movie.service.spec.ts
describe('findAll', () => {
  let getMoviesMock: jest.SpyInstance;
  let getLikedMoviesMock: jest.SpyInstance;

  beforeEach(() => {
    getMoviesMock = jest.spyOn(movieService, 'getMovies');
    getLikedMoviesMock = jest.spyOn(movieService, 'getLikedMovies');
  });

  it('should return a list of movies without user likes', async () => {
    const movies = [{ id: 1, title: 'Movie 1' }];
    const dto = { title: 'Movie' } as GetMoviesDto;
    const qb: any = {
      where: jest.fn().mockReturnThis(),
      getManyAndCount: jest.fn().mockResolvedValue([movies, 1]),
    };

    getMoviesMock.mockResolvedValue(qb);
    jest
      .spyOn(commonService, 'applyCursorPaginationParamsToQb')
      .mockResolvedValue({ nextCursor: null } as any);

    const result = await movieService.findAll(dto);

    expect(getMoviesMock).toHaveBeenCalled();
    expect(qb.where).toHaveBeenCalledWith('movie.title LIKE :title', {
      title: '%Movie%',
    });
    expect(
      commonService.applyCursorPaginationParamsToQb,
    ).toHaveBeenCalledWith(qb, dto);
    expect(qb.getManyAndCount).toHaveBeenCalled();
    expect(result).toEqual({
      data: movies,
      nextCursor: null,
      count: 1,
    });
  });

  it('should return a list of movies with user likes', async () => {
    const movies = [
      { id: 1, title: 'Movie 1' },
      { id: 3, title: 'Movie 3' },
    ];
    const likedMovies = [
      { movie: { id: 1 }, isLike: true },
      { movie: { id: 2 }, isLike: false },
    ];
    const dto = { title: 'Movie' } as GetMoviesDto;
    const qb: any = {
      where: jest.fn().mockReturnThis(),
      getManyAndCount: jest.fn().mockResolvedValue([movies, 1]),
    };

    getMoviesMock.mockResolvedValue(qb);
    jest
      .spyOn(commonService, 'applyCursorPaginationParamsToQb')
      .mockReturnValue({ nextCursor: null } as any);
    getLikedMoviesMock.mockResolvedValue(likedMovies);

    const userId = 1;
    const result = await movieService.findAll(dto, userId);

    expect(getMoviesMock).toHaveBeenCalled();
    expect(getLikedMoviesMock).toHaveBeenCalledWith(
      movies.map((movie) => movie.id),
      userId,
    );
    expect(result.data[0].likeStatus).toBe(true);
    expect(result.data[1].likeStatus).toBe(null);
  });

  it('should return movies without title filter', async () => {
    const movies = [{ id: 1, title: 'Movie 1' }];
    const dto = {} as GetMoviesDto;
    const qb: any = {
      getManyAndCount: jest.fn().mockResolvedValue([movies, 1]),
    };

    getMoviesMock.mockResolvedValue(qb);
    jest
      .spyOn(commonService, 'applyCursorPaginationParamsToQb')
      .mockResolvedValue({ nextCursor: null } as any);

    const result = await movieService.findAll(dto);

    expect(getMoviesMock).toHaveBeenCalled();
    expect(qb.getManyAndCount).toHaveBeenCalled();
    expect(result).toEqual({
      data: movies,
      nextCursor: null,
      count: 1,
    });
  });
});
```

#### 주요 포인트

1. **QueryBuilder Mock**: `any` 타입으로 Mock하여 `where()`, `getManyAndCount()` 등 메서드 체이닝 지원
2. **Service 내부 메서드 Mock**: `getMovies()`, `getLikedMovies()` 같은 private 메서드를 `jest.spyOn()`으로 Mock
3. **좋아요 상태 매핑**: `reduce()`를 사용하여 `likeStatus` 속성 추가
4. **빈 배열 처리**: `movieIds.length > 0` 체크로 빈 배열일 때 `getLikedMovies()` 호출 방지

---

### 17.3 MovieService 테스트하기 2 (findOne, create)

#### findOne() 테스트

영화 상세 정보 조회 기능을 테스트합니다.

```typescript:src/movie/movie.service.spec.ts
describe('findOne', () => {
  let findMovieDetailMock: jest.SpyInstance;

  beforeEach(() => {
    findMovieDetailMock = jest.spyOn(movieService, 'findMovieDetail');
  });

  it('should return a movie if found', async () => {
    const movie = { id: 1, title: 'Movie 1' };

    findMovieDetailMock.mockResolvedValue(movie);

    const result = await movieService.findOne(1);

    expect(findMovieDetailMock).toHaveBeenCalledWith(1);
    expect(result).toEqual(movie);
  });

  it('should throw NotFoundException if movie is not found', async () => {
    findMovieDetailMock.mockResolvedValue(null);

    await expect(movieService.findOne(1)).rejects.toThrow(NotFoundException);
    expect(findMovieDetailMock).toHaveBeenCalledWith(1);
  });
});
```

#### create() 테스트

영화 생성 기능을 테스트합니다. 트랜잭션과 여러 의존성을 사용합니다.

```typescript:src/movie/movie.service.spec.ts
describe('create', () => {
  let qr: jest.Mocked<QueryRunner>;
  let createMovieDetailMock: jest.SpyInstance;
  let createMovieMock: jest.SpyInstance;
  let createMovieGenreRelationMock: jest.SpyInstance;
  let renameMovieFileMock: jest.SpyInstance;

  beforeEach(() => {
    qr = {
      manager: {
        findOne: jest.fn(),
        find: jest.fn(),
      },
    } as any as jest.Mocked<QueryRunner>;

    createMovieDetailMock = jest.spyOn(movieService, 'createMovieDetail');
    createMovieMock = jest.spyOn(movieService, 'createMovie');
    createMovieGenreRelationMock = jest.spyOn(
      movieService,
      'createMovieGenreRelation',
    );
    renameMovieFileMock = jest.spyOn(movieService, 'renameMovieFile');
  });

  it('should create a movie successfully', async () => {
    const createMovieDto: CreateMovieDto = {
      title: 'New Movie',
      directorId: 1,
      genreIds: [1, 2],
      detail: 'Some Detail',
      movieFileName: 'mmovie.mp4',
    };
    const userId = 1;
    const director = { id: 1, name: 'Director' };
    const genres = [
      { id: 1, name: 'Genre1' },
      { id: 2, name: 'Genre2' },
    ];
    const movieDetailInsertResult = { identifiers: [{ id: 1 }] };
    const movieInsertResult = { identifiers: [{ id: 1 }] };

    (qr.manager.findOne as any).mockResolvedValueOnce(director);
    (qr.manager.find as any).mockResolvedValueOnce(genres);

    createMovieDetailMock.mockResolvedValue(movieDetailInsertResult);
    createMovieMock.mockResolvedValue(movieInsertResult);
    createMovieGenreRelationMock.mockResolvedValue(undefined);
    renameMovieFileMock.mockResolvedValue(undefined);

    const result = await movieService.create(createMovieDto, qr, userId);

    expect(qr.manager.findOne).toHaveBeenCalledWith(Director, {
      where: { id: createMovieDto.directorId },
    });
    expect(qr.manager.find).toHaveBeenCalledWith(Genre, {
      where: { id: In(createMovieDto.genreIds) },
    });
    expect(createMovieDetailMock).toHaveBeenCalledWith(qr, createMovieDto);
    expect(createMovieMock).toHaveBeenCalledWith(
      qr,
      createMovieDto,
      director,
      movieDetailInsertResult.identifiers[0].id,
      userId,
      expect.any(String),
    );
    expect(createMovieGenreRelationMock).toHaveBeenCalledWith(
      qr,
      movieInsertResult.identifiers[0].id,
      genres,
    );
    expect(renameMovieFileMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.any(String),
      createMovieDto,
    );
    expect(result).toEqual({ ...createMovieDto, id: 1 });
  });

  it('should throw NotFoundException if director does not exist', async () => {
    const createMovieDto: CreateMovieDto = {
      title: 'New Movie',
      directorId: 1,
      genreIds: [1, 2],
      detail: 'Some Detail',
      movieFileName: 'mmovie.mp4',
    };
    const userId = 1;

    (qr.manager.findOne as any).mockResolvedValueOnce(null);

    await expect(
      movieService.create(createMovieDto, qr, userId),
    ).rejects.toThrow(NotFoundException);
    expect(qr.manager.findOne).toHaveBeenCalledWith(Director, {
      where: { id: createMovieDto.directorId },
    });
  });

  it('should throw NotFoundException if some genres do not exist', async () => {
    const createMovieDto: CreateMovieDto = {
      title: 'New Movie',
      directorId: 1,
      genreIds: [1, 2],
      detail: 'Some Detail',
      movieFileName: 'mmovie.mp4',
    };
    const userId = 1;
    const director = { id: 1, name: 'Director' };

    (qr.manager.findOne as any).mockResolvedValueOnce(director);
    (qr.manager.find as any).mockResolvedValueOnce([
      { id: 1, name: 'Genre1' },
    ]);

    await expect(
      movieService.create(createMovieDto, qr, userId),
    ).rejects.toThrow(NotFoundException);

    expect(qr.manager.find).toHaveBeenCalledWith(Genre, {
      where: { id: In(createMovieDto.genreIds) },
    });
  });
});
```

#### 주요 포인트

1. **QueryRunner Mock**: 트랜잭션을 위한 `QueryRunner` 객체 Mock
2. **insert().execute() 결과**: `{ identifiers: [{ id: 1 }] }` 형식으로 반환
3. **TypeORM In()**: `In(genreIds)`로 배열 조건 처리
4. **expect.any(String)**: 경로나 파일명 같은 동적 값 검증
5. **Service 내부 메서드 분리**: `createMovieDetail()`, `createMovie()` 등으로 로직 분리하여 테스트 용이

---

### 17.4 MovieService 테스트하기 3 (update)

#### update() 테스트

영화 수정 기능을 테스트합니다. 트랜잭션과 복잡한 업데이트 로직을 포함합니다.

```typescript:src/movie/movie.service.spec.ts
describe('update', () => {
  let qr: jest.Mocked<QueryRunner>;
  let updateMovieMock: jest.SpyInstance;
  let updateMovieDetailMock: jest.SpyInstance;
  let updateMovieGenreRelationMock: jest.SpyInstance;

  beforeEach(() => {
    qr = {
      connect: jest.fn(),
      startTransaction: jest.fn(),
      commitTransaction: jest.fn(),
      rollbackTransaction: jest.fn(),
      release: jest.fn(),
      manager: {
        findOne: jest.fn(),
        find: jest.fn(),
      },
    } as any as jest.Mocked<QueryRunner>;

    updateMovieMock = jest.spyOn(movieService, 'updateMovie');
    updateMovieDetailMock = jest.spyOn(movieService, 'updateMovieDetail');
    updateMovieGenreRelationMock = jest.spyOn(
      movieService,
      'updateMovieGenreRelation',
    );

    jest.spyOn(dataSource, 'createQueryRunner').mockReturnValue(qr);
  });

  it('should update a movie successfully', async () => {
    const updateMovieDto: UpdateMovieDto = {
      title: 'Updated Movie',
      directorId: 1,
      genreIds: [1, 2],
      detail: 'Updated detail',
    };
    const movie = {
      id: 1,
      detail: { id: 1 },
      genres: [{ id: 1 }, { id: 2 }],
    };
    const director = { id: 1, name: 'Director' };
    const genres = [
      { id: 1, name: 'Genre1' },
      { id: 2, name: 'Genre2' },
    ];

    (qr.connect as any).mockResolvedValue(null);
    (qr.manager.findOne as any).mockResolvedValueOnce(movie);
    (qr.manager.findOne as any).mockResolvedValueOnce(director);
    (qr.manager.find as any).mockResolvedValueOnce(genres);

    updateMovieMock.mockResolvedValue(undefined);
    updateMovieDetailMock.mockResolvedValue(undefined);
    updateMovieGenreRelationMock.mockResolvedValue(undefined);

    const result = await movieService.update(1, updateMovieDto);

    expect(qr.connect).toHaveBeenCalled();
    expect(qr.startTransaction).toHaveBeenCalled();
    expect(qr.manager.findOne).toHaveBeenCalledWith(Movie, {
      where: { id: 1 },
      relations: ['detail', 'genres'],
    });
    expect(updateMovieMock).toHaveBeenCalledWith(qr, expect.any(Object), 1);
    expect(updateMovieDetailMock).toHaveBeenCalledWith(
      qr,
      updateMovieDto.detail,
      movie,
    );
    expect(updateMovieGenreRelationMock).toHaveBeenCalledWith(
      qr,
      1,
      genres,
      movie,
    );
    expect(qr.commitTransaction).toHaveBeenCalled();
    expect(result).toEqual(movie);
  });

  it('should throw NotFoundException if movie does not exist', async () => {
    const updateMovieDto: UpdateMovieDto = {
      title: 'Updated Movie',
    };

    (qr.manager.findOne as any).mockResolvedValue(null);

    await expect(movieService.update(1, updateMovieDto)).rejects.toThrow(
      NotFoundException,
    );

    expect(qr.connect).toHaveBeenCalled();
    expect(qr.startTransaction).toHaveBeenCalled();
    expect(qr.rollbackTransaction).toHaveBeenCalled();
  });

  it('should throw NotFoundException if new director does not exist', async () => {
    const updateMovieDto: UpdateMovieDto = {
      title: 'Updated Movie',
      directorId: 1,
    };
    const movie = { id: 1, detail: { id: 1 }, genres: [] };

    (qr.manager.findOne as any).mockResolvedValueOnce(movie);
    (qr.manager.findOne as any).mockResolvedValueOnce(null);

    await expect(movieService.update(1, updateMovieDto)).rejects.toThrow(
      NotFoundException,
    );

    expect(qr.rollbackTransaction).toHaveBeenCalled();
  });

  it('should throw NotFoundException if new genres do not exist', async () => {
    const updateMoviesDto: UpdateMovieDto = {
      title: 'Updated Movie',
      genreIds: [1, 2],
    };
    const movie = {
      id: 1,
      detail: { id: 1 },
      genres: [],
    };

    (qr.manager.findOne as any).mockResolvedValueOnce(movie);
    (qr.manager.find as any).mockResolvedValueOnce([
      { id: 1, name: 'Genre1' },
    ]);

    await expect(movieService.update(1, updateMoviesDto)).rejects.toThrow(
      NotFoundException,
    );

    expect(qr.rollbackTransaction).toHaveBeenCalled();
  });

  it('should rollback transaction and rethrow error on failure', async () => {
    const updateMovieDto: UpdateMovieDto = {
      title: 'Updated Movie',
    };

    (qr.manager.findOne as any).mockRejectedValueOnce(
      new Error('Database Error'),
    );

    await expect(movieService.update(1, updateMovieDto)).rejects.toThrow(
      'Database Error',
    );

    expect(qr.connect).toHaveBeenCalled();
    expect(qr.startTransaction).toHaveBeenCalled();
    expect(qr.rollbackTransaction).toHaveBeenCalled();
  });
});
```

#### 주요 포인트

1. **트랜잭션 관리**: `connect()`, `startTransaction()`, `commitTransaction()`, `rollbackTransaction()` Mock
2. **에러 시 롤백**: 예외 발생 시 `rollbackTransaction()` 호출 검증
3. **relations 포함**: `findOne()` 호출 시 `relations: ['detail', 'genres']` 포함
4. **조건부 업데이트**: `detail`, `directorId`, `genreIds`가 있을 때만 해당 로직 실행

---

### 17.5 MovieService 테스트하기 4 (remove, toggleMovieLike)

#### remove() 테스트

영화 삭제 기능을 테스트합니다.

```typescript:src/movie/movie.service.spec.ts
describe('remove', () => {
  let findOneMock: jest.SpyInstance;
  let deleteMovieMock: jest.SpyInstance;
  let deleteMovieDetailMock: jest.SpyInstance;

  beforeEach(() => {
    findOneMock = jest.spyOn(movieRepository, 'findOne');
    deleteMovieMock = jest.spyOn(movieService, 'deleteMovie');
    deleteMovieDetailMock = jest.spyOn(movieDetailRepository, 'delete');
  });

  it('should remove a movie successfully', async () => {
    const movie = { id: 1, detail: { id: 2 } };

    findOneMock.mockResolvedValue(movie);
    deleteMovieMock.mockResolvedValue(undefined);
    deleteMovieDetailMock.mockResolvedValue(undefined);

    const result = await movieService.remove(1);

    expect(findOneMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['detail'],
    });
    expect(deleteMovieMock).toHaveBeenCalledWith(1);
    expect(deleteMovieDetailMock).toHaveBeenCalledWith({
      id: movie.detail.id,
    });
    expect(result).toBe(1);
  });

  it('should throw NotFoundException if movie does not exist', async () => {
    findOneMock.mockResolvedValue(null);

    await expect(movieService.remove(1)).rejects.toThrow(NotFoundException);

    expect(findOneMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['detail'],
    });
    expect(deleteMovieMock).not.toHaveBeenCalled();
    expect(deleteMovieDetailMock).not.toHaveBeenCalled();
  });
});
```

#### toggleMovieLike() 테스트

영화 좋아요/싫어요 토글 기능을 테스트합니다.

```typescript:src/movie/movie.service.spec.ts
describe('toggleMovieLike', () => {
  let findOneMovieMock: jest.SpyInstance;
  let findOneUserMock: jest.SpyInstance;
  let getLikedRecordMock: jest.SpyInstance;
  let deleteLikeMock: jest.SpyInstance;
  let updateLikeMock: jest.SpyInstance;
  let saveLikeMock: jest.SpyInstance;

  beforeEach(() => {
    findOneMovieMock = jest.spyOn(movieRepository, 'findOne');
    findOneUserMock = jest.spyOn(userRepository, 'findOne');
    getLikedRecordMock = jest.spyOn(movieService, 'getLikedRecord');
    deleteLikeMock = jest.spyOn(movieUserLikeRepository, 'delete');
    updateLikeMock = jest.spyOn(movieUserLikeRepository, 'update');
    saveLikeMock = jest.spyOn(movieUserLikeRepository, 'save');
  });

  it('should toggle movie like status when like record exists and isLike is different', async () => {
    const movie = { id: 1 };
    const user = { id: 1 };
    const likeRecord = { movie, user, isLike: true };

    findOneMovieMock.mockResolvedValue(movie);
    findOneUserMock.mockResolvedValue(user);
    getLikedRecordMock
      .mockResolvedValueOnce(likeRecord)
      .mockResolvedValueOnce({ isLike: false });

    const result = await movieService.toggleMovieLike(1, 1, false);

    expect(findOneMovieMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['likedUsers'],
    });
    expect(findOneUserMock).toHaveBeenCalledWith({ where: { id: 1 } });
    expect(getLikedRecordMock).toHaveBeenCalledWith(1, 1);
    expect(updateLikeMock).toHaveBeenCalledWith(
      { movie, user },
      { isLike: false },
    );
    expect(result).toEqual({ isLike: false });
  });

  it('should delete like record when isLike is the same as the existing record', async () => {
    const movie = { id: 1 };
    const user = { id: 1 };
    const likeRecord = { movie, user, isLike: true };

    findOneMovieMock.mockResolvedValue(movie);
    findOneUserMock.mockResolvedValue(user);
    getLikedRecordMock
      .mockResolvedValueOnce(likeRecord)
      .mockResolvedValueOnce(null);

    const result = await movieService.toggleMovieLike(1, 1, true);

    expect(findOneMovieMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['likedUsers'],
    });
    expect(findOneUserMock).toHaveBeenCalledWith({ where: { id: 1 } });
    expect(getLikedRecordMock).toHaveBeenCalledWith(1, 1);
    expect(deleteLikeMock).toHaveBeenCalledWith({ movie, user });
    expect(result).toEqual({ isLike: null });
  });

  it('should save a new like record when no existing record is found', async () => {
    const movie = { id: 1 };
    const user = { id: 1 };

    findOneMovieMock.mockResolvedValue(movie);
    findOneUserMock.mockResolvedValue(user);
    getLikedRecordMock
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ isLike: true });

    const result = await movieService.toggleMovieLike(1, 1, true);

    expect(findOneMovieMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['likedUsers'],
    });
    expect(findOneUserMock).toHaveBeenCalledWith({ where: { id: 1 } });
    expect(getLikedRecordMock).toHaveBeenCalledWith(1, 1);
    expect(saveLikeMock).toHaveBeenCalledWith({ movie, user, isLike: true });
    expect(result).toEqual({ isLike: true });
  });

  it('should throw BadRequestException if movie does not exist', async () => {
    findOneMovieMock.mockResolvedValue(null);

    await expect(movieService.toggleMovieLike(1, 1, true)).rejects.toThrow(
      BadRequestException,
    );

    expect(findOneMovieMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['likedUsers'],
    });
    expect(findOneUserMock).not.toHaveBeenCalled();
  });

  it('should throw UnauthorizedException if user does not exist', async () => {
    const movie = { id: 1 };

    findOneMovieMock.mockResolvedValue(movie);
    findOneUserMock.mockResolvedValue(null);

    await expect(movieService.toggleMovieLike(1, 1, true)).rejects.toThrow(
      UnauthorizedException,
    );

    expect(findOneMovieMock).toHaveBeenCalledWith({
      where: { id: 1 },
      relations: ['likedUsers'],
    });
    expect(findOneUserMock).toHaveBeenCalledWith({ where: { id: 1 } });
  });
});
```

#### 주요 포인트

1. **좋아요 토글 로직**:
   - 기존 레코드가 있고 `isLike`가 다르면 → `update()`
   - 기존 레코드가 있고 `isLike`가 같으면 → `delete()` (토글 취소)
   - 기존 레코드가 없으면 → `save()` (새로 생성)

2. **relations 포함**: `findOne()` 호출 시 `relations: ['likedUsers']` 포함

3. **에러 처리**: 
   - 영화가 없으면 `BadRequestException`
   - 사용자가 없으면 `UnauthorizedException`

---

### 17.6 MovieService 버그 수정

테스트 작성 중 발견된 버그를 수정하는 과정입니다.

#### 주요 버그 수정 사항

1. **getLikedMovies() 반환 타입**: QueryBuilder를 반환하던 것을 `.getMany()`로 배열 반환하도록 수정
2. **빈 배열 처리**: `movieIds.length > 0` 체크 추가
3. **relations 누락**: `remove()`에서 `relations: ['detail']` 추가
4. **파라미터 순서**: `create()` 메서드의 파라미터 순서 확인 (`dto, qr, userId`)

---

### 17.7 MovieController 테스트하기

#### 기본 설정

```typescript:src/movie/movie.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { MovieController } from './movie.controller';
import { MovieService } from './movie.service';
import { TestBed } from '@automock/jest';
import { CreateMovieDto } from './dto/create-movie.dto';
import { QueryRunner } from 'typeorm';
import { UpdateMovieDto } from './dto/update-movie.dto';

describe('MovieController', () => {
  let movieController: MovieController;
  let movieService: jest.Mocked<MovieService>;

  beforeEach(async () => {
    const { unit, unitRef } = TestBed.create(MovieController).compile();

    movieController = unit;
    movieService = unitRef.get<MovieService>(MovieService);
  });

  it('should be defined', () => {
    expect(movieController).toBeDefined();
  });
});
```

#### CRUD 메서드 테스트

```typescript:src/movie/movie.controller.spec.ts
describe('getMovies', () => {
  it('should call movieService.findAll with the correct parameters', async () => {
    const dto = { page: 1, limit: 10 };
    const userId = 1;
    const movies = [{ id: 1 }, { id: 2 }];

    jest.spyOn(movieService, 'findAll').mockResolvedValue(movies as any);

    const result = await movieController.getMovies(dto as any, userId);

    expect(movieService.findAll).toHaveBeenCalledWith(dto, userId);
    expect(result).toEqual(movies);
  });
});

describe('getMoviesRecent', () => {
  it('should call movieService.findRecent', async () => {
    await movieController.getMoviesRecent();
    expect(movieService.findRecent).toHaveBeenCalled();
  });
});

describe('getMovie', () => {
  it('should call movieService.findOne with the correct id', async () => {
    const id = 1;
    await movieController.getMovie(1);
    expect(movieService.findOne).toHaveBeenCalledWith(1);
  });
});

describe('createMovie', () => {
  it('should call movieService.create with the correct parameters', async () => {
    const body = { title: 'Test Movie' };
    const userId = 1;
    const queryRunner = {};

    await movieController.createMovie(
      body as CreateMovieDto,
      queryRunner as QueryRunner,
      userId,
    );

    expect(movieService.create).toHaveBeenCalledWith(
      body,
      queryRunner,
      userId,
    );
  });
});

describe('updateMovie', () => {
  it('should call movieService.update with the correct parameters', async () => {
    const id = '1'; // ParseIntPipe로 받으므로 string
    const body: UpdateMovieDto = { title: 'Updated Movie' };

    await movieController.updateMovie(id, body);

    expect(movieService.update).toHaveBeenCalledWith(1, body);
  });
});

describe('deleteMovie', () => {
  it('should call movieService.remove with the correct id', async () => {
    const id = '1'; // ParseIntPipe로 받으므로 string
    await movieController.deleteMovie(id);
    expect(movieService.remove).toHaveBeenCalledWith(1);
  });
});

describe('createMovieLike', () => {
  it('should call movieService.toggleMovieLike with the correct parameters', async () => {
    const movieId = 1;
    const userId = 2;

    await movieController.createMovieLike(movieId, userId);
    expect(movieService.toggleMovieLike).toHaveBeenCalledWith(
      movieId,
      userId,
      true,
    );
  });
});

describe('createMovieDislike', () => {
  it('should call movieService.toggleMovieLike with the correct parameters', async () => {
    const movieId = 1;
    const userId = 2;

    await movieController.createMovieDislike(movieId, userId);
    expect(movieService.toggleMovieLike).toHaveBeenCalledWith(
      movieId,
      userId,
      false,
    );
  });
});
```

#### 주요 포인트

1. **Automock 사용**: Controller도 Automock으로 간단하게 설정
2. **ParseIntPipe**: `@Param('id', ParseIntPipe) id: string`로 받지만 Service에는 `+id`로 변환되어 전달
3. **QueryRunner**: `@QueryRunner()` 데코레이터로 받은 QueryRunner를 Service에 전달
4. **좋아요/싫어요**: 같은 `toggleMovieLike()` 메서드를 `isLike` 파라미터로 구분

---

## 정리

### Genre Module 테스트 요약

1. **간단한 CRUD**: 표준적인 CRUD 기능 테스트
2. **에러 처리**: `NotFoundException` 처리
3. **TypeORM update()**: `update({ id }, data)` 형식

### Movie Module 테스트 요약

1. **Automock 활용**: 복잡한 의존성을 자동으로 Mock 처리
2. **QueryBuilder 테스트**: QueryBuilder Mock을 통한 복잡한 쿼리 테스트
3. **트랜잭션 테스트**: QueryRunner를 통한 트랜잭션 관리 테스트
4. **캐시 테스트**: Cache Manager를 통한 캐싱 로직 테스트
5. **좋아요 토글**: 복잡한 비즈니스 로직 테스트 (update/delete/save 분기)

### 테스트 작성 순서 (Movie Module)

1. **테스트 1**: `findRecent()`, `findAll()` - 조회 기능
2. **테스트 2**: `findOne()`, `create()` - 조회 및 생성
3. **테스트 3**: `update()` - 수정 (트랜잭션 포함)
4. **테스트 4**: `remove()`, `toggleMovieLike()` - 삭제 및 좋아요 토글

### Best Practices

1. **Automock 활용**: 복잡한 의존성이 많은 경우 Automock 사용
2. **Service 내부 메서드 분리**: 테스트하기 쉽도록 메서드 분리
3. **QueryBuilder Mock**: `any` 타입으로 Mock하여 메서드 체이닝 지원
4. **트랜잭션 검증**: `commitTransaction()`, `rollbackTransaction()` 호출 검증
5. **에러 케이스**: 모든 예외 상황 테스트

---

## 14. Auth Module Unit Test

### 14.1 Auth Module Unit Test 세팅하기

Auth Module은 인증과 관련된 기능을 담당하는 모듈입니다. JWT 토큰 발급, 사용자 인증, 토큰 블랙리스트 관리 등의 기능을 테스트합니다.

#### 필요한 의존성

AuthService는 다음과 같은 의존성을 가집니다:

- `Repository<User>`: 사용자 데이터베이스 접근
- `ConfigService`: 환경 변수 접근 (JWT secret 등)
- `JwtService`: JWT 토큰 생성 및 검증
- `Cache`: 토큰 블랙리스트 관리
- `UserService`: 사용자 생성

#### 테스트 모듈 설정

```typescript:src/auth/auth.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { User, Role } from 'src/user/entity/user.entity';
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserService } from 'src/user/user.service';
import * as bcrypt from 'bcrypt';

// bcrypt 모듈 전체 Mock
jest.mock('bcrypt');

// Mock 객체들 정의
const mockUserRepository = {
  findOne: jest.fn(),
};

const mockConfigService = {
  get: jest.fn(),
};

const mockJwtService = {
  signAsync: jest.fn(),
  verifyAsync: jest.fn(),
  decode: jest.fn(),
};

const mockCacheManager = {
  set: jest.fn(),
};

const mockUserService = {
  create: jest.fn(),
};

describe('AuthService', () => {
  let authService: AuthService;
  let userRepository: Repository<User>;
  let configService: ConfigService;
  let jwtService: JwtService;
  let cacheManager: Cache;
  let userService: UserService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: getRepositoryToken(User),
          useValue: mockUserRepository,
        },
        {
          provide: ConfigService,
          useValue: mockConfigService,
        },
        {
          provide: JwtService,
          useValue: mockJwtService,
        },
        {
          provide: CACHE_MANAGER,
          useValue: mockCacheManager,
        },
        {
          provide: UserService,
          useValue: mockUserService,
        },
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
    userRepository = module.get<Repository<User>>(getRepositoryToken(User));
    configService = module.get<ConfigService>(ConfigService);
    jwtService = module.get<JwtService>(JwtService);
    cacheManager = module.get<Cache>(CACHE_MANAGER);
    userService = module.get<UserService>(UserService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(authService).toBeDefined();
  });
});
```

#### 주요 포인트

1. **`jest.mock('bcrypt')`**: bcrypt 모듈 전체를 Mock으로 대체
2. **`getRepositoryToken(User)`**: TypeORM Repository 토큰 생성
3. **`CACHE_MANAGER`**: NestJS Cache Manager 토큰
4. **`afterEach`**: 각 테스트 후 Mock 초기화

---

### 14.2 AuthService 테스트하기 1

#### tokenBlock() 테스트

토큰을 블랙리스트에 등록하는 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('tokenBlock', () => {
  it('should block a token', async () => {
    const token = 'token';
    const payload = { 
      exp: Math.floor(Date.now() / 1000) + 60 // 60초 후 만료
    };
    
    jest.spyOn(jwtService, 'decode').mockReturnValue(payload);

    await authService.tokenBlock(token);

    expect(jwtService.decode).toHaveBeenCalledWith(token);
    expect(cacheManager.set).toHaveBeenCalledWith(
      `BLOCK_TOKEN_${token}`,
      payload,
      expect.any(Number), // TTL은 계산된 값이므로 any로 검증
    );
  });
});
```

#### parseBasicToken() 테스트

Basic 인증 토큰을 파싱하는 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('parseBasicToken', () => {
  it('should parse a basic token', () => {
    // 'test@test.com:123123'을 base64로 인코딩
    const encodedToken = Buffer.from('test@test.com:123123', 'utf-8').toString('base64');
    const rawToken = `Basic ${encodedToken}`;
    
    const result = authService.parseBasicToken(rawToken);
    const expected = { email: 'test@test.com', password: '123123' };
    
    expect(result).toEqual(expected);
  });

  it('should throw BadRequestException if the token is invalid', () => {
    const rawToken = 'Basic invalidToken';
    expect(() => authService.parseBasicToken(rawToken)).toThrow(BadRequestException);
  });

  it('should throw BadRequestException if the token type is not Basic', () => {
    const rawToken = 'Bearer invalidToken';
    expect(() => authService.parseBasicToken(rawToken)).toThrow(BadRequestException);
  });

  it('should throw BadRequestException if the token format is invalid', () => {
    const rawToken = 'Basic a'; // 잘못된 base64 형식
    expect(() => authService.parseBasicToken(rawToken)).toThrow(BadRequestException);
  });
});
```

#### parseBearerToken() 테스트

Bearer 토큰을 파싱하고 검증하는 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('parseBearerToken', () => {
  it('should parse a bearer token', async () => {
    const rawToken = 'Bearer token';
    const payload = { type: 'access' };

    jest.spyOn(jwtService, 'verifyAsync').mockResolvedValue(payload);
    jest.spyOn(configService, 'get').mockReturnValue('secret');

    const result = await authService.parseBearerToken(rawToken, false);
    
    expect(jwtService.verifyAsync).toHaveBeenCalledWith('token', { secret: 'secret' });
    expect(result).toEqual(payload);
  });

  it('should throw BadRequestException for invalid Bearer token format', async () => {
    const rawToken = 'a'; // Bearer 접두사 없음
    await expect(() => authService.parseBearerToken(rawToken, false)).rejects.toThrow(BadRequestException);
  });

  it('should throw BadRequestException for invalid Bearer token type', async () => {
    const rawToken = 'Basic a'; // Basic 타입
    await expect(() => authService.parseBearerToken(rawToken, false)).rejects.toThrow(BadRequestException);
  });

  it('should throw UnauthorizedException if token type is refresh but isRefreshToken is false', async () => {
    const rawToken = 'Bearer a';
    jest.spyOn(jwtService, 'verifyAsync').mockResolvedValue({ type: 'refresh' });

    await expect(() => authService.parseBearerToken(rawToken, false)).rejects.toThrow(UnauthorizedException);
  });

  it('should throw UnauthorizedException if token type is access but isRefreshToken is true', async () => {
    const rawToken = 'Bearer a';
    jest.spyOn(jwtService, 'verifyAsync').mockResolvedValue({ type: 'access' });
    
    await expect(() => authService.parseBearerToken(rawToken, true)).rejects.toThrow(UnauthorizedException);
  });
});
```

---

### 14.3 AuthService 테스트하기 2

#### register() 테스트

사용자 회원가입 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('register', () => {
  it('should register a user', async () => {
    const rawToken = 'Basic a';
    const user = { email: 'test@test.com', password: '123123' };

    jest.spyOn(authService, 'parseBasicToken').mockReturnValue(user);
    jest.spyOn(userService, 'create').mockResolvedValue(user as User);
    
    const result = await authService.register(rawToken);
    
    expect(authService.parseBasicToken).toHaveBeenCalledWith(rawToken);
    expect(userService.create).toHaveBeenCalledWith(user);
    expect(result).toEqual(user);
  });
});
```

#### authenticate() 테스트

사용자 인증 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('authenticate', () => {
  it('should authenticate a user with correct credentials', async () => {
    const user = { 
      id: 1,
      email: 'test@test.com', 
      password: 'hashedPassword' 
    };

    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(user as User);
    (bcrypt.compare as jest.Mock) = jest.fn().mockResolvedValue(true);

    const result = await authService.authenticate(user.email, 'plainPassword');
    
    expect(userRepository.findOne).toHaveBeenCalledWith({ 
      where: { email: user.email } 
    });
    expect(bcrypt.compare).toHaveBeenCalledWith('plainPassword', 'hashedPassword');
    expect(result).toEqual(user);
  });

  it('should throw BadRequestException if the user does not exist', async () => {
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(null);
    
    await expect(() => authService.authenticate('test@test.com', '123123')).rejects.toThrow(BadRequestException);
  });

  it('should throw BadRequestException if the password is incorrect', async () => {
    const user = { 
      id: 1,
      email: 'test@test.com', 
      password: 'hashedPassword' 
    };
    
    jest.spyOn(mockUserRepository, 'findOne').mockResolvedValue(user as User);
    (bcrypt.compare as jest.Mock) = jest.fn().mockResolvedValue(false);
    
    await expect(() => authService.authenticate('test@test.com', 'wrongPassword')).rejects.toThrow(BadRequestException);
  });
});
```

#### issueToken() 테스트

JWT 토큰 발급 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('issueToken', () => {
  const user = { id: 1, role: Role.user };
  const token = 'accessToken';

  beforeEach(() => {
    jest.spyOn(mockConfigService, 'get').mockReturnValue('secret');
    jest.spyOn(jwtService, 'signAsync').mockResolvedValue(token);
  });

  it('should issue an access token', async () => {
    const result = await authService.issueToken(user, false);

    expect(jwtService.signAsync).toHaveBeenCalledWith(
      { sub: user.id, role: Role.user, type: 'access' }, 
      { secret: 'secret', expiresIn: '300s' }
    );
    expect(result).toEqual(token);
  });

  it('should issue a refresh token', async () => {
    const result = await authService.issueToken(user, true);

    expect(jwtService.signAsync).toHaveBeenCalledWith(
      { sub: user.id, role: Role.user, type: 'refresh' }, 
      { secret: 'secret', expiresIn: '24h' }
    );
    expect(result).toEqual(token);
  });
});
```

#### login() 테스트

로그인 기능을 테스트합니다.

```typescript:src/auth/auth.service.spec.ts
describe('login', () => {
  it('should login a user and return tokens', async () => {
    const rawToken = 'Basic a';
    const email = 'test@test.com';
    const password = '123123';
    const user = { id: 1, role: Role.user };

    jest.spyOn(authService, 'parseBasicToken').mockReturnValue({ email, password });
    jest.spyOn(authService, 'authenticate').mockResolvedValue(user as User);
    jest.spyOn(authService, 'issueToken')
      .mockResolvedValueOnce('refreshToken')
      .mockResolvedValueOnce('accessToken');

    const result = await authService.login(rawToken);

    expect(authService.parseBasicToken).toHaveBeenCalledWith(rawToken);
    expect(authService.authenticate).toHaveBeenCalledWith(email, password);
    expect(authService.issueToken).toHaveBeenCalledTimes(2);
    expect(authService.issueToken).toHaveBeenNthCalledWith(1, user, true); // refresh token
    expect(authService.issueToken).toHaveBeenNthCalledWith(2, user, false); // access token
    expect(result).toEqual({ 
      accessToken: 'accessToken', 
      refreshToken: 'refreshToken' 
    });
  });
});
```

#### 주요 포인트

1. **bcrypt Mock**: `jest.mock('bcrypt')`로 모듈 전체 Mock, `(bcrypt.compare as jest.Mock)`로 타입 캐스팅
2. **mockResolvedValueOnce()**: 여러 번 호출되는 메서드에 대해 각 호출마다 다른 값 반환
3. **toHaveBeenNthCalledWith()**: N번째 호출의 인자 검증
4. **Service 내부 메서드 Mock**: `jest.spyOn(authService, 'parseBasicToken')`로 같은 서비스의 다른 메서드 Mock

---

### 14.4 AuthController 테스트하기

Controller는 Service에 의존하므로 Service를 Mock으로 대체합니다.

#### 기본 설정

```typescript:src/auth/auth.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { Role, User } from 'src/user/entity/user.entity';

const mockAuthService = {
  register: jest.fn(),
  login: jest.fn(),
  tokenBlock: jest.fn(),
  issueToken: jest.fn(),
};

describe('AuthController', () => {
  let authController: AuthController;
  let authService: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [
        {
          provide: AuthService,
          useValue: mockAuthService,
        },
      ],
    }).compile();

    authController = module.get<AuthController>(AuthController);
    authService = module.get<AuthService>(AuthService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(authController).toBeDefined();
  });
});
```

#### registerUser() 테스트

```typescript:src/auth/auth.controller.spec.ts
describe('registerUser', () => {
  it('should register a user', async () => {
    const rawToken = 'Basic a';
    const result = { id: 1, email: 'test@test.com' };
    
    jest.spyOn(authService, 'register').mockResolvedValue(result as User);

    expect(authController.registerUser(rawToken)).resolves.toEqual(result);
    expect(authService.register).toHaveBeenCalledWith(rawToken);
  });
});
```

#### loginUser() 테스트

```typescript:src/auth/auth.controller.spec.ts
describe('loginUser', () => {
  it('should login a user and return tokens', async () => {
    const rawToken = 'Basic a';
    const result = { 
      refreshToken: 'mock.refresh.token', 
      accessToken: 'mock.access.token' 
    }; 
    
    jest.spyOn(authService, 'login').mockResolvedValue(result);
    
    expect(authController.loginUser(rawToken)).resolves.toEqual(result);
    expect(authService.login).toHaveBeenCalledWith(rawToken);
  });
});
```

#### blockToken() 테스트

```typescript:src/auth/auth.controller.spec.ts
describe('blockToken', () => {
  it('should block a token', async () => {
    const token = 'token';
    
    jest.spyOn(authService, 'tokenBlock').mockResolvedValue(true);

    expect(authController.blockToken(token)).resolves.toBe(true);
    expect(authService.tokenBlock).toHaveBeenCalledWith(token);
  });
});
```

#### rotateAccessToken() 테스트

```typescript:src/auth/auth.controller.spec.ts
describe('rotateAccessToken', () => {
  it('should rotate access token', async () => {
    const accessToken = 'mocked.access.token';
    const req = { user: { id: 1, role: Role.user } };

    jest.spyOn(authService, 'issueToken').mockResolvedValue(accessToken);

    const result = await authController.rotateAccessToken(req);

    expect(authService.issueToken).toHaveBeenCalledWith(req.user, false);
    expect(result).toEqual({ accessToken });
  });
});
```

#### loginUserPassport() 테스트

```typescript:src/auth/auth.controller.spec.ts
describe('loginUserPassport', () => {
  it('should login user using passport strategy', async () => {
    const user = { id: 1, role: Role.user };
    const req = { user };
    const accessToken = 'mocked.access.token';
    const refreshToken = 'mocked.refresh.token';

    jest.spyOn(authService, 'issueToken')
      .mockResolvedValueOnce(refreshToken)
      .mockResolvedValueOnce(accessToken);

    const result = await authController.loginUserPassport(req);

    expect(authService.issueToken).toHaveBeenCalledTimes(2);
    expect(authService.issueToken).toHaveBeenNthCalledWith(1, user, true);
    expect(authService.issueToken).toHaveBeenNthCalledWith(2, user, false);
    expect(result).toEqual({ refreshToken, accessToken });
  });
});
```

#### Controller 테스트 특징

1. **Service Mock**: Controller의 비즈니스 로직은 Service에서 처리하므로, Controller는 Service 호출만 검증
2. **요청 객체**: `@Request()` 데코레이터로 받는 `req` 객체를 Mock으로 전달
3. **비동기 처리**: `resolves.toEqual()` 또는 `async/await` 사용

---

## 15. Director Module Unit Test

### 15.1 DirectorService 테스트하기

Director Module은 감독 정보를 관리하는 모듈입니다. CRUD 기능을 테스트합니다.

#### 테스트 모듈 설정

```typescript:src/director/director.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { DirectorService } from './director.service';
import { Repository } from 'typeorm';
import { Director } from './entity/director.entity';
import { getRepositoryToken } from '@nestjs/typeorm';
import { CreateDirectorDto } from './dto/create-director.dto';
import { UpdateDirectorDto } from './dto/update-director.dto';
import { NotFoundException } from '@nestjs/common';

const mockDirectorRepository = {
  save: jest.fn(),
  find: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
};

describe('DirectorService', () => {
  let directorService: DirectorService;
  let directorRepository: Repository<Director>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DirectorService,
        {
          provide: getRepositoryToken(Director),
          useValue: mockDirectorRepository,
        },
      ],
    }).compile();

    directorService = module.get<DirectorService>(DirectorService);
    directorRepository = module.get<Repository<Director>>(
      getRepositoryToken(Director),
    );
  });

  beforeAll(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(directorService).toBeDefined();
  });
});
```

#### create() 테스트

```typescript:src/director/director.service.spec.ts
describe('create', () => {
  it('should create a new director and return it', async () => {
    const createDirectorDto: CreateDirectorDto = {
      name: 'John Doe',
      dob: new Date('1970-07-30'),
      nationality: 'American',
    };

    const savedDirector = {
      id: 1,
      ...createDirectorDto,
    };

    jest
      .spyOn(mockDirectorRepository, 'save')
      .mockResolvedValue(savedDirector);

    const result = await directorService.create(createDirectorDto);

    expect(mockDirectorRepository.save).toHaveBeenCalledWith(
      createDirectorDto,
    );
    expect(result).toEqual(savedDirector);
  });
});
```

#### findAll() 테스트

```typescript:src/director/director.service.spec.ts
describe('findAll', () => {
  it('should return all directors', async () => {
    const directors = [
      {
        id: 1,
        name: 'John Doe',
        dob: new Date('1970-07-30'),
        nationality: 'American',
      },
    ];

    jest.spyOn(mockDirectorRepository, 'find').mockResolvedValue(directors);

    const result = await directorService.findAll();

    expect(mockDirectorRepository.find).toHaveBeenCalled();
    expect(result).toEqual(directors);
  });
});
```

#### findOne() 테스트

```typescript:src/director/director.service.spec.ts
describe('findOne', () => {
  it('should return a director by id', async () => {
    const director = {
      id: 1,
      name: 'John Doe',
      dob: new Date('1970-07-30'),
      nationality: 'American',
    };
    
    jest.spyOn(mockDirectorRepository, 'findOne').mockResolvedValue(director);

    const result = await directorService.findOne(director.id);

    expect(mockDirectorRepository.findOne).toHaveBeenCalledWith({
      where: { id: 1 },
    });
    expect(result).toEqual(director);
  });
});
```

#### update() 테스트

```typescript:src/director/director.service.spec.ts
describe('update', () => {
  it('should update a director and return it', async () => {
    const updateDirectorDto: UpdateDirectorDto = {
      name: 'Jane Doe',
    };

    const existingDirector = { 
      id: 1, 
      name: 'John Doe',
      dob: new Date('1970-07-30'),
      nationality: 'American',
    };
    const updatedDirector = { 
      ...existingDirector,
      name: 'Jane Doe',
    };

    jest
      .spyOn(mockDirectorRepository, 'findOne')
      .mockResolvedValueOnce(existingDirector);
    jest
      .spyOn(mockDirectorRepository, 'update')
      .mockResolvedValue(undefined);
    jest
      .spyOn(mockDirectorRepository, 'findOne')
      .mockResolvedValueOnce(updatedDirector);

    const result = await directorService.update(1, updateDirectorDto);

    expect(directorRepository.findOne).toHaveBeenCalledWith({
      where: { id: 1 },
    });
    expect(directorRepository.update).toHaveBeenCalledWith(
      { id: 1 },
      updateDirectorDto,
    );
    expect(directorRepository.findOne).toHaveBeenCalledTimes(2);
    expect(result).toEqual(updatedDirector);
  });

  it('should throw NotFoundException if director to update is not found', async () => {
    jest.spyOn(mockDirectorRepository, 'findOne').mockResolvedValue(null);

    await expect(directorService.update(1, { name: 'John Doe' })).rejects.toThrow(
      NotFoundException,
    );
    expect(mockDirectorRepository.update).not.toHaveBeenCalled();
  });
});
```

#### remove() 테스트

```typescript:src/director/director.service.spec.ts
describe('remove', () => {
  it('should delete a director and return id', async () => {
    const director = {
      id: 1,
      name: 'John Doe',
      dob: new Date('1970-07-30'),
      nationality: 'American',
    };
    
    jest.spyOn(mockDirectorRepository, 'findOne').mockResolvedValue(director);
    jest.spyOn(mockDirectorRepository, 'delete').mockResolvedValue(undefined);

    const result = await directorService.remove(director.id);

    expect(mockDirectorRepository.findOne).toHaveBeenCalledWith({
      where: { id: 1 },
    });
    expect(mockDirectorRepository.delete).toHaveBeenCalledWith(1);
    expect(result).toEqual(1);
  });

  it('should throw NotFoundException if director to delete is not found', async () => {
    jest.spyOn(mockDirectorRepository, 'findOne').mockResolvedValue(null);

    await expect(directorService.remove(1)).rejects.toThrow(NotFoundException);
    expect(mockDirectorRepository.delete).not.toHaveBeenCalled();
  });
});
```

#### 주요 포인트

1. **TypeORM update()**: `update({ id }, data)` 형식으로 호출 (첫 번째 인자는 criteria 객체)
2. **여러 번 호출되는 findOne()**: `mockResolvedValueOnce()`로 각 호출마다 다른 값 반환
3. **에러 케이스**: `not.toHaveBeenCalled()`로 메서드가 호출되지 않았는지 검증

---

### 15.2 DirectorController 테스트하기

#### 기본 설정

```typescript:src/director/director.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { DirectorController } from './director.controller';
import { DirectorService } from './director.service';
import { CreateDirectorDto } from './dto/create-director.dto';
import { UpdateDirectorDto } from './dto/update-director.dto';

const mockDirectorService = {
  create: jest.fn(),
  findAll: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  remove: jest.fn(),
};

describe('DirectorController', () => {
  let controller: DirectorController;
  let service: DirectorService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DirectorController],
      providers: [
        {
          provide: DirectorService,
          useValue: mockDirectorService,
        },
      ],
    }).compile();

    controller = module.get<DirectorController>(DirectorController);
    service = module.get<DirectorService>(DirectorService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
```

#### findAll() 테스트

```typescript:src/director/director.controller.spec.ts
describe('findAll', () => {
  it('should call findAll method from DirectorService', async () => {
    const result = [{ id: 1, name: 'John Doe' }];
    jest.spyOn(mockDirectorService, 'findAll').mockResolvedValue(result);

    const controllerResult = await controller.findAll();
    
    expect(service.findAll).toHaveBeenCalled();
    expect(controllerResult).toEqual(result);
  });
});
```

#### findOne() 테스트

```typescript:src/director/director.controller.spec.ts
describe('findOne', () => {
  it('should call findOne method from DirectorService with correct ID', async () => {
    const result = { id: 1, name: 'John Doe' };
    const id = '1'; // ParseIntPipe로 받으므로 string

    jest.spyOn(mockDirectorService, 'findOne').mockResolvedValue(result);

    const controllerResult = await controller.findOne(id);
    
    expect(service.findOne).toHaveBeenCalledWith(1); // +id로 변환됨
    expect(controllerResult).toEqual(result);
  });
});
```

#### create() 테스트

```typescript:src/director/director.controller.spec.ts
describe('create', () => {
  it('should call create method from DirectorService with correct DTO', async () => {
    const createDirectorDto: CreateDirectorDto = { 
      name: 'John Doe',
      dob: new Date('1970-07-30'),
      nationality: 'American',
    };
    const result = { id: 1, ...createDirectorDto };

    jest.spyOn(mockDirectorService, 'create').mockResolvedValue(result);

    const controllerResult = await controller.create(createDirectorDto);
    
    expect(service.create).toHaveBeenCalledWith(createDirectorDto);
    expect(controllerResult).toEqual(result);
  });
});
```

#### update() 테스트

```typescript:src/director/director.controller.spec.ts
describe('update', () => {
  it('should call update method from DirectorService with correct ID and DTO', async () => {
    const id = '1'; // ParseIntPipe로 받으므로 string
    const updateDirectorDto: UpdateDirectorDto = { name: 'Jane Doe' };
    const result = {
      id: 1,
      name: 'Jane Doe',
    };
    
    jest.spyOn(mockDirectorService, 'update').mockResolvedValue(result);

    const controllerResult = await controller.update(id, updateDirectorDto);
    
    expect(service.update).toHaveBeenCalledWith(1, updateDirectorDto); // +id로 변환됨
    expect(controllerResult).toEqual(result);
  });
});
```

#### remove() 테스트

```typescript:src/director/director.controller.spec.ts
describe('remove', () => {
  it('should call remove method from DirectorService with correct ID', async () => {
    const id = '1'; // ParseIntPipe로 받으므로 string
    const result = 1;
    
    jest.spyOn(mockDirectorService, 'remove').mockResolvedValue(result);

    const controllerResult = await controller.remove(id);
    
    expect(service.remove).toHaveBeenCalledWith(1); // +id로 변환됨
    expect(controllerResult).toEqual(result);
  });
});
```

#### Controller 테스트 특징

1. **ParseIntPipe**: Controller에서 `@Param('id', ParseIntPipe) id: string`로 받지만, 실제로는 `+id`로 숫자 변환되어 Service에 전달
2. **Service Mock**: Controller는 Service의 비즈니스 로직을 테스트하지 않고, 올바른 호출만 검증
3. **비동기 처리**: `async/await` 또는 `resolves.toEqual()` 사용

---

## 정리

### Auth Module 테스트 요약

1. **복잡한 의존성**: JwtService, ConfigService, Cache, UserService 등 여러 의존성 Mock 필요
2. **bcrypt Mock**: `jest.mock('bcrypt')`로 모듈 전체 Mock
3. **토큰 파싱**: Basic/Bearer 토큰 파싱 로직 테스트
4. **에러 처리**: 다양한 예외 케이스 테스트 (BadRequestException, UnauthorizedException)
5. **Service 내부 메서드 Mock**: 같은 서비스의 다른 메서드를 `jest.spyOn(service, 'method')`로 Mock

### Director Module 테스트 요약

1. **간단한 CRUD**: 표준적인 CRUD 기능 테스트
2. **TypeORM update()**: `update({ id }, data)` 형식 주의
3. **여러 번 호출**: `mockResolvedValueOnce()`로 각 호출마다 다른 값 반환
4. **ParseIntPipe**: Controller에서 string으로 받지만 Service에는 number로 전달

### 테스트 작성 패턴

1. **기본 테스트**: `should be defined` 테스트로 시작
2. **성공 케이스**: 정상 동작하는 경우 테스트
3. **에러 케이스**: 예외가 발생하는 경우 테스트
4. **Mock 검증**: 호출 여부, 호출 횟수, 호출 인자 검증
5. **반환값 검증**: 결과값이 예상과 일치하는지 검증

### Best Practices

1. **Mock 초기화**: `afterEach`에서 `jest.clearAllMocks()` 사용
2. **명확한 테스트 이름**: `should [동작] when [조건]` 형식
3. **독립성**: 각 테스트는 독립적으로 실행 가능
4. **AAA 패턴**: Arrange-Act-Assert 구조 유지
5. **커버리지**: 중요한 로직은 높은 커버리지 유지
