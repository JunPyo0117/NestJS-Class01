# Part 27. Swagger 다큐멘테이션

## 목차
1. [Swagger 세팅하기](#1-swagger-세팅하기)
2. [Swagger에서의 토큰 인증](#2-swagger에서의-토큰-인증)
3. [ApiProperty Annotation 알아보기](#3-apiproperty-annotation-알아보기)
4. [ApiOperation 알아보기](#4-apioperation-알아보기)
5. [ApiHideProperty 알아보기](#5-apihideproperty-알아보기)

---

## 1. Swagger 세팅하기

### 1.1 Swagger란?

**Swagger**는 RESTful API를 문서화하고 테스트할 수 있는 도구입니다. OpenAPI 스펙을 기반으로 API의 엔드포인트, 파라미터, 응답 등을 시각적으로 표현합니다.

#### Swagger의 장점

1. **자동 문서화**: 코드에서 자동으로 API 문서 생성
2. **인터랙티브 테스트**: 브라우저에서 직접 API 테스트 가능
3. **타입 안정성**: DTO와 실제 API 스펙 일치 보장
4. **협업 효율성**: 프론트엔드 개발자와의 소통 원활

### 1.2 Swagger 설치

```bash
npm install @nestjs/swagger
```

### 1.3 Swagger 기본 설정

`main.ts`에서 Swagger를 설정합니다.

```typescript:src/main.ts
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Swagger 설정
  const config = new DocumentBuilder()
    .setTitle('Netflix API')
    .setDescription('Netflix API Description')
    .setVersion('1.0')
    .addBasicAuth()
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);

  SwaggerModule.setup('doc', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
    },
  });

  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
```

### 1.4 DocumentBuilder 옵션

#### 기본 정보 설정

```typescript
const config = new DocumentBuilder()
  .setTitle('Netflix API')           // API 제목
  .setDescription('Netflix API Description')  // API 설명
  .setVersion('1.0')                 // API 버전
  .build();
```

#### 인증 방식 추가

```typescript
.addBasicAuth()    // Basic 인증 추가
.addBearerAuth()   // Bearer 토큰 인증 추가
```

#### 추가 옵션

```typescript
.addTag('Movie', '영화 관련 API')  // 태그 추가
.addServer('http://localhost:3000', '로컬 서버')  // 서버 URL 추가
.setContact('Contact', 'https://example.com', 'contact@example.com')  // 연락처
.setLicense('MIT', 'https://opensource.org/licenses/MIT')  // 라이선스
```

### 1.5 Swagger UI 접근

설정이 완료되면 다음 URL로 접근할 수 있습니다:

```
http://localhost:3000/doc
```

### 1.6 SwaggerOptions

```typescript
SwaggerModule.setup('doc', app, document, {
  swaggerOptions: {
    persistAuthorization: true,  // 인증 정보 유지
    tagsSorter: 'alpha',         // 태그 알파벳 순 정렬
    operationsSorter: 'alpha',   // 작업 알파벳 순 정렬
  },
});
```

#### 주요 옵션

| 옵션 | 설명 | 기본값 |
|------|------|-------|
| `persistAuthorization` | 인증 정보를 브라우저에 저장 | `false` |
| `tagsSorter` | 태그 정렬 방식 (`alpha`, `method`) | - |
| `operationsSorter` | 작업 정렬 방식 (`alpha`, `method`) | - |
| `docExpansion` | 문서 확장 상태 (`none`, `list`, `full`) | `list` |

---

## 2. Swagger에서의 토큰 인증

### 2.1 Bearer Token 인증

Bearer Token은 JWT 토큰을 사용한 인증 방식입니다.

#### 컨트롤러에 적용

```typescript:src/movie/movie.controller.ts
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';

@Controller('movie')
@ApiBearerAuth()  // Bearer Token 인증 필요
@ApiTags('Movie')
export class MovieController {
  // ...
}
```

#### 전역 적용

컨트롤러 레벨에서 `@ApiBearerAuth()`를 사용하면 해당 컨트롤러의 모든 엔드포인트에 Bearer Token 인증이 필요합니다.

#### 개별 엔드포인트 적용

```typescript
@Get()
@ApiBearerAuth()  // 이 엔드포인트만 Bearer Token 필요
getMovies() {
  // ...
}
```

### 2.2 Basic Auth 인증

Basic Auth는 사용자명과 비밀번호를 Base64로 인코딩하여 전송하는 인증 방식입니다.

#### 컨트롤러에 적용

```typescript:src/auth/auth.controller.ts
import { ApiBasicAuth, ApiBearerAuth, ApiTags } from '@nestjs/swagger';

@Controller('auth')
@ApiBearerAuth()
@ApiTags('Auth')
export class AuthController {
  @Public()
  @ApiBasicAuth()  // Basic Auth 인증 필요
  @Post('register')
  registerUser(@Authorization() token: string) {
    return this.authService.register(token);
  }

  @Public()
  @ApiBasicAuth()  // Basic Auth 인증 필요
  @Post('login')
  loginUser(@Authorization() token: string) {
    return this.authService.login(token);
  }
}
```

### 2.3 Swagger UI에서 인증 사용하기

#### Bearer Token 인증

1. Swagger UI 오른쪽 상단의 **"Authorize"** 버튼 클릭
2. `bearerAuth` 섹션에서 토큰 입력
3. `Bearer` 접두사 없이 토큰만 입력 (예: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`)
4. **"Authorize"** 버튼 클릭

#### Basic Auth 인증

1. **"Authorize"** 버튼 클릭
2. `basicAuth` 섹션에서 사용자명과 비밀번호 입력
3. **"Authorize"** 버튼 클릭

### 2.4 인증 정보 유지

`persistAuthorization: true` 옵션을 설정하면 인증 정보가 브라우저에 저장되어 페이지를 새로고침해도 유지됩니다.

```typescript
SwaggerModule.setup('doc', app, document, {
  swaggerOptions: {
    persistAuthorization: true,
  },
});
```

### 2.5 Public 엔드포인트 처리

`@Public()` 데코레이터를 사용한 엔드포인트는 Swagger에서도 인증이 필요 없습니다.

```typescript
@Get()
@Public()  // 인증 불필요
@ApiOperation({ description: '[Movie]를 페이지네이션 하는 API' })
getMovies() {
  // ...
}
```

---

## 3. ApiProperty Annotation 알아보기

### 3.1 ApiProperty란?

`@ApiProperty()` 데코레이터는 DTO의 속성을 Swagger 문서에 명시적으로 정의합니다. 각 속성의 타입, 설명, 예시 등을 지정할 수 있습니다.

### 3.2 기본 사용법

```typescript:src/movie/dto/create-movie.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsNumber, IsArray } from 'class-validator';

export class CreateMovieDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    description: '영화 제목',
    example: 'The Dark Knight',
  })
  title: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    description: '영화 상세 내용',
    example: 'The Dark Knight is a superhero movie',
  })
  detail: string;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty({
    description: '감독 객체 ID',
    example: 1,
  })
  directorId: number;

  @IsArray()
  @IsNumber({}, { each: true })
  @ApiProperty({
    description: '장르 객체 ID 배열',
    example: [1, 2, 3],
  })
  genreIds: number[];

  @IsString()
  @ApiProperty({
    description: '영화 파일 이름',
    example: 'aaa-bbb-ccc-ddd.mp4',
  })
  movieFileName: string;
}
```

### 3.3 ApiProperty 옵션

#### 기본 옵션

```typescript
@ApiProperty({
  description: '속성 설명',      // 속성 설명
  example: '예시 값',            // 예시 값
  type: String,                 // 타입 명시
  required: true,                // 필수 여부
  default: '기본값',            // 기본값
})
```

#### 배열 타입

```typescript
@ApiProperty({
  description: '장르 객체 ID 배열',
  example: [1, 2, 3],
  type: [Number],              // 배열 타입 명시
  isArray: true,               // 배열임을 명시
  required: false,             // 선택적 파라미터
})
genreIds: number[];
```

#### 열거형(Enum)

```typescript
enum Role {
  Admin = 0,
  User = 1,
}

@ApiProperty({
  description: '사용자 역할',
  example: Role.Admin,
  enum: Role,                 // Enum 타입
})
role: Role;
```

#### 객체 타입

```typescript
@ApiProperty({
  description: '사용자 정보',
  type: UserDto,              // DTO 타입 참조
})
user: UserDto;
```

### 3.4 선택적 속성

```typescript
@ApiProperty({
  description: '영화 제목',
  example: 'The Dark Knight',
  required: false,            // 선택적 속성
})
title?: string;
```

### 3.5 기본값 설정

```typescript
@ApiProperty({
  description: '페이지네이션 페이지 당 아이템 수',
  example: 5,
  default: 5,                 // 기본값
  required: false,
})
take: number = 5;
```

### 3.6 실제 사용 예제

#### CursorPaginationDto

```typescript:src/common/dto/cursor-pagination.dto.ts
import { ApiProperty } from '@nestjs/swagger';

export class CursorPaginationDto {
  @ApiProperty({
    description: '페이지네이션 커서',
    example: 'eyJ2YWx1ZXMiOnsiaWQiOjF9LCJvcmRlciI6WyJpZF9ERVNDIl19',
    required: false,
  })
  cursor?: string;

  @ApiProperty({
    description: '내림차순, 오름차순 정렬',
    example: ['id_DESC'],
    type: [String],
    isArray: true,
    required: false,
  })
  order: string[] = ['id_DESC'];

  @ApiProperty({
    description: '페이지네이션 페이지 당 아이템 수',
    example: 5,
    type: Number,
    required: false,
    default: 5,
  })
  take: number = 5;
}
```

### 3.7 ApiProperty의 장점

1. **명확한 문서화**: 각 속성의 의미와 타입을 명확히 표현
2. **예시 제공**: 개발자가 쉽게 이해할 수 있는 예시 값 제공
3. **타입 안정성**: Swagger UI에서 올바른 타입으로 입력 가능
4. **자동 검증**: class-validator와 함께 사용하여 자동 검증

---

## 4. ApiOperation 알아보기

### 4.1 ApiOperation이란?

`@ApiOperation()` 데코레이터는 API 엔드포인트에 대한 설명을 추가합니다. 각 엔드포인트의 목적, 동작 방식, 사용 시나리오 등을 문서화할 수 있습니다.

### 4.2 기본 사용법

```typescript:src/movie/movie.controller.ts
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';

@Controller('movie')
@ApiTags('Movie')
export class MovieController {
  @Get()
  @ApiOperation({ 
    description: '[Movie]를 페이지네이션 하는 API' 
  })
  getMovies() {
    return this.movieService.findAll();
  }
}
```

### 4.3 ApiOperation 옵션

```typescript
@ApiOperation({
  summary: '영화 목록 조회',           // 간단한 요약
  description: '영화 목록을 페이지네이션하여 조회합니다.',  // 상세 설명
  operationId: 'getMovies',           // 고유 식별자
  deprecated: false,                  // 사용 중단 여부
})
```

### 4.4 ApiResponse와 함께 사용

```typescript:src/movie/movie.controller.ts
@Get()
@ApiOperation({ description: '[Movie]를 페이지네이션 하는 API' })
@ApiResponse({ 
  status: 200, 
  description: '영화 목록 조회 성공' 
})
@ApiResponse({
  status: 400,
  description: '페이지네이션 데이터를 잘못 입력 했을 때',
})
getMovies(@Query() dto: GetMoviesDto) {
  return this.movieService.findAll(dto);
}
```

### 4.5 다양한 응답 상태 코드 문서화

```typescript
@Post()
@ApiOperation({ 
  summary: '영화 생성',
  description: '새로운 영화를 생성합니다. 관리자 권한이 필요합니다.',
})
@ApiResponse({ 
  status: 201, 
  description: '영화 생성 성공' 
})
@ApiResponse({
  status: 400,
  description: '잘못된 요청 데이터',
})
@ApiResponse({
  status: 401,
  description: '인증되지 않은 사용자',
})
@ApiResponse({
  status: 403,
  description: '권한이 없는 사용자',
})
createMovie(@Body() body: CreateMovieDto) {
  return this.movieService.create(body);
}
```

### 4.6 실제 사용 예제

```typescript:src/movie/movie.controller.ts
@Get()
@Public()
@Throttle({ count: 5, unit: 'minute', ttl: 60000 })
@ApiOperation({ description: '[Movie]를 페이지네이션 하는 API' })
@ApiResponse({ status: 200, description: '영화 목록 조회 성공' })
@ApiResponse({
  status: 400,
  description: '페이지네이션 데이터를 잘못 입력 했을 때',
})
getMovies(@Query() dto: GetMoviesDto, @UserId() UserId?: number) {
  return this.movieService.findAll(dto, UserId);
}
```

### 4.7 ApiOperation의 장점

1. **명확한 API 설명**: 각 엔드포인트의 목적과 사용법 명확히 표현
2. **에러 처리 문서화**: 다양한 에러 상황과 응답 코드 문서화
3. **협업 효율성**: 프론트엔드 개발자가 API 사용법을 쉽게 이해
4. **유지보수성**: API 변경 시 문서도 함께 업데이트

---

## 5. ApiHideProperty 알아보기

### 5.1 ApiHideProperty란?

`@ApiHideProperty()` 데코레이터는 Swagger 문서에서 특정 속성을 숨기는 데 사용합니다. 내부적으로만 사용되는 속성이나 민감한 정보를 문서에서 제외할 수 있습니다.

### 5.2 기본 사용법

```typescript:src/common/entity/base-table.entity.ts
import { ApiHideProperty } from '@nestjs/swagger';
import { Exclude } from 'class-transformer';

@Entity()
export class BaseTable {
  @CreateDateColumn()
  @Exclude()
  @ApiHideProperty()  // Swagger 문서에서 숨김
  createdAt: Date;

  @UpdateDateColumn()
  @Exclude()
  @ApiHideProperty()  // Swagger 문서에서 숨김
  updatedAt: Date;

  @VersionColumn()
  @Exclude()
  @ApiHideProperty()  // Swagger 문서에서 숨김
  version: number;
}
```

### 5.3 사용 시나리오

#### 1. 내부 관리 필드

```typescript
@Entity()
export class Movie extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @CreateDateColumn()
  @ApiHideProperty()  // 생성일시는 내부 관리용
  createdAt: Date;
}
```

#### 2. 민감한 정보

```typescript
@Entity()
export class User {
  @Column()
  email: string;

  @Column()
  @ApiHideProperty()  // 비밀번호는 문서에서 숨김
  password: string;
}
```

#### 3. 계산된 필드

```typescript
@Entity()
export class Movie {
  @Column()
  likeCount: number;

  @Column()
  dislikeCount: number;

  // 계산된 필드는 Swagger에서 숨김
  get totalVotes(): number {
    return this.likeCount + this.dislikeCount;
  }
}
```

### 5.4 Exclude와의 차이

#### @Exclude()

- **용도**: 응답에서 필드를 제외
- **적용 시점**: 런타임 (실제 응답 데이터)
- **사용 위치**: `class-transformer`

```typescript
@CreateDateColumn()
@Exclude()  // 응답에서 제외
createdAt: Date;
```

#### @ApiHideProperty()

- **용도**: Swagger 문서에서 필드를 숨김
- **적용 시점**: 문서 생성 시
- **사용 위치**: `@nestjs/swagger`

```typescript
@CreateDateColumn()
@ApiHideProperty()  // Swagger 문서에서 숨김
createdAt: Date;
```

### 5.5 함께 사용하기

일반적으로 두 데코레이터를 함께 사용합니다:

```typescript:src/common/entity/base-table.entity.ts
@CreateDateColumn()
@Exclude()              // 응답에서 제외
@ApiHideProperty()      // Swagger 문서에서 숨김
createdAt: Date;
```

**이유:**
- `@Exclude()`: 실제 API 응답에서 필드 제외
- `@ApiHideProperty()`: Swagger 문서에서 필드 숨김

### 5.6 실제 사용 예제

#### BaseTable 엔티티

```typescript:src/common/entity/base-table.entity.ts
import { ApiHideProperty } from '@nestjs/swagger';
import { Exclude } from 'class-transformer';
import {
  CreateDateColumn,
  Entity,
  UpdateDateColumn,
  VersionColumn,
} from 'typeorm';

@Entity()
export class BaseTable {
  @CreateDateColumn()
  @Exclude()
  @ApiHideProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @Exclude()
  @ApiHideProperty()
  updatedAt: Date;

  @VersionColumn()
  @Exclude()
  @ApiHideProperty()
  version: number;
}
```

이렇게 하면:
- API 응답에서 `createdAt`, `updatedAt`, `version` 필드가 제외됨
- Swagger 문서에서도 해당 필드가 표시되지 않음

### 5.7 ApiHideProperty의 장점

1. **문서 정리**: 불필요한 정보를 문서에서 제거하여 가독성 향상
2. **보안**: 민감한 정보를 문서에서 숨김
3. **명확성**: 사용자가 알아야 할 정보만 표시
4. **유지보수**: 내부 필드 변경 시 문서 영향 최소화

---

## 정리

### Swagger 데코레이터 비교

| 데코레이터 | 용도 | 적용 위치 | 예시 |
|-----------|------|----------|------|
| `@ApiProperty()` | 속성 문서화 | DTO 속성 | `@ApiProperty({ description: '...' })` |
| `@ApiOperation()` | 엔드포인트 설명 | 컨트롤러 메서드 | `@ApiOperation({ description: '...' })` |
| `@ApiResponse()` | 응답 상태 코드 문서화 | 컨트롤러 메서드 | `@ApiResponse({ status: 200 })` |
| `@ApiBearerAuth()` | Bearer Token 인증 | 컨트롤러/메서드 | `@ApiBearerAuth()` |
| `@ApiBasicAuth()` | Basic Auth 인증 | 컨트롤러/메서드 | `@ApiBasicAuth()` |
| `@ApiTags()` | 태그 그룹화 | 컨트롤러 | `@ApiTags('Movie')` |
| `@ApiHideProperty()` | 속성 숨김 | 엔티티/DTO 속성 | `@ApiHideProperty()` |

### 주요 개념

1. **Swagger**: RESTful API 문서화 및 테스트 도구
2. **DocumentBuilder**: Swagger 설정 빌더
3. **ApiProperty**: DTO 속성 문서화
4. **ApiOperation**: API 엔드포인트 설명
5. **ApiHideProperty**: 문서에서 속성 숨김

### 실전 팁

1. **일관성 유지**: 모든 DTO에 `@ApiProperty()` 추가
2. **명확한 설명**: `description`과 `example`을 명확하게 작성
3. **에러 문서화**: 모든 가능한 에러 응답을 `@ApiResponse()`로 문서화
4. **태그 활용**: 관련된 API를 `@ApiTags()`로 그룹화
5. **인증 명시**: 인증이 필요한 API에 `@ApiBearerAuth()` 또는 `@ApiBasicAuth()` 추가
6. **민감 정보 보호**: 민감한 정보는 `@ApiHideProperty()`로 숨김
