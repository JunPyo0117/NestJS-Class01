# QueryBuilder

## 목차
1. [QueryBuilder 이론](#querybuilder-이론)
2. [QueryBuilder 사용하는 방식으로 로직 변경하기](#querybuilder-사용하는-방식으로-로직-변경하기)

---

## QueryBuilder 이론

### QueryBuilder란?

**QueryBuilder**는 TypeORM에서 제공하는 SQL 쿼리를 프로그래밍 방식으로 작성할 수 있게 해주는 도구입니다.

### QueryBuilder를 사용하는 이유

1. **복잡한 쿼리 작성**: JOIN, 서브쿼리, 복잡한 WHERE 조건 등을 쉽게 작성할 수 있습니다.
2. **성능 최적화**: 필요한 데이터만 선택적으로 조회할 수 있습니다.
3. **동적 쿼리**: 조건에 따라 쿼리를 동적으로 생성할 수 있습니다.
4. **타입 안정성**: TypeScript의 타입 체크를 활용할 수 있습니다.

### QueryBuilder 기본 구조

```typescript
const qb = this.repository
  .createQueryBuilder('alias')  // 엔티티 별칭 지정
  .select('alias.field')         // SELECT 절
  .where('alias.id = :id', { id: 1 })  // WHERE 절
  .getOne();                     // 실행
```

### QueryBuilder 주요 메서드

#### 1. createQueryBuilder()

QueryBuilder 인스턴스를 생성합니다.

```typescript
const qb = this.movieRepository.createQueryBuilder('movie');
```

- **반환 타입**: `SelectQueryBuilder<Movie>` (동기 메서드)
- **매개변수**: 엔티티의 별칭(alias) 지정
- **주의**: `await`를 사용하지 않습니다. (Promise를 반환하지 않음)

#### 2. leftJoinAndSelect()

LEFT JOIN을 수행하고 결과를 선택합니다.

```typescript
.leftJoinAndSelect('movie.director', 'director')
.leftJoinAndSelect('movie.genres', 'genres')
```

- **첫 번째 인자**: 관계 경로 (`'movie.director'`)
- **두 번째 인자**: JOIN된 테이블의 별칭 (`'director'`)
- **기능**: 관계된 엔티티를 함께 조회합니다.

#### 3. where()

WHERE 조건을 추가합니다.

```typescript
.where('movie.id = :id', { id: 1 })
.where('movie.title LIKE :title', { title: '%인셉션%' })
```

- **첫 번째 인자**: SQL 조건 문자열 (파라미터 바인딩 사용)
- **두 번째 인자**: 파라미터 객체
- **보안**: 파라미터 바인딩을 사용하여 SQL Injection을 방지합니다.

#### 4. getOne(), getMany(), getManyAndCount()

쿼리를 실행하고 결과를 반환합니다.

```typescript
const movie = await qb.getOne();              // 단일 엔티티
const movies = await qb.getMany();            // 엔티티 배열
const [movies, count] = await qb.getManyAndCount();  // 엔티티 배열 + 개수
```

- **getOne()**: 단일 엔티티 반환 (없으면 `null`)
- **getMany()**: 엔티티 배열 반환
- **getManyAndCount()**: `[엔티티 배열, 개수]` 튜플 반환

### QueryBuilder vs Repository 메서드 비교

#### Repository 메서드 (기존 방식)

```typescript
const movies = await this.movieRepository.find({
  where: { title: Like('%인셉션%') },
  relations: ['director', 'genres'],
});
```

**장점**:
- 간단하고 직관적
- TypeORM이 자동으로 쿼리 생성

**단점**:
- 복잡한 쿼리 작성이 어려움
- 성능 최적화가 제한적

#### QueryBuilder (새로운 방식)

```typescript
const movies = await this.movieRepository
  .createQueryBuilder('movie')
  .leftJoinAndSelect('movie.director', 'director')
  .leftJoinAndSelect('movie.genres', 'genres')
  .where('movie.title LIKE :title', { title: '%인셉션%' })
  .getMany();
```

**장점**:
- 복잡한 쿼리 작성 가능
- 성능 최적화 가능
- 동적 쿼리 생성 용이

**단점**:
- 코드가 더 길어짐
- SQL 지식 필요

---

## QueryBuilder 사용하는 방식으로 로직 변경하기

### 1. findAll() - SELECT 쿼리

**파일**: `src/movie/movie.service.ts`

#### 기존 방식 (Repository 메서드)

```typescript
async findAll(title?: string) {
  if (!title) {
    return [
      await this.movieRepository.find({ 
        relations: ['director', 'genres'] 
      }),
      await this.movieRepository.count(),
    ];
  }

  if (title) {
    return await this.movieRepository.findAndCount({
      where: { title: Like(`%${title}%`) },
      relations: ['director', 'genres'],
    });
  }
}
```

#### QueryBuilder 방식

```typescript
async findAll(title?: string) {
  const qb = this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres');
    
  if (title) {
    qb.where('movie.title LIKE :title', { title: `%${title}%` });
  }

  return await qb.getManyAndCount();
}
```

**설명**:
1. **createQueryBuilder('movie')**: Movie 엔티티에 'movie' 별칭 부여
2. **leftJoinAndSelect()**: Director와 Genre 관계를 LEFT JOIN으로 조회
3. **조건부 where()**: `title`이 제공되면 WHERE 조건 추가
4. **getManyAndCount()**: 결과 배열과 개수를 함께 반환

**장점**:
- 조건부 쿼리를 하나의 QueryBuilder로 처리
- 코드가 더 간결하고 읽기 쉬움

### 2. findOne() - 단일 조회

**파일**: `src/movie/movie.service.ts`

#### 기존 방식

```typescript
async findOne(id: number) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director', 'genres'],
  });

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  return movie;
}
```

#### QueryBuilder 방식

```typescript
async findOne(id: number) {
  const movie = await this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres')
    .leftJoinAndSelect('movie.detail', 'detail')
    .where('movie.id = :id', { id })
    .getOne();

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  return movie;
}
```

**설명**:
- **where('movie.id = :id', { id })**: 파라미터 바인딩을 사용한 WHERE 조건
- **getOne()**: 단일 엔티티 반환

### 3. create() - INSERT 쿼리

**파일**: `src/movie/movie.service.ts`

#### 기존 방식 (save 메서드)

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  // ... Director, Genre 조회

  const movie = await this.movieRepository.save({
    title: CreateMovieDto.title,
    detail: {
      detail: CreateMovieDto.detail,
    },
    director: director,
    genres: genres,
  });

  return movie;
}
```

#### QueryBuilder 방식 (insert)

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  // 1. Director, Genre 조회 (동일)
  const director = await this.directorRepository.findOne({
    where: { id: CreateMovieDto.directorId },
  });

  const genres = await this.genreRepository.find({
    where: { id: In(CreateMovieDto.genreIds) },
  });

  // 2. MovieDetail 먼저 생성
  const movieDetail = await this.movieDetailRepository
    .createQueryBuilder()
    .insert()
    .into(MovieDetail)
    .values({
      detail: CreateMovieDto.detail,
    })
    .execute();

  const movieDetailId = movieDetail.identifiers[0].id;

  // 3. Movie 생성
  const movie = await this.movieRepository
    .createQueryBuilder()
    .insert()
    .into(Movie)
    .values({
      title: CreateMovieDto.title,
      detail: {
        id: movieDetailId,
      },
      director: director,
    })
    .execute();

  const movieId = movie.identifiers[0].id;

  // 4. Many-to-Many 관계 설정
  await this.movieRepository
    .createQueryBuilder()
    .relation(Movie, 'genres')
    .of(movieId)
    .add(genres.map((genre) => genre.id));

  // 5. 최종 결과 반환
  return this.movieRepository.findOne({
    where: { id: movieId },
    relations: ['detail', 'director', 'genres'],
  });
}
```

**설명**:

1. **insert()**: INSERT 쿼리 생성
2. **into(MovieDetail)**: 삽입할 엔티티 지정
3. **values({ ... })**: 삽입할 값 지정
4. **execute()**: 쿼리 실행
5. **identifiers[0].id**: 생성된 레코드의 ID 가져오기
   - `execute()`는 `InsertResult`를 반환하며, `identifiers` 배열에 생성된 레코드의 ID가 포함됩니다.
6. **relation()**: Many-to-Many 관계 설정
   - `.relation(Movie, 'genres')`: Movie 엔티티의 'genres' 관계 지정
   - `.of(movieId)`: 관계를 설정할 Movie의 ID
   - `.add(genreIds)`: 관계에 추가할 Genre ID 배열

**장점**:
- 단계별로 명확하게 처리
- Many-to-Many 관계를 별도로 관리 가능

### 4. update() - UPDATE 쿼리

**파일**: `src/movie/movie.service.ts`

#### 기존 방식

```typescript
await this.movieRepository.update({ id }, movieUpdateFields);

await this.movieDetailRepository.update(
  { id: movie.detail.id },
  { detail },
);
```

#### QueryBuilder 방식

```typescript
// Movie 업데이트
await this.movieRepository
  .createQueryBuilder()
  .update(Movie)
  .set(movieUpdateFields)
  .where('id = :id', { id })
  .execute();

// MovieDetail 업데이트
if (detail) {
  await this.movieDetailRepository
    .createQueryBuilder()
    .update(MovieDetail)
    .set({ detail })
    .where('id = :id', { id: movie.detail.id })
    .execute();
}

// Many-to-Many 관계 업데이트
if (newGenres) {
  await this.movieRepository
    .createQueryBuilder()
    .relation(Movie, 'genres')
    .of(id)
    .addAndRemove(
      newGenres.map((genre) => genre.id),      // 추가할 장르
      movie.genres.map((genre) => genre.id),    // 제거할 장르
    );
}
```

**설명**:

1. **update(Movie)**: UPDATE 쿼리 생성
2. **set({ ... })**: 업데이트할 필드와 값 지정
3. **where('id = :id', { id })**: WHERE 조건
4. **execute()**: 쿼리 실행
5. **addAndRemove()**: Many-to-Many 관계 추가 및 제거
   - 첫 번째 인자: 추가할 관계 ID 배열
   - 두 번째 인자: 제거할 관계 ID 배열

**장점**:
- 명시적으로 어떤 필드를 업데이트하는지 명확
- Many-to-Many 관계를 효율적으로 관리

### 5. remove() - DELETE 쿼리

**파일**: `src/movie/movie.service.ts`

#### 기존 방식

```typescript
await this.movieRepository.delete(id);
```

#### QueryBuilder 방식

```typescript
await this.movieRepository
  .createQueryBuilder()
  .delete()
  .where('id = :id', { id })
  .execute();
```

**설명**:
- **delete()**: DELETE 쿼리 생성
- **where('id = :id', { id })**: 삭제 조건
- **execute()**: 쿼리 실행

---

## QueryBuilder의 relation() 메서드

### Many-to-Many 관계 관리

QueryBuilder의 `relation()` 메서드를 사용하면 Many-to-Many 관계를 효율적으로 관리할 수 있습니다.

#### 1. add() - 관계 추가

```typescript
await this.movieRepository
  .createQueryBuilder()
  .relation(Movie, 'genres')
  .of(movieId)
  .add(genreIds);
```

**설명**:
- `relation(Movie, 'genres')`: Movie 엔티티의 'genres' 관계 지정
- `of(movieId)`: 관계를 설정할 Movie의 ID
- `add(genreIds)`: 추가할 Genre ID 배열

#### 2. remove() - 관계 제거

```typescript
await this.movieRepository
  .createQueryBuilder()
  .relation(Movie, 'genres')
  .of(movieId)
  .remove(genreIds);
```

**설명**:
- `remove(genreIds)`: 제거할 Genre ID 배열

#### 3. addAndRemove() - 관계 추가 및 제거

```typescript
await this.movieRepository
  .createQueryBuilder()
  .relation(Movie, 'genres')
  .of(movieId)
  .addAndRemove(
    genreIdsToAdd,    // 추가할 장르 ID 배열
    genreIdsToRemove  // 제거할 장르 ID 배열
  );
```

**설명**:
- 한 번의 호출로 관계를 추가하고 제거할 수 있습니다.
- 기존 관계를 모두 제거하고 새로운 관계를 추가하는 것보다 효율적입니다.

---

## QueryBuilder 주요 메서드 정리

### SELECT 관련

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `createQueryBuilder('alias')` | QueryBuilder 생성 | `SelectQueryBuilder<T>` |
| `leftJoinAndSelect(relation, alias)` | LEFT JOIN 및 선택 | `SelectQueryBuilder<T>` |
| `innerJoinAndSelect(relation, alias)` | INNER JOIN 및 선택 | `SelectQueryBuilder<T>` |
| `where(condition, params)` | WHERE 조건 추가 | `SelectQueryBuilder<T>` |
| `andWhere(condition, params)` | AND WHERE 조건 추가 | `SelectQueryBuilder<T>` |
| `orWhere(condition, params)` | OR WHERE 조건 추가 | `SelectQueryBuilder<T>` |
| `getOne()` | 단일 엔티티 반환 | `Promise<T \| null>` |
| `getMany()` | 엔티티 배열 반환 | `Promise<T[]>` |
| `getManyAndCount()` | 엔티티 배열 + 개수 반환 | `Promise<[T[], number]>` |

### INSERT 관련

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `insert()` | INSERT 쿼리 생성 | `InsertQueryBuilder<T>` |
| `into(entity)` | 삽입할 엔티티 지정 | `InsertQueryBuilder<T>` |
| `values(values)` | 삽입할 값 지정 | `InsertQueryBuilder<T>` |
| `execute()` | 쿼리 실행 | `Promise<InsertResult>` |

### UPDATE 관련

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `update(entity)` | UPDATE 쿼리 생성 | `UpdateQueryBuilder<T>` |
| `set(values)` | 업데이트할 값 지정 | `UpdateQueryBuilder<T>` |
| `where(condition, params)` | WHERE 조건 추가 | `UpdateQueryBuilder<T>` |
| `execute()` | 쿼리 실행 | `Promise<UpdateResult>` |

### DELETE 관련

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `delete()` | DELETE 쿼리 생성 | `DeleteQueryBuilder<T>` |
| `where(condition, params)` | WHERE 조건 추가 | `DeleteQueryBuilder<T>` |
| `execute()` | 쿼리 실행 | `Promise<DeleteResult>` |

### RELATION 관련

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `relation(entity, relation)` | 관계 지정 | `RelationQueryBuilder<T>` |
| `of(id)` | 관계를 설정할 엔티티 ID | `RelationQueryBuilder<T>` |
| `add(ids)` | 관계 추가 | `Promise<void>` |
| `remove(ids)` | 관계 제거 | `Promise<void>` |
| `addAndRemove(addIds, removeIds)` | 관계 추가 및 제거 | `Promise<void>` |

---

## 파라미터 바인딩

### 파라미터 바인딩이란?

파라미터 바인딩은 SQL 쿼리에 값을 직접 삽입하는 대신, 플레이스홀더(`:paramName`)를 사용하고 값을 별도로 전달하는 방식입니다.

### 사용 예시

```typescript
// ✅ 올바른 방법 (파라미터 바인딩)
.where('movie.title LIKE :title', { title: '%인셉션%' })
.where('movie.id = :id', { id: 1 })

// ❌ 잘못된 방법 (SQL Injection 위험)
.where(`movie.title LIKE '%인셉션%'`)
.where(`movie.id = ${id}`)
```

### 파라미터 바인딩의 장점

1. **SQL Injection 방지**: 사용자 입력을 안전하게 처리
2. **성능 향상**: 쿼리 플랜 재사용 가능
3. **타입 안정성**: TypeScript 타입 체크 활용

---

## 프로젝트 파일 구조

```
src/
└── movie/
    └── movie.service.ts
        ├── findAll()          # QueryBuilder SELECT
        ├── findOne()          # QueryBuilder SELECT
        ├── create()           # QueryBuilder INSERT + relation
        ├── update()            # QueryBuilder UPDATE + relation
        └── remove()           # QueryBuilder DELETE
```

---

## 핵심 개념 정리

### 1. QueryBuilder 생성

- `createQueryBuilder('alias')`: 동기 메서드, `await` 불필요
- 별칭(alias)을 지정하여 엔티티를 참조

### 2. JOIN 처리

- `leftJoinAndSelect()`: LEFT JOIN 및 결과 선택
- `innerJoinAndSelect()`: INNER JOIN 및 결과 선택

### 3. 조건 처리

- `where()`: WHERE 조건 추가
- 파라미터 바인딩 사용 (`:paramName`)

### 4. INSERT 처리

- `insert().into().values().execute()`
- `identifiers[0].id`로 생성된 ID 가져오기

### 5. UPDATE 처리

- `update().set().where().execute()`
- Many-to-Many 관계는 `relation()` 메서드 사용

### 6. DELETE 처리

- `delete().where().execute()`

### 7. Many-to-Many 관계 관리

- `relation().of().add()`: 관계 추가
- `relation().of().remove()`: 관계 제거
- `relation().of().addAndRemove()`: 관계 추가 및 제거

---

## 참고사항

1. **createQueryBuilder()는 동기 메서드**: `await`를 사용하지 않습니다.
2. **파라미터 바인딩 필수**: SQL Injection 방지를 위해 항상 사용합니다.
3. **execute()는 비동기**: INSERT, UPDATE, DELETE의 `execute()`는 `await`가 필요합니다.
4. **identifiers 사용**: INSERT 후 생성된 ID는 `identifiers[0].id`로 가져옵니다.
5. **relation() 메서드**: Many-to-Many 관계를 효율적으로 관리할 수 있습니다.
