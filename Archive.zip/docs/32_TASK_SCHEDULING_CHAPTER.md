# Part 24. Task Scheduling

## 목차
1. [Task Scheduling 이론](#1-task-scheduling-이론)
2. [Cron 작업 등록해보기](#2-cron-작업-등록해보기)
3. [잉여 파일 삭제 기능 구현하기](#3-잉여-파일-삭제-기능-구현하기)
4. [좋아요, 싫어요 통계 기능 구현하기](#4-좋아요-싫어요-통계-기능-구현하기)
5. [다이나믹 타스크 스케쥴링](#5-다이나믹-타스크-스케쥴링)

---

## 1. Task Scheduling 이론

### 1.1 Task Scheduling이란?

**Task Scheduling(작업 스케줄링)**은 특정 시간이나 주기적으로 자동으로 실행되는 작업을 관리하는 기능입니다. 주기적인 데이터 정리, 통계 계산, 알림 발송 등의 작업에 사용됩니다.

#### Task Scheduling의 목적

1. **자동화**: 수동 작업을 자동으로 처리
2. **정기적 유지보수**: 데이터베이스 정리, 통계 업데이트 등
3. **리소스 관리**: 서버 리소스를 효율적으로 활용

### 1.2 Cron 표현식

Cron은 유닉스 계열 운영체제에서 사용하는 시간 기반 작업 스케줄러입니다. NestJS에서는 `@nestjs/schedule` 패키지를 통해 Cron 기능을 제공합니다.

#### Cron 표현식 형식

```
* * * * * *
│ │ │ │ │ │
│ │ │ │ │ └─── 요일 (0-7, 0과 7은 일요일)
│ │ │ │ └───── 월 (1-12)
│ │ │ └─────── 일 (1-31)
│ │ └───────── 시 (0-23)
│ └─────────── 분 (0-59)
└───────────── 초 (0-59) - NestJS에서 추가
```

#### Cron 표현식 예제

| 표현식 | 설명 |
|--------|------|
| `* * * * * *` | 매초 실행 |
| `0 * * * * *` | 매분 0초에 실행 |
| `0 0 * * * *` | 매시간 0분 0초에 실행 |
| `0 0 0 * * *` | 매일 자정에 실행 |
| `*/5 * * * * *` | 5초마다 실행 |
| `0 */30 * * * *` | 30분마다 실행 |
| `0 0 0 * * 0` | 매주 일요일 자정에 실행 |

### 1.3 NestJS Schedule Module

NestJS는 `@nestjs/schedule` 패키지를 통해 강력한 스케줄링 기능을 제공합니다.

#### 주요 기능

1. **@Cron 데코레이터**: 메서드에 Cron 작업 등록
2. **@Interval 데코레이터**: 일정 간격으로 실행
3. **@Timeout 데코레이터**: 일정 시간 후 실행
4. **SchedulerRegistry**: 동적으로 작업 관리

---

## 2. Cron 작업 등록해보기

### 2.1 ScheduleModule 설정

먼저 `AppModule`에 `ScheduleModule`을 등록해야 합니다.

```typescript:src/app.module.ts
import { ScheduleModule } from '@nestjs/schedule';

@Module({
  imports: [
    // ... 다른 모듈들
    ScheduleModule.forRoot(),
  ],
})
export class AppModule {}
```

### 2.2 TaskService 생성

`TaskService`를 생성하고 `@Cron` 데코레이터를 사용하여 작업을 등록합니다.

```typescript:src/common/task.service.ts
import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';

@Injectable()
export class TaskService {
  @Cron('* * * * * *')
  logEverySecond() {
    console.log('1초 마다 실행');
  }
}
```

### 2.3 TaskService 모듈에 등록

`TaskService`를 `CommonModule`의 `providers`에 등록합니다.

```typescript:src/common/common.module.ts
import { Module } from '@nestjs/common';
import { TaskService } from './task.service';

@Module({
  providers: [CommonService, TaskService],
  exports: [CommonService, TaskService],
})
export class CommonModule {}
```

### 2.4 Cron 작업에 이름 부여

작업에 이름을 부여하면 나중에 동적으로 관리할 수 있습니다.

```typescript:src/common/task.service.ts
@Cron('* * * * * *', {
  name: 'printer',
})
printer() {
  console.log('printer every second');
}
```

---

## 3. 잉여 파일 삭제 기능 구현하기

### 3.1 문제 상황

파일 업로드 시 임시 파일이 `public/temp` 폴더에 저장됩니다. 사용자가 파일을 업로드한 후 실제로 사용하지 않으면 임시 파일이 계속 남아있어 디스크 공간을 낭비합니다.

### 3.2 해결 방법

24시간 이상 지난 임시 파일을 자동으로 삭제하는 작업을 구현합니다.

### 3.3 파일 삭제 로직 구현

```typescript:src/common/task.service.ts
import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { readdir, unlink } from 'fs/promises';
import { join, parse } from 'path';

@Injectable()
export class TaskService {
  // 매일 자정에 실행
  @Cron('0 0 0 * * *')
  async eraseOrphanFiles() {
    const files = await readdir(join(process.cwd(), 'public', 'temp'));

    const deleteFilesTarget = files.filter((file) => {
      const filename = parse(file).name;

      // 파일명 형식: UUID_timestamp.extension
      const split = filename.split('_');

      // 형식이 맞지 않으면 삭제 대상
      if (split.length !== 2) {
        return true;
      }

      try {
        // 타임스탬프 추출
        const timestamp = parseInt(split[split.length - 1]);
        const fileDate = +new Date(timestamp);
        const aDayInMilSec = 24 * 60 * 60 * 1000;
        const now = +new Date();

        // 24시간 이상 지난 파일은 삭제 대상
        return now - fileDate > aDayInMilSec;
      } catch {
        // 파싱 실패 시 삭제 대상
        return true;
      }
    });

    // 병렬로 파일 삭제
    await Promise.all(
      deleteFilesTarget.map((x) =>
        unlink(join(process.cwd(), 'public', 'temp', x)),
      ),
    );
  }
}
```

### 3.4 코드 설명

#### 파일명 파싱

```typescript
const filename = parse(file).name;
const split = filename.split('_');
```

- `parse(file).name`: 파일 확장자를 제외한 이름만 추출
- `split('_')`: UUID와 타임스탬프를 분리

#### 타임스탬프 확인

```typescript
const timestamp = parseInt(split[split.length - 1]);
const fileDate = +new Date(timestamp);
const now = +new Date();
const aDayInMilSec = 24 * 60 * 60 * 1000;

return now - fileDate > aDayInMilSec;
```

- 타임스탬프를 숫자로 변환하여 파일 생성 시간 계산
- 현재 시간과 비교하여 24시간 이상 지났는지 확인

#### 병렬 삭제

```typescript
await Promise.all(
  deleteFilesTarget.map((x) =>
    unlink(join(process.cwd(), 'public', 'temp', x)),
  ),
);
```

- `Promise.all()`을 사용하여 모든 파일을 병렬로 삭제
- 순차 삭제보다 훨씬 빠른 성능

### 3.5 성능 최적화

파일이 많을 경우를 대비하여 배치 처리 방식으로 개선할 수 있습니다.

```typescript
// 배치 단위로 병렬 처리 (한 번에 50개씩)
const BATCH_SIZE = 50;
for (let i = 0; i < deleteFilesTarget.length; i += BATCH_SIZE) {
  const batch = deleteFilesTarget.slice(i, i + BATCH_SIZE);
  await Promise.allSettled(
    batch.map((file) =>
      unlink(join(process.cwd(), 'public', 'temp', file)),
    ),
  );
}
```

**장점:**
- 메모리 사용량 제어
- 일부 파일 삭제 실패해도 나머지 계속 처리 (`Promise.allSettled`)
- 시스템 부하 분산

---

## 4. 좋아요, 싫어요 통계 기능 구현하기

### 4.1 문제 상황

영화의 좋아요/싫어요 개수를 매번 실시간으로 계산하면 성능 문제가 발생할 수 있습니다. 특히 영화 목록을 조회할 때마다 `COUNT(*)` 쿼리를 실행하면 데이터베이스 부하가 증가합니다.

### 4.2 해결 방법

정기적으로 좋아요/싫어요 개수를 계산하여 `Movie` 엔티티의 `likeCount`, `dislikeCount` 컬럼에 저장합니다.

### 4.3 Movie 엔티티 확인

```typescript:src/movie/entity/movie.entity.ts
@Entity()
export class Movie {
  // ... 다른 컬럼들

  @Column({ default: 0 })
  likeCount: number;

  @Column({ default: 0 })
  dislikeCount: number;
}
```

### 4.4 통계 계산 로직 구현

```typescript:src/common/task.service.ts
import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { Movie } from 'src/movie/entity/movie.entity';
import { Repository } from 'typeorm';

@Injectable()
export class TaskService {
  constructor(
    @InjectRepository(Movie)
    private readonly movieRepository: Repository<Movie>,
  ) {}

  // 매시간 0분 0초에 실행
  @Cron('0 0 * * * *')
  async calculateMovieLikeCount() {
    console.log('calculateMovieLikeCount');
    await this.movieRepository.query(
      `UPDATE movie m
      SET "likeCount" = COALESCE((
        SELECT COUNT(*) 
        FROM movie_user_like mul 
        WHERE m.id = mul."movieId" AND mul."isLike" = true
      ), 0)`,
    );
  }

  async calculateMovieDislikeCount() {
    await this.movieRepository.query(
      `UPDATE movie m
      SET "dislikeCount" = COALESCE((
        SELECT COUNT(*) 
        FROM movie_user_like mul 
        WHERE m.id = mul."movieId" AND mul."isLike" = false
      ), 0)`,
    );
  }
}
```

### 4.5 SQL 쿼리 설명

#### 좋아요 개수 계산

```sql
UPDATE movie m
SET "likeCount" = COALESCE((
  SELECT COUNT(*) 
  FROM movie_user_like mul 
  WHERE m.id = mul."movieId" AND mul."isLike" = true
), 0)
```

- 서브쿼리로 각 영화의 좋아요 개수를 계산
- `COALESCE(..., 0)`: 좋아요가 없는 영화는 0으로 설정
- 모든 영화의 `likeCount`를 한 번에 업데이트

#### 주의사항

**잘못된 쿼리:**
```sql
UPDATE movie m
SET "likeCount" = (
  SELECT COUNT(*) FROM movie_user_like mul 
  WHERE m.id = mul."movieId" AND mul."isLike" = true
)
WHERE m."id" = mul."movieId" AND mul."isLike" = true  -- ❌ 오류!
```

**문제점:**
- `WHERE` 절에서 서브쿼리 내부의 `mul` 테이블을 참조할 수 없음
- `mul`은 서브쿼리 내부에서만 사용 가능

**올바른 쿼리:**
```sql
UPDATE movie m
SET "likeCount" = COALESCE((
  SELECT COUNT(*) 
  FROM movie_user_like mul 
  WHERE m.id = mul."movieId" AND mul."isLike" = true
), 0)
-- WHERE 절 없음: 모든 영화 업데이트
```

### 4.6 CommonModule 설정

`TaskService`에서 `MovieRepository`를 사용하려면 `CommonModule`에 `Movie` 엔티티를 등록해야 합니다.

```typescript:src/common/common.module.ts
import { TypeOrmModule } from '@nestjs/typeorm';
import { Movie } from 'src/movie/entity/movie.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Movie]),
  ],
  providers: [CommonService, TaskService],
  exports: [CommonService, TaskService],
})
export class CommonModule {}
```

---

## 5. 다이나믹 타스크 스케쥴링

### 5.1 다이나믹 타스크 스케쥴링이란?

**다이나믹 타스크 스케쥴링**은 애플리케이션 실행 중에 동적으로 작업을 시작하거나 중지할 수 있는 기능입니다. `SchedulerRegistry`를 사용하여 등록된 작업을 제어할 수 있습니다.

### 5.2 SchedulerRegistry 사용하기

`SchedulerRegistry`를 주입받아 등록된 작업에 접근할 수 있습니다.

```typescript:src/common/task.service.ts
import { Injectable } from '@nestjs/common';
import { Cron, SchedulerRegistry } from '@nestjs/schedule';

@Injectable()
export class TaskService {
  constructor(
    private readonly schedulerRegistry: SchedulerRegistry,
  ) {}

  @Cron('* * * * * *', {
    name: 'printer',
  })
  printer() {
    console.log('printer every second');
  }

  @Cron('*/5 * * * * *')
  stopper() {
    console.log('---stopper run---');

    // 이름으로 작업 가져오기
    const job = this.schedulerRegistry.getCronJob('printer');

    // 작업 정보 확인
    console.log('# Next Dates');
    console.log(job.nextDates(5)); // 다음 5번의 실행 날짜

    // 작업 제어
    if ((job as any).running) {
      void job.stop();
    } else {
      void job.start();
    }
  }
}
```

### 5.3 CronJob 메서드

#### 작업 정보 조회

```typescript
const job = this.schedulerRegistry.getCronJob('printer');

// 마지막 실행 시간
console.log(job.lastDate());

// 다음 실행 시간
console.log(job.nextDate());

// 다음 N번의 실행 시간
console.log(job.nextDates(5));
```

#### 작업 제어

```typescript
// 작업 시작
void job.start();

// 작업 중지
void job.stop();

// 실행 상태 확인 (타입 정의에 없어서 타입 단언 필요)
if ((job as any).running) {
  // 작업이 실행 중
}
```

### 5.4 타입 이슈 해결

`CronJob`의 `running` 속성은 런타임에는 존재하지만 TypeScript 타입 정의에는 없습니다. 타입 단언을 사용하여 접근합니다.

```typescript
// 타입 단언 사용
if ((job as any).running) {
  void job.stop();
} else {
  void job.start();
}
```

**이유:**
- `@nestjs/schedule`의 타입 정의가 완전하지 않음
- 실제 `node-cron`의 `CronJob` 인스턴스는 `running` 속성을 가짐
- 런타임에서는 정상 작동하지만 타입 체크를 통과하기 위해 단언 필요

### 5.5 Promise 처리

`job.start()`와 `job.stop()`은 Promise를 반환할 수 있습니다. 명시적으로 무시하려면 `void` 연산자를 사용합니다.

```typescript
void job.start();
void job.stop();
```

### 5.6 실전 활용 예제

#### 조건부 작업 실행

```typescript
@Cron('*/10 * * * * *')
async conditionalTask() {
  const job = this.schedulerRegistry.getCronJob('printer');
  
  // 특정 조건에서만 작업 중지
  if (someCondition && (job as any).running) {
    void job.stop();
    console.log('작업이 중지되었습니다.');
  }
}
```

#### 작업 상태 모니터링

```typescript
@Cron('0 * * * * *')
async monitorTasks() {
  const jobs = this.schedulerRegistry.getCronJobs();
  
  jobs.forEach((job, name) => {
    console.log(`작업: ${name}`);
    console.log(`상태: ${(job as any).running ? '실행 중' : '중지됨'}`);
    console.log(`다음 실행: ${job.nextDate()}`);
  });
}
```

---

## 정리

### 주요 개념

1. **Task Scheduling**: 정기적으로 자동 실행되는 작업 관리
2. **Cron 표현식**: 시간 기반 작업 스케줄 정의
3. **@Cron 데코레이터**: 메서드에 Cron 작업 등록
4. **SchedulerRegistry**: 동적으로 작업 관리

### 실전 활용

1. **잉여 파일 삭제**: 정기적으로 임시 파일 정리
2. **통계 계산**: 주기적으로 집계 데이터 업데이트
3. **다이나믹 제어**: 실행 중 작업 시작/중지

### 주의사항

1. **타입 단언**: `CronJob`의 `running` 속성은 타입 단언 필요
2. **Promise 처리**: `start()`, `stop()` 메서드는 `void` 연산자 사용
3. **SQL 쿼리**: 서브쿼리 내부의 테이블을 외부에서 참조 불가
4. **성능 최적화**: 대량 파일 삭제 시 배치 처리 고려
