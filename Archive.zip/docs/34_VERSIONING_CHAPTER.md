# Part 26. Versioning

## 목차
1. [Versioning 이론](#1-versioning-이론)
2. [URI Versioning](#2-uri-versioning)
3. [Header, Media Type Versioning](#3-header-media-type-versioning)

---

## 1. Versioning 이론

### 1.1 API Versioning이란?

**API Versioning(API 버전 관리)**은 API의 변경 사항을 관리하고, 여러 버전의 API를 동시에 제공하는 기법입니다. API를 업데이트할 때 기존 클라이언트와의 호환성을 유지하면서 새로운 기능을 추가할 수 있습니다.

#### API Versioning의 필요성

1. **하위 호환성 유지**: 기존 클라이언트가 계속 작동하도록 보장
2. **점진적 마이그레이션**: 클라이언트가 새로운 버전으로 천천히 전환 가능
3. **변경 관리**: API 변경 사항을 명확하게 추적
4. **안정성**: 프로덕션 환경에서 안전한 업데이트

### 1.2 API 변경 시나리오

#### Breaking Changes (호환성 깨짐)

- **요청/응답 구조 변경**: 필드 추가, 삭제, 타입 변경
- **엔드포인트 제거**: 기존 엔드포인트 삭제
- **인증 방식 변경**: 인증 메커니즘 변경
- **에러 응답 형식 변경**: 에러 메시지 구조 변경

#### Non-Breaking Changes (호환성 유지)

- **새로운 필드 추가**: 선택적 필드 추가
- **새로운 엔드포인트 추가**: 기존 엔드포인트에 영향 없음
- **성능 개선**: 내부 로직만 변경

### 1.3 Versioning 전략

#### 1. URI Versioning (URL 기반)

```
GET /v1/movies
GET /v2/movies
```

**장점:**
- 명확하고 직관적
- 캐싱이 쉬움
- 브라우저에서 직접 테스트 가능

**단점:**
- URL이 길어짐
- RESTful 원칙에 약간 어긋남

#### 2. Header Versioning (헤더 기반)

```
GET /movies
Headers: version: 2
```

**장점:**
- URL이 깔끔함
- RESTful 원칙 준수
- 버전 정보가 명시적

**단점:**
- 브라우저에서 직접 테스트 어려움
- 캐싱 설정이 복잡할 수 있음

#### 3. Media Type Versioning (Content-Type 기반)

```
GET /movies
Headers: Accept: application/vnd.api+json;version=2
```

**장점:**
- HTTP 표준에 가장 부합
- RESTful 원칙 완벽 준수

**단점:**
- 구현이 복잡함
- 클라이언트 설정이 번거로움

### 1.4 NestJS Versioning 지원

NestJS는 내장된 버전 관리 기능을 제공합니다.

#### 주요 기능

1. **전역 버전 설정**: 애플리케이션 전체에 버전 적용
2. **컨트롤러별 버전**: 각 컨트롤러마다 다른 버전 지정
3. **라우트별 버전**: 개별 라우트에 버전 지정
4. **다중 버전 지원**: 여러 버전 동시 지원

---

## 2. URI Versioning

### 2.1 URI Versioning 설정

`main.ts`에서 `enableVersioning()`을 사용하여 URI 버전 관리를 활성화합니다.

```typescript:src/main.ts
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe, VersioningType } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  app.enableVersioning({
    type: VersioningType.URI,
  });
  
  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
```

### 2.2 컨트롤러에 버전 지정

컨트롤러 데코레이터에 `version` 옵션을 추가합니다.

```typescript:src/movie/movie.controller.ts
@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMoviesV2() {
    return 'MovieControllerV2';
  }
}
```

### 2.3 버전 중립 컨트롤러

`VERSION_NEUTRAL`을 사용하면 버전 관리에서 제외됩니다.

```typescript:src/movie/movie.controller.ts
import { VERSION_NEUTRAL } from '@nestjs/common';

@Controller({
  path: 'movie',
  version: VERSION_NEUTRAL,
})
export class MovieController {
  @Get()
  getMovies() {
    return this.movieService.findAll();
  }
}
```

### 2.4 라우트별 버전 지정

개별 라우트에 `@Version()` 데코레이터를 사용할 수 있습니다.

```typescript
import { Version } from '@nestjs/common';

@Controller('movie')
export class MovieController {
  @Get()
  @Version('1')
  getMoviesV1() {
    return 'Version 1';
  }

  @Get()
  @Version('2')
  getMoviesV2() {
    return 'Version 2';
  }
}
```

### 2.5 URI Versioning 동작 방식

#### 요청 예시

```bash
# Version 1
GET /v1/movie

# Version 2
GET /v2/movie

# Version Neutral (버전 없음)
GET /movie
```

#### 응답 예시

```json
// GET /v1/movie
{
  "id": 1,
  "title": "Movie Title",
  "description": "Description"
}

// GET /v2/movie
{
  "id": 1,
  "title": "Movie Title",
  "description": "Description",
  "rating": 4.5,  // 새로운 필드 추가
  "tags": ["action", "drama"]  // 새로운 필드 추가
}
```

### 2.6 전역 Prefix와 함께 사용

전역 prefix를 설정하면 버전이 앞에 붙습니다.

```typescript
app.setGlobalPrefix('api');
app.enableVersioning({
  type: VersioningType.URI,
});

// 결과: /api/v1/movie, /api/v2/movie
```

### 2.7 다중 버전 지원

하나의 컨트롤러에서 여러 버전을 지원할 수 있습니다.

```typescript
@Controller('movie')
export class MovieController {
  @Get()
  @Version(['1', '2'])
  getMovies() {
    // v1과 v2 모두에서 동일한 로직 사용
    return this.movieService.findAll();
  }
}
```

### 2.8 버전별 다른 로직 구현

```typescript
@Controller('movie')
export class MovieController {
  @Get()
  @Version('1')
  getMoviesV1() {
    // Version 1: 기본 필드만 반환
    return this.movieService.findAllV1();
  }

  @Get()
  @Version('2')
  getMoviesV2() {
    // Version 2: 추가 필드 포함
    return this.movieService.findAllV2();
  }
}
```

---

## 3. Header, Media Type Versioning

### 3.1 Header Versioning

Header Versioning은 HTTP 헤더를 통해 버전을 지정합니다.

#### 설정

```typescript:src/main.ts
app.enableVersioning({
  type: VersioningType.HEADER,
  header: 'version',  // 기본값: 'version'
});
```

#### 사용 방법

```bash
# 요청 예시
GET /movie
Headers:
  version: 2
```

#### 컨트롤러 설정

```typescript
@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMovies() {
    return 'Version 2 via Header';
  }
}
```

### 3.2 Header Versioning의 장점

1. **URL 깔끔함**: URL에 버전 정보가 없음
2. **RESTful 준수**: REST 원칙에 더 부합
3. **유연성**: 헤더를 동적으로 변경 가능

### 3.3 Header Versioning의 단점

1. **브라우저 테스트 어려움**: 직접 URL 입력으로 테스트 불가
2. **캐싱 복잡**: 헤더를 고려한 캐싱 전략 필요
3. **디버깅 어려움**: 버전 정보가 명시적이지 않음

### 3.4 Media Type Versioning

Media Type Versioning은 `Accept` 헤더를 통해 버전을 지정합니다.

#### 설정

```typescript:src/main.ts
app.enableVersioning({
  type: VersioningType.MEDIA_TYPE,
  key: 'v=',  // Accept: application/json;v=2
});
```

#### 사용 방법

```bash
# 요청 예시
GET /movie
Headers:
  Accept: application/json;v=2
```

#### 컨트롤러 설정

```typescript
@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMovies() {
    return 'Version 2 via Media Type';
  }
}
```

### 3.5 Media Type Versioning의 장점

1. **HTTP 표준 준수**: HTTP Content Negotiation 원칙 준수
2. **RESTful 완벽**: REST 아키텍처 원칙 완벽 준수
3. **유연한 협상**: 클라이언트가 원하는 형식과 버전 동시 지정

### 3.6 Media Type Versioning의 단점

1. **복잡한 구현**: 설정과 사용이 복잡함
2. **클라이언트 설정 번거로움**: Accept 헤더 설정 필요
3. **가독성 낮음**: 버전 정보가 명확하지 않음

### 3.7 다중 Versioning 전략

여러 버전 관리 방식을 동시에 사용할 수 있습니다.

```typescript
app.enableVersioning({
  type: VersioningType.URI,  // URI 버전 관리
  // 또는
  type: VersioningType.HEADER,  // Header 버전 관리
  // 또는
  type: VersioningType.MEDIA_TYPE,  // Media Type 버전 관리
});
```

**주의**: 한 번에 하나의 타입만 활성화할 수 있습니다. 여러 타입을 동시에 사용하려면 커스텀 로직이 필요합니다.

### 3.8 버전 관리 전략 선택 가이드

| 전략 | 사용 시나리오 | 장점 | 단점 |
|------|--------------|------|------|
| **URI Versioning** | 일반적인 API, 브라우저 테스트 필요 | 명확함, 테스트 쉬움 | URL 길어짐 |
| **Header Versioning** | RESTful 원칙 중시, URL 깔끔함 필요 | URL 깔끔, RESTful | 테스트 어려움 |
| **Media Type Versioning** | HTTP 표준 준수, 복잡한 협상 필요 | 표준 준수, 유연함 | 복잡함 |

### 3.9 실전 예제

#### URI Versioning 예제

```typescript
// main.ts
app.enableVersioning({
  type: VersioningType.URI,
});

// movie.controller.ts
@Controller({
  path: 'movie',
  version: '1',
})
export class MovieControllerV1 {
  @Get()
  getMovies() {
    return { version: 'v1', data: [] };
  }
}

@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMovies() {
    return { version: 'v2', data: [], metadata: {} };
  }
}
```

**요청:**
```bash
GET /v1/movie  # MovieControllerV1 호출
GET /v2/movie  # MovieControllerV2 호출
```

#### Header Versioning 예제

```typescript
// main.ts
app.enableVersioning({
  type: VersioningType.HEADER,
  header: 'version',
});

// movie.controller.ts
@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMovies() {
    return { version: 'v2', data: [] };
  }
}
```

**요청:**
```bash
GET /movie
Headers:
  version: 2
```

#### Media Type Versioning 예제

```typescript
// main.ts
app.enableVersioning({
  type: VersioningType.MEDIA_TYPE,
  key: 'v=',
});

// movie.controller.ts
@Controller({
  path: 'movie',
  version: '2',
})
export class MovieControllerV2 {
  @Get()
  getMovies() {
    return { version: 'v2', data: [] };
  }
}
```

**요청:**
```bash
GET /movie
Headers:
  Accept: application/json;v=2
```

### 3.10 버전 관리 모범 사례

#### 1. Semantic Versioning

```
v1.0.0  # Major.Minor.Patch
v1.1.0  # Minor 버전 업데이트 (기능 추가)
v2.0.0  # Major 버전 업데이트 (Breaking Changes)
```

#### 2. 버전 지원 정책

- **최신 버전**: 최신 기능과 성능 개선
- **이전 버전**: 최소 1-2개 버전 유지 (하위 호환성)
- **Deprecated 버전**: 사용 중단 예정 알림

#### 3. 버전 마이그레이션 가이드

- **마이그레이션 문서**: 버전 간 변경 사항 문서화
- **점진적 전환**: 충분한 시간 제공
- **자동 마이그레이션 도구**: 가능하면 제공

#### 4. 버전별 문서화

```markdown
# API Documentation

## Version 1
- Endpoint: `/v1/movie`
- Features: Basic CRUD operations

## Version 2
- Endpoint: `/v2/movie`
- Features: Basic CRUD + Advanced filtering
- Breaking Changes: Response format changed
```

---

## 정리

### Versioning 전략 비교

| 전략 | URL 예시 | 헤더 예시 | 사용 난이도 | RESTful 준수 |
|------|----------|-----------|------------|--------------|
| **URI** | `/v1/movie` | - | ⭐ 쉬움 | ⭐⭐ 보통 |
| **Header** | `/movie` | `version: 2` | ⭐⭐ 보통 | ⭐⭐⭐ 높음 |
| **Media Type** | `/movie` | `Accept: application/json;v=2` | ⭐⭐⭐ 어려움 | ⭐⭐⭐ 완벽 |

### 주요 개념

1. **API Versioning**: API 변경 사항 관리 및 하위 호환성 유지
2. **Breaking Changes**: 기존 클라이언트와 호환되지 않는 변경
3. **Version Strategy**: 버전을 지정하는 방법 (URI, Header, Media Type)
4. **VERSION_NEUTRAL**: 버전 관리에서 제외

### 실전 팁

1. **URI Versioning 권장**: 대부분의 경우 URI 버전 관리가 가장 실용적
2. **명확한 버전 정책**: 버전 지원 기간과 마이그레이션 계획 수립
3. **충분한 테스트**: 각 버전별로 충분한 테스트 수행
4. **문서화**: 버전별 변경 사항과 마이그레이션 가이드 제공
5. **점진적 전환**: 기존 클라이언트를 위한 충분한 전환 기간 제공
