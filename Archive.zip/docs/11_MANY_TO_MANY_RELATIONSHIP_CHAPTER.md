# Many-to-Many Relationship & 엔드포인트 업데이트

## 목차
1. [Many-to-Many Relationship 개념](#many-to-many-relationship-개념)
2. [Genre Many-to-Many Relationship 생성](#genre-many-to-many-relationship-생성)
3. [POST movie 엔드포인트 업데이트](#post-movie-엔드포인트-업데이트)
4. [PATCH GET movie 엔드포인트 업데이트](#patch-get-movie-엔드포인트-업데이트)

---

## Many-to-Many Relationship 개념

### Many-to-Many 관계란?

**Many-to-Many (다대다)** 관계는 두 엔티티가 서로 여러 개의 관계를 가질 수 있는 관계입니다.

- **영화(Movie)**는 여러 개의 **장르(Genre)**를 가질 수 있습니다.
- **장르(Genre)**는 여러 개의 **영화(Movie)**에 속할 수 있습니다.

### 예시
- 영화 "인셉션"은 "액션", "SF", "스릴러" 장르를 가질 수 있습니다.
- "액션" 장르는 "인셉션", "다크나이트", "인터스텔라" 등 여러 영화에 속할 수 있습니다.

### TypeORM에서의 Many-to-Many

TypeORM은 Many-to-Many 관계를 구현하기 위해 **중간 테이블(Join Table)**을 자동으로 생성합니다.

- `@ManyToMany()` 데코레이터 사용
- `@JoinTable()` 데코레이터로 관계의 소유자(Owner) 지정
- 중간 테이블은 `movie_genres_genre` 같은 이름으로 자동 생성됩니다.

---

## Genre Many-to-Many Relationship 생성

### 1. Genre Entity 생성

**파일**: `src/genre/entity/genre.entity.ts`

```typescript
import { Movie } from '../../movie/entity/movie.entity';
import { Column, Entity, ManyToMany, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Genre {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    unique: true,
  })
  name: string;

  @ManyToMany(() => Movie, (movie) => movie.genres)
  movies: Movie[];
}
```

**설명**:
- `@Entity()`: Genre를 TypeORM 엔티티로 선언
- `@PrimaryGeneratedColumn()`: 자동 증가하는 기본 키
- `@Column({ unique: true })`: `name` 필드에 유니크 제약 조건 추가
- `@ManyToMany(() => Movie, (movie) => movie.genres)`: Movie와 Many-to-Many 관계 설정
  - 첫 번째 인자: 관계를 맺을 엔티티 클래스
  - 두 번째 인자: 역방향 관계 속성 (`movie.genres`)

### 2. Movie Entity에 Many-to-Many 관계 추가

**파일**: `src/movie/entity/movie.entity.ts`

```typescript
import { Genre } from 'src/genre/entity/genre.entity';
import { ManyToMany, JoinTable } from 'typeorm';

@Entity()
export class Movie extends BaseTable {
  // ... 다른 필드들

  @ManyToMany(() => Genre, (genre) => genre.movies)
  @JoinTable()
  genres: Genre[];

  // ... 다른 관계들
}
```

**설명**:
- `@ManyToMany(() => Genre, (genre) => genre.movies)`: Genre와 Many-to-Many 관계 설정
  - 첫 번째 인자: 관계를 맺을 엔티티 클래스
  - 두 번째 인자: 역방향 관계 속성 (`genre.movies`)
- `@JoinTable()`: **관계의 소유자(Owner)**를 지정합니다.
  - `@JoinTable()`이 있는 쪽이 중간 테이블을 소유합니다.
  - `Movie` 엔티티에 `@JoinTable()`을 추가하면 `movie_genres_genre` 테이블이 생성됩니다.

### 3. Module 설정

**파일**: `src/movie/movie.module.ts`

```typescript
import { Genre } from 'src/genre/entity/genre.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Movie, MovieDetail, Director, Genre]),
    DirectorModule,
  ],
  // ...
})
export class MovieModule {}
```

**설명**:
- `TypeOrmModule.forFeature([Genre])`: Genre 엔티티를 MovieModule에서 사용할 수 있도록 등록
- Genre Repository를 MovieService에서 주입받아 사용할 수 있습니다.

**파일**: `src/genre/genre.module.ts`

```typescript
import { TypeOrmModule } from '@nestjs/typeorm';
import { Genre } from './entity/genre.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Genre])],
  // ...
})
export class GenreModule {}
```

**파일**: `src/app.module.ts`

```typescript
import { Genre } from './genre/entity/genre.entity';

@Module({
  imports: [
    // ...
    TypeOrmModule.forRootAsync({
      // ...
      entities: [Movie, MovieDetail, Director, Genre],
      // ...
    }),
    GenreModule,
    // ...
  ],
})
export class AppModule {}
```

**설명**:
- `entities` 배열에 `Genre` 추가: TypeORM이 Genre 엔티티를 인식하도록 설정
- `GenreModule` import: Genre 관련 기능을 앱에서 사용할 수 있도록 설정

### 4. MovieService에 Genre Repository 주입

**파일**: `src/movie/movie.service.ts`

```typescript
import { Genre } from 'src/genre/entity/genre.entity';

@Injectable()
export class MovieService {
  constructor(
    @InjectRepository(Movie)
    private readonly movieRepository: Repository<Movie>,
    @InjectRepository(MovieDetail)
    private readonly movieDetailRepository: Repository<MovieDetail>,
    @InjectRepository(Director)
    private readonly directorRepository: Repository<Director>,
    @InjectRepository(Genre)
    private readonly genreRepository: Repository<Genre>,
  ) {}
}
```

**설명**:
- `@InjectRepository(Genre)`: Genre Repository를 주입받아 장르 관련 데이터베이스 작업 수행 가능

---

## POST movie 엔드포인트 업데이트

### 1. CreateMovieDto에 genreIds 추가

**파일**: `src/movie/dto/create-movie.dto.ts`

```typescript
import {
  ArrayNotEmpty,
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsString,
} from 'class-validator';

export class CreateMovieDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  detail: string;

  @IsNotEmpty()
  @IsNumber()
  directorId: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  genreIds: number[];
}
```

**설명**:
- `@IsArray()`: `genreIds`가 배열인지 검증
- `@ArrayNotEmpty()`: 배열이 비어있지 않은지 검증
- `@IsNumber({}, { each: true })`: 배열의 각 요소가 숫자인지 검증
- `genreIds: number[]`: 장르 ID 배열을 받습니다.

### 2. MovieService의 create 메서드 업데이트

**파일**: `src/movie/movie.service.ts`

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  // 1. Director 조회
  const director = await this.directorRepository.findOne({
    where: { id: CreateMovieDto.directorId },
  });

  if (!director) {
    throw new NotFoundException(
      `Director with ID ${CreateMovieDto.directorId} not found`,
    );
  }

  // 2. Genre 조회 및 검증
  const genres = await this.genreRepository.find({
    where: { id: In(CreateMovieDto.genreIds) },
  });

  if (genres.length !== CreateMovieDto.genreIds.length) {
    throw new NotFoundException(
      `존재하지 않는 장르가 있습니다. 존재하는 장르: ${genres.map((genre) => genre.id).join(', ')}`,
    );
  }

  // 3. Movie 생성 (genres 포함)
  const movie = await this.movieRepository.save({
    title: CreateMovieDto.title,
    detail: {
      detail: CreateMovieDto.detail,
    },
    director: director,
    genres: genres, // Many-to-Many 관계 설정
  });

  return movie;
}
```

**설명**:
1. **Director 조회**: `directorId`로 감독을 조회하고 존재 여부를 확인합니다.
2. **Genre 조회**: `In()` 연산자를 사용하여 `genreIds` 배열에 해당하는 모든 장르를 조회합니다.
   - `In()`: TypeORM의 쿼리 연산자로, 배열에 포함된 값들과 일치하는 레코드를 찾습니다.
3. **Genre 검증**: 조회된 장르의 개수와 요청된 `genreIds`의 개수를 비교하여 존재하지 않는 장르가 있는지 확인합니다.
4. **Movie 저장**: `genres` 배열을 포함하여 Movie를 저장합니다.
   - TypeORM이 자동으로 중간 테이블에 관계를 저장합니다.

### 3. TypeORM의 In() 연산자

```typescript
import { In } from 'typeorm';

const genres = await this.genreRepository.find({
  where: { id: In([1, 2, 3]) }, // id가 1, 2, 3 중 하나인 장르 조회
});
```

**설명**:
- `In()`: SQL의 `IN` 절과 동일한 기능
- 배열에 포함된 값들과 일치하는 레코드를 조회합니다.
- `genreIds: [1, 2, 3]`이면 id가 1, 2, 3인 장르를 모두 조회합니다.

---

## PATCH GET movie 엔드포인트 업데이트

### 1. UpdateMovieDto에 genreIds 추가

**파일**: `src/movie/dto/update-movie.dto.ts`

```typescript
export class UpdateMovieDto {
  @IsNotEmpty()
  @IsOptional()
  @IsString()
  title?: string;

  @IsArray()
  @IsNotEmpty()
  @IsNumber({}, { each: true })
  @IsOptional()
  genreIds?: number[];

  @IsNotEmpty()
  @IsOptional()
  @IsString()
  detail?: string;

  @IsNotEmpty()
  @IsOptional()
  @IsNumber()
  directorId?: number;
}
```

**설명**:
- `@IsOptional()`: `genreIds`가 선택적 필드임을 명시
- `genreIds?: number[]`: 장르 ID 배열 (선택적)
- `@IsArray()`, `@IsNotEmpty()`, `@IsNumber({}, { each: true })`: `genreIds`가 제공되면 배열이고, 비어있지 않으며, 각 요소가 숫자여야 함

### 2. MovieService의 update 메서드 업데이트

**파일**: `src/movie/movie.service.ts`

```typescript
async update(id: number, UpdateMovieDto: UpdateMovieDto) {
  // 1. 기존 Movie 조회
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'genres'],
  });

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  // 2. DTO에서 필드 분리
  const { detail, directorId, genreIds, ...movieRest } = UpdateMovieDto;

  // 3. Director 업데이트 (선택적)
  let newDirector;
  if (directorId) {
    const director = await this.directorRepository.findOne({
      where: { id: directorId },
    });

    if (!director) {
      throw new NotFoundException(`Director with ID ${directorId} not found`);
    }

    newDirector = director;
  }

  // 4. Genre 업데이트 (선택적)
  let newGenres;
  if (genreIds) {
    const genres = await this.genreRepository.find({
      where: { id: In(genreIds) },
    });

    if (genres.length !== genreIds.length) {
      throw new NotFoundException(
        `존재하지 않는 장르가 있습니다. 존재하는 장르: ${genres.map((genre) => genre.id).join(', ')}`,
      );
    }

    newGenres = genres;
  }

  // 5. Movie 기본 필드 업데이트
  const movieUpdateFields = {
    ...movieRest,
    ...(newDirector && { director: newDirector }),
  };

  await this.movieRepository.update({ id }, movieUpdateFields);

  // 6. MovieDetail 업데이트 (선택적)
  if (detail) {
    await this.movieDetailRepository.update(
      { id: movie.detail.id },
      { detail },
    );
  }

  // 7. Genre 관계 업데이트 (선택적)
  const newMovie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director', 'genres'],
  });

  if (newGenres) {
    newMovie!.genres = newGenres;
    await this.movieRepository.save(newMovie!);
  }

  // 8. 최종 결과 반환
  return this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director', 'genres'],
  });
}
```

**설명**:
1. **기존 Movie 조회**: `genres` 관계를 포함하여 조회합니다.
2. **DTO 분리**: `detail`, `directorId`, `genreIds`를 분리하고 나머지는 `movieRest`에 저장합니다.
3. **Director 업데이트**: `directorId`가 제공되면 감독을 조회하고 검증합니다.
4. **Genre 업데이트**: `genreIds`가 제공되면 장르를 조회하고 검증합니다.
5. **Movie 기본 필드 업데이트**: `update()` 메서드로 기본 필드만 업데이트합니다.
   - `update()`는 Many-to-Many 관계를 업데이트하지 않습니다.
6. **MovieDetail 업데이트**: `detail`이 제공되면 MovieDetail을 업데이트합니다.
7. **Genre 관계 업데이트**: `newGenres`가 있으면 `save()` 메서드를 사용하여 Many-to-Many 관계를 업데이트합니다.
   - `save()`는 엔티티의 모든 관계를 포함하여 저장합니다.
8. **최종 결과 반환**: 업데이트된 Movie를 모든 관계와 함께 반환합니다.

### 3. update() vs save()의 차이

**`update()` 메서드**:
```typescript
await this.movieRepository.update({ id }, { title: '새 제목' });
```
- 기본 필드만 업데이트합니다.
- **Many-to-Many 관계를 업데이트하지 않습니다.**
- 더 빠르고 효율적입니다.

**`save()` 메서드**:
```typescript
const movie = await this.movieRepository.findOne({ where: { id } });
movie.genres = newGenres;
await this.movieRepository.save(movie);
```
- 엔티티의 모든 관계를 포함하여 저장합니다.
- **Many-to-Many 관계를 업데이트할 수 있습니다.**
- 엔티티를 먼저 조회해야 합니다.

### 4. MovieService의 findAll 메서드 업데이트

**파일**: `src/movie/movie.service.ts`

```typescript
async findAll(title?: string) {
  if (!title) {
    return [
      await this.movieRepository.find({ 
        relations: ['director', 'genres'] // genres 추가
      }),
      await this.movieRepository.count(),
    ];
  }

  if (title) {
    return await this.movieRepository.findAndCount({
      where: { title: Like(`%${title}%`) },
      relations: ['director', 'genres'], // genres 추가
    });
  }
}
```

**설명**:
- `relations: ['director', 'genres']`: `genres` 관계를 포함하여 조회합니다.
- 이제 영화 목록을 조회할 때 장르 정보도 함께 반환됩니다.

### 5. MovieService의 findOne 메서드 업데이트

**파일**: `src/movie/movie.service.ts`

```typescript
async findOne(id: number) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director', 'genres'], // genres 추가
  });

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  return movie;
}
```

**설명**:
- `relations: ['detail', 'director', 'genres']`: `genres` 관계를 포함하여 조회합니다.
- 이제 단일 영화를 조회할 때 장르 정보도 함께 반환됩니다.

---

## API 응답 예시

### GET /movie 응답

```json
[
  [
    {
      "createdAt": "2026-01-12T13:32:25.517Z",
      "updatedAt": "2026-01-12T13:56:40.583Z",
      "version": 9,
      "id": 1,
      "title": "인셉션",
      "genres": [
        {
          "id": 1,
          "name": "액션"
        },
        {
          "id": 2,
          "name": "SF"
        }
      ],
      "director": {
        "id": 1,
        "name": "크리스토퍼 놀란",
        "dob": "1970-07-30T00:00:00.000Z",
        "nationality": "United Kingdom"
      }
    }
  ],
  1
]
```

### POST /movie 요청

```json
{
  "title": "인셉션",
  "detail": "꿈 속에서 일어나는 이야기",
  "directorId": 1,
  "genreIds": [1, 2, 3]
}
```

### PATCH /movie/:id 요청

```json
{
  "title": "인셉션 2",
  "genreIds": [1, 4]
}
```

---

## 핵심 개념 정리

### 1. Many-to-Many 관계 설정

- `@ManyToMany()`: Many-to-Many 관계 선언
- `@JoinTable()`: 관계의 소유자 지정 (중간 테이블 생성)
- 양방향 관계: 양쪽 엔티티에 `@ManyToMany()` 선언

### 2. Many-to-Many 관계 저장

- `save()` 메서드 사용: 엔티티 객체에 `genres` 배열을 할당하고 `save()` 호출
- TypeORM이 자동으로 중간 테이블에 관계 저장

### 3. Many-to-Many 관계 조회

- `relations: ['genres']`: `findOne()` 또는 `find()` 시 `genres` 관계 포함
- Eager Loading: 관계를 포함하여 한 번의 쿼리로 모든 데이터 조회

### 4. Many-to-Many 관계 업데이트

- `update()` 메서드는 Many-to-Many 관계를 업데이트하지 않음
- `save()` 메서드를 사용하여 관계 업데이트
- 엔티티를 먼저 조회한 후 `genres` 배열을 할당하고 `save()` 호출

### 5. In() 연산자

- `In([1, 2, 3])`: 배열에 포함된 값들과 일치하는 레코드 조회
- SQL의 `IN` 절과 동일한 기능
- 여러 ID로 한 번에 조회할 때 유용

---

## 프로젝트 파일 구조

```
src/
├── movie/
│   ├── entity/
│   │   └── movie.entity.ts          # @ManyToMany, @JoinTable
│   ├── dto/
│   │   ├── create-movie.dto.ts       # genreIds 추가
│   │   └── update-movie.dto.ts       # genreIds 추가
│   ├── movie.service.ts              # Genre 조회 및 관계 설정
│   └── movie.module.ts               # Genre Repository 등록
├── genre/
│   ├── entity/
│   │   └── genre.entity.ts           # @ManyToMany
│   └── genre.module.ts               # TypeOrmModule.forFeature([Genre])
└── app.module.ts                      # Genre 엔티티 등록
```

---

## 참고사항

1. **중간 테이블 이름**: TypeORM이 자동으로 `movie_genres_genre` 같은 이름으로 생성합니다.
2. **관계의 소유자**: `@JoinTable()`이 있는 쪽이 중간 테이블을 소유합니다.
3. **역방향 관계**: 양방향 관계에서 역방향 속성을 올바르게 지정해야 합니다.
4. **성능 고려**: Many-to-Many 관계는 추가 쿼리가 발생할 수 있으므로 `relations` 옵션을 적절히 사용해야 합니다.
