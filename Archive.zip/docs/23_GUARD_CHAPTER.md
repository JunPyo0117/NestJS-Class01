# Part 14. Guard

## 목차
1. [Guard 이론](#1-guard-이론)
2. [Auth Guard 생성하기](#2-auth-guard-생성하기)
3. [Public Custom Decorator 생성하기](#3-public-custom-decorator-생성하기)
4. [Bearer Token Middleware 토큰 검증 개선하기](#4-bearer-token-middleware-토큰-검증-개선하기)

---

## 1. Guard 이론

### 1.1 Guard란?

**Guard(가드)**는 권한 등 조건을 확인한 후 요청이 라우트 핸들러로 전달될지 말지를 결정합니다. 이 과정을 우리는 흔히 **인가(Authorization)**이라고 부르며, 요청을 보낸 사용자가 요청을 수행할 자격이 있는지 확인하게 됩니다.

> **참고**: 위 이미지는 Guard의 개념과 역할을 설명하는 다이어그램입니다. Guard는 권한 등 조건을 확인한 후 요청이 라우트 핸들러로 전달될지 말지를 결정합니다.

#### Guard의 특징

1. **인가(Authorization) 처리**: 사용자의 권한을 확인하여 요청 허용/거부 결정
2. **실행 컨텍스트 접근**: `ExecutionContext`를 통해 다음에 실행될 핸들러 정보 확인 가능
3. **Middleware와의 차이**: Middleware는 실행 문맥이 부족하지만, Guard는 `ExecutionContext`를 통해 정확한 정보 확인 가능

### 1.2 Guard의 실행 순서

Guard는 NestJS의 요청 처리 파이프라인에서 **Middleware 이후, Interceptor 이전**에 실행됩니다.

> **참고**: 위 이미지는 NestJS 요청 처리 파이프라인에서 Guard의 위치를 보여주는 플로우차트입니다. Guard는 Middleware와 Interceptor 사이에서 인가를 처리합니다.

#### 실행 흐름

```
요청 → Middleware → Guard → Interceptor → Pipe → Controller → Service → Repository
```

1. **Middleware**: 요청 전처리 (예: 토큰 파싱)
2. **Guard**: 인가 확인 (예: 사용자 권한 검증)
3. **Interceptor**: 요청/응답 가로채기
4. **Pipe**: 데이터 변환 및 검증
5. **Controller**: 라우트 핸들러 실행

### 1.3 Guard vs Middleware

#### Middleware의 한계

- 실행 문맥이 부족함
- 어느 한 Middleware가 실행된 다음에 어떤 기능이 실행될지 알 수 없음
- 요청/응답 객체만 접근 가능

#### Guard의 장점

- `ExecutionContext` 객체를 통해 다음에 실행될 기능을 정확히 알 수 있음
- 라우트 핸들러, 메서드, 파라미터 등 상세 정보 접근 가능
- 인가 로직 구현에 최적화됨

### 1.4 CanActivate 인터페이스

Guard는 `CanActivate` 인터페이스를 구현해야 합니다.

```typescript
export interface CanActivate {
  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean>;
}
```

- `canActivate` 메서드를 구현해야 함
- `ExecutionContext`를 매개변수로 받음
- `boolean` 또는 `Promise<boolean>` 또는 `Observable<boolean>` 반환
- `true` 반환 시 요청 허용, `false` 반환 시 요청 거부

### 1.5 ExecutionContext

`ExecutionContext`는 현재 실행 컨텍스트에 대한 정보를 제공합니다.

```typescript
export interface ExecutionContext {
  getClass<T = any>(): Type<T>;
  getHandler(): Function;
  getArgs(): any[];
  getArgByIndex<T = any>(index: number): T;
  switchToHttp(): HttpArgumentsHost;
  switchToRpc(): RpcArgumentsHost;
  switchToWs(): WsArgumentsHost;
}
```

주요 메서드:
- `getHandler()`: 실행될 핸들러 함수 반환
- `getClass()`: 실행될 핸들러가 속한 클래스 반환
- `switchToHttp()`: HTTP 컨텍스트로 전환

---

## 2. Auth Guard 생성하기

### 2.1 Auth Guard 구현

`src/auth/guard/auth.guard.ts` 파일을 생성하고 Guard를 구현합니다.

```typescript:src/auth/guard/auth.guard.ts
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthService } from '../auth.service';
import { Reflector } from '@nestjs/core';
import { Public } from '../decorator/public.decorator';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly authService: AuthService,
    private readonly reflector: Reflector,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    // 공개 여부 확인
    const isPublic = this.reflector.get(Public, context.getHandler());

    if (isPublic) {
      return true;
    }

    const request = context.switchToHttp().getRequest();

    if (!request.user || request.user.type !== 'access') {
      return false;
    }

    return true;
  }
}
```

#### 주요 구현 내용

1. **@Injectable()**: 의존성 주입 가능하도록 설정
2. **CanActivate 인터페이스 구현**: `canActivate` 메서드 구현
3. **Reflector 주입**: 메타데이터를 읽기 위해 `Reflector` 사용
4. **Public 데코레이터 확인**: `@Public()` 데코레이터가 있는지 확인
5. **사용자 인증 확인**: `request.user`가 존재하고 `type`이 `'access'`인지 확인

### 2.2 전역 Guard 등록

`app.module.ts`에서 Guard를 전역으로 등록합니다.

```typescript:src/app.module.ts
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from './auth/guard/auth.guard';

@Module({
  // ... imports
  providers: [
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
  ],
})
export class AppModule implements NestModule {
  // ...
}
```

#### APP_GUARD 사용

- `APP_GUARD` 토큰을 사용하여 전역 Guard 등록
- 모든 라우트에 자동으로 적용됨
- 개별 컨트롤러나 메서드에서 `@Public()` 데코레이터로 제외 가능

---

## 3. Public Custom Decorator 생성하기

### 3.1 Public Decorator 구현

일부 엔드포인트는 인증 없이 접근 가능하도록 `@Public()` 데코레이터를 생성합니다.

```typescript:src/auth/decorator/public.decorator.ts
import { Reflector } from '@nestjs/core';

export const Public = Reflector.createDecorator();
```

#### Reflector.createDecorator()

- NestJS의 `Reflector.createDecorator()`를 사용하여 커스텀 데코레이터 생성
- 메타데이터를 설정하는 데코레이터를 간단하게 생성 가능
- Guard에서 `reflector.get()`으로 메타데이터 읽기 가능

### 3.2 Public Decorator 사용

컨트롤러에서 `@Public()` 데코레이터를 사용하여 인증을 제외합니다.

```typescript:src/movie/movie.controller.ts
import { Public } from 'src/auth/decorator/public.decorator';

@Controller('movie')
export class MovieController {
  @Get()
  @Public()
  getMovies(@Query('title', MovieTitleValidationPipe) title?: string) {
    return this.movieService.findAll(title);
  }

  @Post()
  createMovie(@Body() body: CreateMovieDto) {
    return this.movieService.create(body);
  }
}
```

#### 동작 방식

1. `@Public()` 데코레이터가 적용된 메서드는 메타데이터에 표시됨
2. Guard의 `canActivate`에서 `reflector.get(Public, context.getHandler())`로 확인
3. `isPublic`이 `true`이면 인증 없이 통과
4. `isPublic`이 `false`이면 `request.user` 확인 후 통과/거부 결정

---

## 4. Bearer Token Middleware 토큰 검증 개선하기

### 4.1 기존 Middleware 확인

`BearerTokenMiddleware`는 이미 토큰을 파싱하고 검증하는 역할을 수행하고 있습니다.

```typescript:src/auth/middleware/bearer-token.middleware.ts
@Injectable()
export class BearerTokenMiddleware implements NestMiddleware {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
      next();
      return;
    }

    try {
      const token = this.validateBearerToken(authHeader);
      const decodedPayload = this.jwtService.decode(token);

      if (
        decodedPayload.type !== 'refresh' &&
        decodedPayload.type !== 'access'
      ) {
        throw new BadRequestException('Invalid token');
      }

      const secretKey = this.configService.get<string>(
        decodedPayload.type === 'refresh'
          ? envVariableKeys.refreshTokenSecret
          : envVariableKeys.accessTokenSecret,
      )!;
      const payload = await this.jwtService.verifyAsync(token, {
        secret: secretKey,
      });

      req.user = payload;
      next();
    } catch (e) {
      next();
    }
  }

  validateBearerToken(rawToken: string) {
    const bearerSplit = rawToken.split(' ');

    if (bearerSplit.length !== 2) {
      throw new BadRequestException('Invalid token');
    }

    const [bearer, token] = bearerSplit;

    if (bearer.toLocaleLowerCase() !== 'bearer') {
      throw new BadRequestException('Invalid token');
    }

    return token;
  }
}
```

### 4.2 Guard와 Middleware의 역할 분리

#### Middleware의 역할

- **토큰 파싱**: Authorization 헤더에서 Bearer 토큰 추출
- **토큰 검증**: JWT 토큰의 유효성 검증
- **사용자 정보 설정**: `req.user`에 페이로드 설정
- **에러 처리**: 토큰이 없거나 유효하지 않아도 `next()` 호출 (Guard에서 처리)

#### Guard의 역할

- **인가 확인**: `request.user`가 존재하는지 확인
- **토큰 타입 확인**: `request.user.type`이 `'access'`인지 확인
- **Public 엔드포인트 처리**: `@Public()` 데코레이터 확인
- **요청 허용/거부**: `true`/`false` 반환으로 요청 제어

### 4.3 전체 흐름

```
1. 요청 도착
   ↓
2. BearerTokenMiddleware 실행
   - Authorization 헤더 확인
   - Bearer 토큰 추출
   - JWT 검증
   - req.user에 페이로드 설정 (성공 시)
   - next() 호출
   ↓
3. AuthGuard 실행
   - @Public() 데코레이터 확인
   - Public이면 → true 반환 (통과)
   - Public이 아니면 → request.user 확인
     - request.user가 없거나 type !== 'access' → false 반환 (거부)
     - request.user.type === 'access' → true 반환 (통과)
   ↓
4. Controller 실행
```

### 4.4 에러 처리 개선

현재 Middleware는 에러가 발생해도 `next()`를 호출하여 Guard로 넘어갑니다. Guard에서 최종적으로 인증 여부를 확인하므로, Middleware는 단순히 토큰을 파싱하고 검증하는 역할만 수행합니다.

#### 장점

1. **역할 분리**: Middleware는 토큰 처리, Guard는 인가 처리
2. **유연성**: Public 엔드포인트는 토큰 없이도 접근 가능
3. **명확성**: 각 컴포넌트의 책임이 명확함

---

## 정리

### Guard의 핵심 개념

1. **인가(Authorization)**: 사용자의 권한을 확인하여 요청 허용/거부
2. **ExecutionContext**: 다음에 실행될 핸들러 정보 접근 가능
3. **CanActivate**: Guard가 구현해야 하는 인터페이스
4. **전역 Guard**: `APP_GUARD`를 사용하여 모든 라우트에 적용

### 구현 요약

1. **AuthGuard 생성**: `CanActivate` 인터페이스 구현
2. **Public Decorator**: 인증 제외를 위한 커스텀 데코레이터
3. **전역 등록**: `APP_GUARD`로 전역 Guard 설정
4. **역할 분리**: Middleware는 토큰 처리, Guard는 인가 처리

### Guard vs Middleware

| 구분 | Middleware | Guard |
|------|-----------|-------|
| 실행 순서 | 가장 먼저 | Middleware 이후 |
| 접근 정보 | Request/Response | ExecutionContext |
| 주요 역할 | 요청 전처리 | 인가 확인 |
| 실행 컨텍스트 | 부족 | 풍부 |

Guard는 NestJS의 인가 메커니즘을 구현하는 핵심 컴포넌트로, Middleware와 함께 사용하여 안전하고 유연한 인증/인가 시스템을 구축할 수 있습니다.
