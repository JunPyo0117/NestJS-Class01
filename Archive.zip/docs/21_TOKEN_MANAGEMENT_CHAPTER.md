# Ch 5. 토큰관리

## 목차
1. [Access Token 재발급하기](#1-access-token-재발급하기)
2. [환경변수 정비](#2-환경변수-정비)

---

## 1. Access Token 재발급하기

### 1.1 Access Token 재발급의 필요성

Access Token은 짧은 수명(5분)을 가지므로, 만료되면 새로운 Access Token을 발급받아야 합니다. Refresh Token을 사용하여 새로운 Access Token을 재발급할 수 있습니다.

#### 토큰 재발급 흐름
```
1. Access Token 만료 (5분 후)
   ↓
2. Refresh Token을 Authorization 헤더에 포함하여 요청
   ↓
3. 서버가 Refresh Token 검증
   ↓
4. 새로운 Access Token 발급
   ↓
5. 새로운 Access Token으로 API 사용 계속
```

### 1.2 Bearer Token 파싱 메서드 구현

프로젝트에서 Bearer Token을 파싱하고 검증하는 메서드를 확인해보겠습니다.

#### parseBearerToken 메서드

```48:82:src/auth/auth.service.ts
  async parseBearerToken(rawToken: string, isRefreshToken: boolean) {
    const bearerSplit = rawToken.split(' ');

    if (bearerSplit.length !== 2) {
      throw new BadRequestException('Invalid token');
    }

    const [bearer, token] = bearerSplit;

    if (bearer.toLocaleLowerCase() !== 'bearer') {
      throw new BadRequestException('Invalid token');
    }

    try {
      const payload = await this.jwtService.verifyAsync(token, {
        secret: this.configService.get<string>(
          envVariableKeys.refreshTokenSecret,
        )!,
      });

      if (isRefreshToken) {
        if (payload.type !== 'refresh') {
          throw new BadRequestException('Refresh token is required');
        }
      } else {
        if (payload.type !== 'access') {
          throw new BadRequestException('Access token is required');
        }
      }

      return payload;
    } catch (e) {
      throw new UnauthorizedException('토큰이 만료되었습니다');
    }
  }
```

#### 코드 설명

1. **Bearer Token 형식 검증**
   ```typescript
   const bearerSplit = rawToken.split(' ');
   const [bearer, token] = bearerSplit;
   ```
   - `Authorization: Bearer <token>` 형식에서 `Bearer`와 토큰을 분리
   - 공백을 기준으로 나누어 배열로 만듦

2. **Bearer 키워드 확인**
   ```typescript
   if (bearer.toLocaleLowerCase() !== 'bearer') {
     throw new BadRequestException('Invalid token');
   }
   ```
   - 대소문자 구분 없이 `bearer`인지 확인
   - 올바른 형식이 아니면 예외 발생

3. **JWT 토큰 검증**
   ```typescript
   const payload = await this.jwtService.verifyAsync(token, {
     secret: this.configService.get<string>(
       envVariableKeys.refreshTokenSecret,
     )!,
   });
   ```
   - `jwtService.verifyAsync`로 토큰 검증
   - Refresh Token Secret으로 검증 (Refresh Token 재발급 시)
   - 검증 성공 시 페이로드 반환

4. **토큰 타입 검증**
   ```typescript
   if (isRefreshToken) {
     if (payload.type !== 'refresh') {
       throw new BadRequestException('Refresh token is required');
     }
   }
   ```
   - `isRefreshToken`이 `true`면 Refresh Token이어야 함
   - `payload.type`이 `'refresh'`인지 확인
   - 타입이 맞지 않으면 예외 발생

5. **에러 처리**
   ```typescript
   catch (e) {
     throw new UnauthorizedException('토큰이 만료되었습니다');
   }
   ```
   - 토큰 만료 또는 검증 실패 시 `UnauthorizedException` 발생
   - 클라이언트에 401 상태 코드 반환

### 1.3 Access Token 재발급 엔드포인트

컨트롤러에서 Access Token 재발급 엔드포인트를 확인해보겠습니다.

#### rotateAccessToken 엔드포인트

```28:38:src/auth/auth.controller.ts
  @Post('token/access')
  async rotateAccessToken(@Headers('authorization') token: string) {
    const payload = await this.authService.parseBearerToken(token, true);

    return {
      accessToken: await this.authService.issueToken(
        { id: payload.sub, role: payload.role },
        false,
      ),
    };
  }
```

#### 동작 과정

1. **요청**
   ```http
   POST /auth/token/access
   Authorization: Bearer <refresh_token>
   ```

2. **Refresh Token 검증**
   ```typescript
   const payload = await this.authService.parseBearerToken(token, true);
   ```
   - `parseBearerToken`에 `true`를 전달하여 Refresh Token 검증
   - 검증 성공 시 페이로드 반환

3. **새로운 Access Token 발급**
   ```typescript
   await this.authService.issueToken(
     { id: payload.sub, role: payload.role },
     false,
   )
   ```
   - 페이로드에서 `sub` (사용자 ID)와 `role` 추출
   - `issueToken`에 `false`를 전달하여 Access Token 발급
   - 새로운 Access Token 반환

4. **응답**
   ```json
   {
     "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
   }
   ```

### 1.4 issueToken 메서드

토큰 발급 메서드를 확인해보겠습니다.

```120:139:src/auth/auth.service.ts
  async issueToken(user: { id: number; role: Role }, isRefreshToken: boolean) {
    const refreshTokenSecret = this.configService.get<string>(
      envVariableKeys.refreshTokenSecret,
    )!;
    const accessTokenSecret = this.configService.get<string>(
      envVariableKeys.accessTokenSecret,
    )!;

    return await this.jwtService.signAsync(
      {
        sub: user.id,
        role: user.role,
        type: isRefreshToken ? 'refresh' : 'access',
      },
      {
        secret: isRefreshToken ? refreshTokenSecret : accessTokenSecret,
        expiresIn: isRefreshToken ? '24h' : '300s',
      },
    );
  }
```

#### 주요 특징

- **토큰 타입 구분**: `type` 필드로 `'refresh'` 또는 `'access'` 구분
- **시크릿 키 분리**: Refresh Token과 Access Token에 다른 시크릿 사용
- **수명 차이**: Refresh Token은 24시간, Access Token은 5분(300초)

### 1.5 사용 예시

#### 클라이언트 측 구현 예시

```typescript
// Access Token이 만료되었을 때
async function refreshAccessToken(refreshToken: string) {
  const response = await fetch('http://localhost:3000/auth/token/access', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${refreshToken}`,
    },
  });

  if (!response.ok) {
    throw new Error('Token refresh failed');
  }

  const data = await response.json();
  return data.accessToken; // 새로운 Access Token
}

// API 요청 시 사용
async function apiRequest(url: string, accessToken: string) {
  let response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  });

  // Access Token 만료 시 재발급
  if (response.status === 401) {
    const newAccessToken = await refreshAccessToken(refreshToken);
    response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${newAccessToken}`,
      },
    });
  }

  return response.json();
}
```

---

## 2. 환경변수 정비

### 2.1 환경변수 관리의 필요성

환경변수를 하드코딩하면 다음과 같은 문제가 발생합니다:

1. **오타 위험**: 문자열을 직접 입력하면 오타 가능성
2. **유지보수 어려움**: 여러 파일에 분산되어 있으면 수정이 어려움
3. **타입 안정성 부족**: 문자열 리터럴은 타입 체크가 어려움

### 2.2 환경변수 상수 파일 생성

프로젝트에서 환경변수 키를 상수로 관리하는 파일을 확인해보겠습니다.

#### env.const.ts 파일

```1:24:src/common/const/env.const.ts
const env = 'ENV';
const dbType = 'DB_TYPE';
const dbHost = 'DB_HOST';
const dbPort = 'DB_PORT';
const dbUsername = 'DB_USERNAME';
const dbPassword = 'DB_PASSWORD';
const dbDatabase = 'DB_DATABASE';
const hashRounds = 'HASH_ROUNDS';
const accessTokenSecret = 'ACCESS_TOKEN_SECRET';
const refreshTokenSecret = 'REFRESH_TOKEN_SECRET';

export const envVariableKeys = {
  env,
  dbType,
  dbHost,
  dbPort,
  dbUsername,
  dbPassword,
  dbDatabase,
  hashRounds,
  accessTokenSecret,
  refreshTokenSecret,
};
```

#### 장점

1. **중앙 집중식 관리**: 모든 환경변수 키를 한 곳에서 관리
2. **타입 안정성**: TypeScript의 타입 체크 활용
3. **자동완성**: IDE에서 자동완성 지원
4. **리팩토링 용이**: 키 이름 변경 시 한 곳만 수정

### 2.3 환경변수 상수 사용

#### AuthService에서 사용

```8:8:src/auth/auth.service.ts
import { envVariableKeys } from 'src/common/const/env.const';
```

```94:96:src/auth/auth.service.ts
    const hash = await bcrypt.hash(
      password,
      this.configService.get<number>(envVariableKeys.hashRounds)!,
    );
```

```121:126:src/auth/auth.service.ts
    const refreshTokenSecret = this.configService.get<string>(
      envVariableKeys.refreshTokenSecret,
    )!;
    const accessTokenSecret = this.configService.get<string>(
      envVariableKeys.accessTokenSecret,
    )!;
```

```63:65:src/auth/auth.service.ts
        secret: this.configService.get<string>(
          envVariableKeys.refreshTokenSecret,
        )!,
```

#### AppModule에서 사용

```16:16:src/app.module.ts
import { envVariableKeys } from './common/const/env.const';
```

```37:42:src/app.module.ts
        type: configService.get<string>(envVariableKeys.dbType) as 'postgres',
        host: configService.get<string>(envVariableKeys.dbHost),
        port: configService.get<number>(envVariableKeys.dbPort),
        username: configService.get<string>(envVariableKeys.dbUsername),
        password: configService.get<string>(envVariableKeys.dbPassword),
        database: configService.get<string>(envVariableKeys.dbDatabase),
```

### 2.4 환경변수 검증 스키마

AppModule에서 환경변수 검증 스키마를 확인해보겠습니다.

```22:32:src/app.module.ts
      validationSchema: Joi.object({
        DB_TYPE: Joi.string().valid('postgres').required(),
        DB_HOST: Joi.string().required(),
        DB_PORT: Joi.number().required(),
        DB_USERNAME: Joi.string().required(),
        DB_PASSWORD: Joi.string().required(),
        DB_DATABASE: Joi.string().required(),
        HASH_ROUNDS: Joi.number().required(),
        ACCESS_TOKEN_SECRET: Joi.string().required(),
        REFRESH_TOKEN_SECRET: Joi.string().required(),
      }),
```

#### 검증 스키마의 역할

1. **필수 환경변수 확인**: `.required()`로 필수 여부 검증
2. **타입 검증**: `Joi.string()`, `Joi.number()`로 타입 검증
3. **값 검증**: `Joi.string().valid('postgres')`로 특정 값만 허용
4. **애플리케이션 시작 시 검증**: 누락되거나 잘못된 환경변수가 있으면 애플리케이션이 시작되지 않음

### 2.5 환경변수 정비의 장점

#### Before (하드코딩)

```typescript
// 여러 파일에 분산
const hash = await bcrypt.hash(
  password,
  this.configService.get<number>('HASH_ROUNDS')!, // 오타 가능
);

const secret = this.configService.get<string>(
  'REFRESH_TOKEN_SECRET', // 오타 가능
)!;
```

#### After (상수 사용)

```typescript
// 중앙 집중식 관리
import { envVariableKeys } from 'src/common/const/env.const';

const hash = await bcrypt.hash(
  password,
  this.configService.get<number>(envVariableKeys.hashRounds)!, // 타입 안전
);

const secret = this.configService.get<string>(
  envVariableKeys.refreshTokenSecret, // 자동완성 지원
)!;
```

### 2.6 환경변수 추가 방법

새로운 환경변수를 추가할 때:

1. **env.const.ts에 상수 추가**
   ```typescript
   const newEnvKey = 'NEW_ENV_KEY';
   
   export const envVariableKeys = {
     // ... 기존 키들
     newEnvKey,
   };
   ```

2. **app.module.ts의 검증 스키마에 추가**
   ```typescript
   validationSchema: Joi.object({
     // ... 기존 검증
     NEW_ENV_KEY: Joi.string().required(),
   }),
   ```

3. **.env 파일에 값 추가**
   ```env
   NEW_ENV_KEY=value
   ```

4. **코드에서 사용**
   ```typescript
   const value = this.configService.get<string>(
     envVariableKeys.newEnvKey,
   )!;
   ```

---

## 3. 정리

### 3.1 Access Token 재발급

- **목적**: 만료된 Access Token을 Refresh Token으로 갱신
- **엔드포인트**: `POST /auth/token/access`
- **요청**: `Authorization: Bearer <refresh_token>`
- **응답**: 새로운 Access Token

### 3.2 환경변수 정비

- **목적**: 환경변수 키를 중앙에서 관리하여 오타 방지 및 유지보수 용이
- **파일**: `src/common/const/env.const.ts`
- **장점**: 타입 안정성, 자동완성, 리팩토링 용이

### 3.3 보안 고려사항

1. **Refresh Token 검증**: Refresh Token만으로 Access Token 재발급 가능
2. **토큰 타입 검증**: `payload.type`으로 토큰 타입 확인
3. **만료 처리**: 만료된 토큰은 적절한 에러 메시지와 함께 거부
4. **환경변수 보안**: `.env` 파일은 `.gitignore`에 포함하여 버전 관리 제외

---

## 참고 자료

- [NestJS ConfigModule 공식 문서](https://docs.nestjs.com/techniques/configuration)
- [JWT 토큰 재발급 패턴](https://auth0.com/blog/refresh-tokens-what-are-they-and-when-to-use-them/)
- [환경변수 관리 Best Practices](https://12factor.net/config)
