# Part 13. Middleware

## 목차
1. [Middleware 이론](#1-middleware-이론)
2. [Bearer Token Middleware 구현하기](#2-bearer-token-middleware-구현하기)

---

## 1. Middleware 이론

### 1.1 Middleware란?

**Middleware(미들웨어)**는 라우트 핸들러가 실행되기 전에 요청을 가로채서 처리하는 함수입니다. Express.js의 미들웨어 개념을 NestJS에서도 사용할 수 있습니다.

#### Middleware의 특징

1. **요청 전처리**: 라우트 핸들러 실행 전에 요청을 처리
2. **응답 후처리**: 라우트 핸들러 실행 후 응답을 처리
3. **다음 미들웨어 호출**: `next()` 함수로 다음 미들웨어나 라우트 핸들러로 제어 전달
4. **요청/응답 수정**: `req`와 `res` 객체를 수정 가능

### 1.2 Middleware의 실행 순서

```
요청 → Middleware 1 → Middleware 2 → ... → Route Handler → 응답
```

#### 실행 흐름

1. 요청이 들어옴
2. 첫 번째 미들웨어 실행
3. `next()` 호출 시 다음 미들웨어로 이동
4. 모든 미들웨어를 통과하면 라우트 핸들러 실행
5. 응답 반환

### 1.3 NestJS에서의 Middleware

NestJS는 Express 미들웨어를 기반으로 하며, 클래스 기반 미들웨어를 제공합니다.

#### NestMiddleware 인터페이스

```typescript
export interface NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void;
}
```

- `use` 메서드를 구현해야 함
- `Request`, `Response`, `NextFunction` 타입 사용
- `@Injectable()` 데코레이터로 DI 가능

### 1.4 Middleware의 사용 사례

#### 1. 인증/인가
- JWT 토큰 검증
- 사용자 정보를 `req.user`에 추가

#### 2. 로깅
- 요청 로그 기록
- 성능 측정

#### 3. 데이터 변환
- 요청 본문 파싱
- 데이터 형식 변환

#### 4. CORS 설정
- Cross-Origin 요청 처리

#### 5. Rate Limiting
- 요청 횟수 제한

### 1.5 Middleware vs Guard vs Interceptor

#### Middleware
- **실행 시점**: 라우트 핸들러 전
- **용도**: 요청 전처리, 로깅, 인증
- **컨텍스트**: Express의 `req`, `res` 객체
- **예외 처리**: Express 예외 처리

#### Guard
- **실행 시점**: 라우트 핸들러 전 (Middleware 이후)
- **용도**: 인가(Authorization), 접근 제어
- **컨텍스트**: NestJS 실행 컨텍스트
- **예외 처리**: NestJS 예외 필터

#### Interceptor
- **실행 시점**: 라우트 핸들러 전후
- **용도**: 응답 변환, 로깅, 캐싱
- **컨텍스트**: NestJS 실행 컨텍스트
- **예외 처리**: NestJS 예외 필터

### 1.6 Middleware 등록 방법

#### 1. 모듈에서 등록 (권장)

```typescript
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(MyMiddleware)
      .forRoutes('*');
  }
}
```

#### 2. 함수형 미들웨어

```typescript
export function logger(req: Request, res: Response, next: NextFunction) {
  console.log('Request...');
  next();
}
```

---

## 2. Bearer Token Middleware 구현하기

### 2.1 Bearer Token Middleware의 목적

Bearer Token Middleware는 모든 요청에서 Authorization 헤더의 Bearer 토큰을 검증하고, 검증된 사용자 정보를 `req.user`에 추가합니다.

#### 주요 기능

1. Authorization 헤더에서 Bearer 토큰 추출
2. JWT 토큰 검증 (Access Token 또는 Refresh Token)
3. 검증된 페이로드를 `req.user`에 추가
4. 토큰이 없으면 다음 미들웨어로 진행 (인증 선택적)

### 2.2 BearerTokenMiddleware 구현

프로젝트에서 구현한 BearerTokenMiddleware를 확인해보겠습니다.

#### BearerTokenMiddleware 클래스

```1:71:src/auth/middleware/bearer-token.middleware.ts
import {
  BadRequestException,
  Injectable,
  NestMiddleware,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { NextFunction, Request, Response } from 'express';
import { envVariableKeys } from 'src/common/const/env.const';

@Injectable()
export class BearerTokenMiddleware implements NestMiddleware {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}
  async use(req: Request, res: Response, next: NextFunction) {
    // basic token
    // bearer token
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
      next();
      return;
    }

    const token = this.validateBearerToken(authHeader);

    try {
      const decodedPayload = this.jwtService.decode(token);

      if (
        decodedPayload.type !== 'refresh' &&
        decodedPayload.type !== 'access'
      ) {
        throw new BadRequestException('Invalid token');
      }

      const secretKey = this.configService.get<string>(
        decodedPayload.type === 'refresh'
          ? envVariableKeys.refreshTokenSecret
          : envVariableKeys.accessTokenSecret,
      )!;
      const payload = await this.jwtService.verifyAsync(token, {
        secret: secretKey,
      });

      req.user = payload;
      next();
    } catch (e) {
      throw new UnauthorizedException('토큰이 만료되었습니다');
    }
  }

  validateBearerToken(rawToken: string) {
    const bearerSplit = rawToken.split(' ');

    if (bearerSplit.length !== 2) {
      throw new BadRequestException('Invalid token');
    }

    const [bearer, token] = bearerSplit;

    if (bearer.toLocaleLowerCase() !== 'bearer') {
      throw new BadRequestException('Invalid token');
    }

    return token;
  }
}
```

### 2.3 코드 상세 설명

#### 1. 클래스 선언 및 의존성 주입

```typescript
@Injectable()
export class BearerTokenMiddleware implements NestMiddleware {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}
```

- `@Injectable()`: NestJS의 DI 시스템에 등록
- `implements NestMiddleware`: NestJS 미들웨어 인터페이스 구현
- `JwtService`, `ConfigService` 주입: JWT 검증 및 환경변수 접근

#### 2. use 메서드 - 메인 로직

```typescript
async use(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    next();
    return;
  }
```

- **Authorization 헤더 확인**: 헤더가 없으면 인증 없이 진행 (선택적 인증)
- **next() 호출**: 다음 미들웨어나 라우트 핸들러로 제어 전달

#### 3. Bearer Token 검증

```typescript
const token = this.validateBearerToken(authHeader);
```

- `validateBearerToken` 메서드로 Bearer 토큰 형식 검증
- `Bearer <token>` 형식에서 토큰 부분만 추출

#### 4. JWT 토큰 디코딩 및 검증

```typescript
const decodedPayload = this.jwtService.decode(token);

if (
  decodedPayload.type !== 'refresh' &&
  decodedPayload.type !== 'access'
) {
  throw new BadRequestException('Invalid token');
}
```

- **decode**: 토큰을 검증하지 않고 페이로드만 추출 (서명 검증 없음)
- **토큰 타입 확인**: `refresh` 또는 `access` 타입만 허용
- 타입이 없거나 잘못된 경우 예외 발생

#### 5. 시크릿 키 선택 및 검증

```typescript
const secretKey = this.configService.get<string>(
  decodedPayload.type === 'refresh'
    ? envVariableKeys.refreshTokenSecret
    : envVariableKeys.accessTokenSecret,
)!;
const payload = await this.jwtService.verifyAsync(token, {
  secret: secretKey,
});
```

- **시크릿 키 선택**: 토큰 타입에 따라 적절한 시크릿 키 선택
- **verifyAsync**: 토큰 서명 검증 및 만료 확인
- 검증 성공 시 페이로드 반환

#### 6. 사용자 정보 추가

```typescript
req.user = payload;
next();
```

- 검증된 페이로드를 `req.user`에 추가
- 라우트 핸들러에서 `@Request() req`로 접근 가능
- `next()` 호출로 다음 미들웨어로 진행

#### 7. validateBearerToken 메서드

```typescript
validateBearerToken(rawToken: string) {
  const bearerSplit = rawToken.split(' ');

  if (bearerSplit.length !== 2) {
    throw new BadRequestException('Invalid token');
  }

  const [bearer, token] = bearerSplit;

  if (bearer.toLocaleLowerCase() !== 'bearer') {
    throw new BadRequestException('Invalid token');
  }

  return token;
}
```

- **토큰 형식 검증**: `Bearer <token>` 형식 확인
- **토큰 추출**: 공백으로 분리하여 토큰 부분만 반환
- 형식이 맞지 않으면 예외 발생

### 2.4 AppModule에서 Middleware 등록

AppModule에서 BearerTokenMiddleware를 등록하는 방법을 확인해보겠습니다.

#### AppModule 설정

```56:72:src/app.module.ts
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(BearerTokenMiddleware)
      .exclude(
        {
          path: '/auth/login',
          method: RequestMethod.POST,
        },
        {
          path: '/auth/register',
          method: RequestMethod.POST,
        },
      )
      .forRoutes('*');
  }
}
```

#### 코드 설명

1. **NestModule 구현**
   ```typescript
   export class AppModule implements NestModule {
     configure(consumer: MiddlewareConsumer) { ... }
   }
   ```
   - `NestModule` 인터페이스 구현
   - `configure` 메서드에서 미들웨어 설정

2. **Middleware 적용**
   ```typescript
   consumer.apply(BearerTokenMiddleware)
   ```
   - `BearerTokenMiddleware`를 적용할 미들웨어로 지정

3. **경로 제외**
   ```typescript
   .exclude(
     { path: '/auth/login', method: RequestMethod.POST },
     { path: '/auth/register', method: RequestMethod.POST },
   )
   ```
   - 로그인과 회원가입 엔드포인트는 미들웨어 제외
   - 인증이 필요 없는 엔드포인트는 제외해야 함

4. **모든 라우트에 적용**
   ```typescript
   .forRoutes('*');
   ```
   - 와일드카드 `'*'`로 모든 라우트에 적용
   - 제외된 경로를 제외하고 모든 요청에 미들웨어 실행

### 2.5 컨트롤러에서 사용

미들웨어에서 설정한 `req.user`를 컨트롤러에서 사용하는 방법을 확인해보겠습니다.

#### AuthController에서 사용

```28:33:src/auth/auth.controller.ts
  @Post('token/access')
  async rotateAccessToken(@Request() req: any) {
    return {
      accessToken: await this.authService.issueToken(req.user, false),
    };
  }
```

- `@Request() req`로 요청 객체 접근
- `req.user`에 미들웨어에서 설정한 페이로드가 들어있음
- 페이로드에서 사용자 정보 추출하여 사용

#### MovieController에서 사용

```24:32:src/movie/movie.controller.ts
  @Get()
  getMovies(
    @Request() req: any,
    @Query('title', MovieTitleValidationPipe) title?: string,
  ) {
    console.log(req.user);
    // title 쿼리의 타입이 string 타입인지?
    return this.movieService.findAll(title);
  }
```

- 모든 엔드포인트에서 `req.user`로 사용자 정보 접근 가능
- 토큰이 있으면 사용자 정보가, 없으면 `undefined`가 됨

### 2.6 Middleware의 장점

#### 1. 중앙 집중식 인증 처리
- 모든 라우트에서 일관된 인증 로직 적용
- 코드 중복 제거

#### 2. 선택적 인증
- 토큰이 없어도 요청 진행 가능
- 특정 엔드포인트만 인증 필수로 설정 가능

#### 3. 유연한 경로 제어
- `exclude`로 특정 경로 제외
- `forRoutes`로 특정 경로만 적용

#### 4. 타입 안전성
- 토큰 타입에 따라 적절한 시크릿 키 사용
- TypeScript로 타입 체크

### 2.7 주의사항

#### 1. 토큰 검증 순서
- `decode`로 먼저 타입 확인
- 타입에 따라 적절한 시크릿 키로 `verify` 수행

#### 2. 에러 처리
- 토큰 만료 시 적절한 예외 발생
- 클라이언트에 명확한 에러 메시지 전달

#### 3. 성능 고려
- 모든 요청에 미들웨어가 실행되므로 성능 영향 고려
- 불필요한 검증은 제외

#### 4. 보안
- 토큰이 없어도 진행되는 선택적 인증 방식
- 인증이 필요한 엔드포인트는 Guard로 추가 보호

---

## 3. 정리

### 3.1 Middleware의 역할

- **요청 전처리**: 라우트 핸들러 실행 전 요청 처리
- **인증 처리**: JWT 토큰 검증 및 사용자 정보 추가
- **선택적 적용**: 특정 경로 제외 가능

### 3.2 BearerTokenMiddleware의 특징

- **선택적 인증**: 토큰이 없어도 요청 진행
- **타입별 검증**: Access Token과 Refresh Token 모두 지원
- **자동 사용자 정보 추가**: `req.user`에 페이로드 추가

### 3.3 Middleware vs Guard

- **Middleware**: 모든 요청에 실행, 선택적 인증
- **Guard**: 특정 엔드포인트에만 적용, 필수 인증

### 3.4 사용 시나리오

1. **전역 인증**: 모든 엔드포인트에서 사용자 정보 필요 시
2. **선택적 인증**: 일부 엔드포인트만 인증 필요 시
3. **로깅/모니터링**: 모든 요청에 대한 로깅

---

## 참고 자료

- [NestJS Middleware 공식 문서](https://docs.nestjs.com/middleware)
- [Express Middleware 가이드](https://expressjs.com/en/guide/using-middleware.html)
- [JWT 토큰 검증 Best Practices](https://auth0.com/blog/a-look-at-the-latest-draft-for-jwt-bcp/)
