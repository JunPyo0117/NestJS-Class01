# Part 22. 좋아요 시스템

## 목차
1. [중간테이블 Entity로 직접 생성하기](#1-중간테이블-entity로-직접-생성하기)
2. [좋아요 시스템 로직 완성하기](#2-좋아요-시스템-로직-완성하기)
3. [좋아요 여부 보여주는 필드 추가하기](#3-좋아요-여부-보여주는-필드-추가하기)
4. [DELETE CASCADE 설정](#4-delete-cascade-설정)
5. [좋아요 버그 수정](#5-좋아요-버그-수정)

---

## 1. 중간테이블 Entity로 직접 생성하기

### 1.1 ManyToMany vs 중간테이블 Entity

#### ManyToMany의 한계

TypeORM의 `@ManyToMany` 데코레이터를 사용하면 자동으로 중간테이블이 생성되지만, 중간테이블에 추가 컬럼을 넣을 수 없습니다.

**예시:**
- 영화와 사용자의 좋아요 관계
- 좋아요/싫어요 구분 (`isLike: boolean`)
- 좋아요 시간 등 추가 정보

이런 경우 중간테이블을 직접 Entity로 만들어야 합니다.

### 1.2 MovieUserLike Entity 생성

```typescript:src/movie/entity/movie-user-like.entity.ts
import {
  Column,
  Entity,
  ManyToOne,
  PrimaryColumn,
} from 'typeorm';
import { Movie } from './movie.entity';
import { User } from 'src/user/entity/user.entity';

@Entity()
export class MovieUserLike {
  @PrimaryColumn({
    name: 'movieId',
    type: 'int8',
  })
  @ManyToOne(() => Movie, (movie) => movie.likedUsers, {
    onDelete: 'CASCADE',
  })
  movie: Movie;

  @PrimaryColumn({
    name: 'userId',
    type: 'int8',
  })
  @ManyToOne(() => User, (user) => user.likedMovies, {
    onDelete: 'CASCADE',
  })
  user: User;

  @Column()
  isLike: boolean;
}
```

#### 핵심 포인트

1. **복합 기본 키 (Composite Primary Key)**
   - `@PrimaryColumn`을 두 개 사용하여 `movieId`와 `userId`를 복합 기본 키로 설정
   - 같은 영화에 같은 사용자가 중복으로 좋아요를 누를 수 없도록 보장

2. **ManyToOne 관계**
   - `@ManyToOne`으로 `Movie`와 `User` 엔티티와 관계 설정
   - `@PrimaryColumn`과 함께 사용하여 외래 키이면서 기본 키가 됨

3. **추가 컬럼**
   - `isLike: boolean`: 좋아요(`true`) 또는 싫어요(`false`) 구분

### 1.3 관계 설정

#### Movie Entity에 관계 추가

```typescript:src/movie/entity/movie.entity.ts
@OneToMany(() => MovieUserLike, (mul) => mul.movie)
likedUsers: MovieUserLike[];
```

#### User Entity에 관계 추가

```typescript:src/user/entity/user.entity.ts
@OneToMany(() => MovieUserLike, (mul) => mul.user)
likedMovies: MovieUserLike[];
```

### 1.4 Module에 등록

```typescript:src/movie/movie.module.ts
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Movie,
      MovieDetail,
      Director,
      Genre,
      User,
      MovieUserLike,  // 중간테이블 Entity 등록
    ]),
    // ...
  ],
  // ...
})
export class MovieModule {}
```

### 1.5 Service에 Repository 주입

```typescript:src/movie/movie.service.ts
constructor(
  @InjectRepository(Movie)
  private readonly movieRepository: Repository<Movie>,
  // ... other repositories
  @InjectRepository(MovieUserLike)
  private readonly movieUserLikeRepository: Repository<MovieUserLike>,
  // ...
) {}
```

---

## 2. 좋아요 시스템 로직 완성하기

### 2.1 Controller 엔드포인트 생성

좋아요와 싫어요를 위한 두 개의 엔드포인트를 생성합니다.

```typescript:src/movie/movie.controller.ts
@Post(':id/like')
createMovieLike(
  @Param('id', ParseIntPipe) movieId: number,
  @UserId() userId: number,
) {
  return this.movieService.toggleMovieLike(movieId, userId, true);
}

@Post(':id/dislike')
createMovieDislike(
  @Param('id', ParseIntPipe) movieId: number,
  @UserId() userId: number,
) {
  return this.movieService.toggleMovieLike(movieId, userId, false);
}
```

#### 특징

- `@UserId()` 커스텀 데코레이터로 사용자 ID 자동 추출
- 좋아요는 `isLike: true`, 싫어요는 `isLike: false`로 전달
- 같은 `toggleMovieLike` 메서드 사용

### 2.2 Service 로직 구현

```typescript:src/movie/movie.service.ts
async toggleMovieLike(movieId: number, userId: number, isLike: boolean) {
  // 1. 영화 존재 확인
  const movie = await this.movieRepository.findOne({
    where: { id: movieId },
    relations: ['likedUsers'],
  });

  if (!movie) {
    throw new BadRequestException(`존재하지 않는 영화입니다.`);
  }

  // 2. 사용자 존재 확인
  const user = await this.userRepository.findOne({
    where: { id: userId },
  });

  if (!user) {
    throw new UnauthorizedException(`존재하지 않는 사용자입니다.`);
  }

  // 3. 기존 좋아요 기록 확인
  const likeRecord = await this.movieUserLikeRepository
    .createQueryBuilder('mul')
    .leftJoinAndSelect('mul.movie', 'movie')
    .leftJoinAndSelect('mul.user', 'user')
    .where('movie.id = :movieId', { movieId })
    .andWhere('user.id = :userId', { userId })
    .getOne();

  // 4. 로직 처리
  if (likeRecord) {
    // 기존 기록이 있는 경우
    if (isLike === likeRecord.isLike) {
      // 같은 상태면 삭제 (토글)
      await this.movieUserLikeRepository.delete({
        movie,
        user,
      });
    } else {
      // 다른 상태면 업데이트 (좋아요 → 싫어요 또는 싫어요 → 좋아요)
      await this.movieUserLikeRepository.update(
        {
          movie,
          user,
        },
        {
          isLike,
        },
      );
    }
  } else {
    // 기존 기록이 없으면 새로 생성
    await this.movieUserLikeRepository.save({
      movie,
      user,
      isLike,
    });
  }

  // 5. 최종 결과 반환
  const result = await this.movieUserLikeRepository
    .createQueryBuilder('mul')
    .leftJoinAndSelect('mul.movie', 'movie')
    .leftJoinAndSelect('mul.user', 'user')
    .where('movie.id = :movieId', { movieId })
    .andWhere('user.id = :userId', { userId })
    .getOne();

  return {
    isLike: result && result.isLike,
  };
}
```

### 2.3 로직 흐름 설명

#### 케이스 1: 처음 좋아요 누르기
```
1. likeRecord = null (기존 기록 없음)
2. 새로 생성: { movie, user, isLike: true }
3. 반환: { isLike: true }
```

#### 케이스 2: 좋아요 취소 (토글)
```
1. likeRecord = { isLike: true }
2. isLike === likeRecord.isLike → true
3. 삭제
4. 반환: { isLike: false } (result가 null이므로)
```

#### 케이스 3: 좋아요 → 싫어요 변경
```
1. likeRecord = { isLike: true }
2. isLike === likeRecord.isLike → false
3. 업데이트: { isLike: false }
4. 반환: { isLike: false }
```

#### 케이스 4: 싫어요 → 좋아요 변경
```
1. likeRecord = { isLike: false }
2. isLike === likeRecord.isLike → false
3. 업데이트: { isLike: true }
4. 반환: { isLike: true }
```

### 2.4 동작 예시

```bash
# 1. 좋아요 누르기
POST /movie/4/like
→ { "isLike": true }

# 2. 다시 좋아요 누르기 (토글)
POST /movie/4/like
→ { "isLike": false } (취소됨)

# 3. 싫어요 누르기
POST /movie/4/dislike
→ { "isLike": false }

# 4. 좋아요로 변경
POST /movie/4/like
→ { "isLike": true }
```

---

## 3. 좋아요 여부 보여주는 필드 추가하기

### 3.1 문제 상황

영화 목록을 조회할 때, 현재 사용자가 각 영화에 좋아요를 눌렀는지 여부를 알 수 없습니다.

### 3.2 해결 방법

`findAll` 메서드에서 사용자 ID가 있으면 좋아요 상태를 조회하여 `likeStatus` 필드를 추가합니다.

```typescript:src/movie/movie.service.ts
async findAll(dto: GetMoviesDto, userId?: number) {
  const { title } = dto;

  const qb = this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres');

  if (title) {
    qb.where('movie.title LIKE :title', { title: `%${title}%` });
  }

  // 커서 페이지네이션 적용
  const { nextCursor } =
    await this.commonService.applyCursorPaginationParamsToQb(qb, dto);

  let [data, count] = await qb.getManyAndCount();

  // 사용자 ID가 있으면 좋아요 상태 조회
  if (userId) {
    const movieIds = data.map((movie) => movie.id);
    const likedMovies =
      movieIds.length < 1
        ? []
        : await this.movieUserLikeRepository
            .createQueryBuilder('mul')
            .leftJoinAndSelect('mul.movie', 'movie')
            .leftJoinAndSelect('mul.user', 'user')
            .where('movie.id IN (:...movieIds)', { movieIds })
            .andWhere('user.id = :userId', { userId })
            .getMany();

    // Map으로 변환하여 빠른 조회
    const likedMovieMap = likedMovies.reduce(
      (acc, next) => ({
        ...acc,
        [next.movie.id]: next.isLike,
      }),
      {},
    );

    // 각 영화에 likeStatus 필드 추가
    data = data.map((x) => ({
      ...x,
      likeStatus: x.id in likedMovieMap ? likedMovieMap[x.id] : null,
    }));
  }

  return {
    data,
    count,
    nextCursor,
  };
}
```

### 3.3 로직 설명

1. **영화 목록 조회**: 기본 쿼리로 영화 목록 가져오기
2. **사용자 ID 확인**: `userId`가 있으면 좋아요 상태 조회
3. **일괄 조회**: `IN` 쿼리로 한 번에 모든 영화의 좋아요 상태 조회
4. **Map 변환**: `reduce`로 `{ movieId: isLike }` 형태의 Map 생성
5. **필드 추가**: 각 영화 객체에 `likeStatus` 필드 추가

### 3.4 Controller 수정

```typescript:src/movie/movie.controller.ts
@Get()
@Public()
getMovies(@Query() dto: GetMoviesDto, @UserId() UserId?: number) {
  return this.movieService.findAll(dto, UserId);
}
```

#### 특징

- `@UserId()` 데코레이터 사용 (옵셔널)
- 로그인하지 않은 사용자는 `UserId`가 `undefined`
- 로그인한 사용자는 자동으로 좋아요 상태 포함

### 3.5 응답 예시

#### 로그인하지 않은 사용자

```json
{
  "data": [
    {
      "id": 1,
      "title": "영화 제목",
      "director": { ... },
      "genres": [ ... ]
      // likeStatus 없음
    }
  ],
  "count": 10,
  "nextCursor": "..."
}
```

#### 로그인한 사용자

```json
{
  "data": [
    {
      "id": 1,
      "title": "영화 제목",
      "director": { ... },
      "genres": [ ... ],
      "likeStatus": true  // 좋아요를 눌렀으면 true, 싫어요면 false, 없으면 null
    }
  ],
  "count": 10,
  "nextCursor": "..."
}
```

### 3.6 성능 최적화

#### N+1 문제 방지

만약 각 영화마다 개별 쿼리를 실행하면:

```typescript
// ❌ 비효율적 (N+1 문제)
for (const movie of data) {
  const like = await this.movieUserLikeRepository.findOne({
    where: { movie: { id: movie.id }, user: { id: userId } }
  });
}
```

**문제점:**
- 영화가 10개면 10번의 추가 쿼리 실행
- 데이터베이스 부하 증가

**해결책:**
- `IN` 쿼리로 한 번에 조회
- Map으로 변환하여 O(1) 조회 시간

---

## 4. DELETE CASCADE 설정

### 4.1 문제 상황

영화나 사용자가 삭제될 때, 관련된 좋아요 기록이 남아있으면 외래 키 제약 조건으로 인해 삭제가 실패합니다.

### 4.2 해결 방법

`@ManyToOne` 데코레이터에 `onDelete: 'CASCADE'` 옵션을 추가합니다.

```typescript:src/movie/entity/movie-user-like.entity.ts
@PrimaryColumn({
  name: 'movieId',
  type: 'int8',
})
@ManyToOne(() => Movie, (movie) => movie.likedUsers, {
  onDelete: 'CASCADE',  // 영화 삭제 시 좋아요 기록도 자동 삭제
})
movie: Movie;

@PrimaryColumn({
  name: 'userId',
  type: 'int8',
})
@ManyToOne(() => User, (user) => user.likedMovies, {
  onDelete: 'CASCADE',  // 사용자 삭제 시 좋아요 기록도 자동 삭제
})
user: User;
```

### 4.3 동작 방식

#### 영화 삭제 시

```sql
-- 영화 삭제
DELETE FROM movie WHERE id = 1;

-- 자동으로 실행됨
DELETE FROM movie_user_like WHERE movieId = 1;
```

#### 사용자 삭제 시

```sql
-- 사용자 삭제
DELETE FROM user WHERE id = 1;

-- 자동으로 실행됨
DELETE FROM movie_user_like WHERE userId = 1;
```

### 4.4 CASCADE 옵션 종류

| 옵션 | 설명 | 동작 |
|------|------|------|
| `'CASCADE'` | 부모 삭제 시 자식도 삭제 | 영화 삭제 → 좋아요 기록 삭제 |
| `'SET NULL'` | 부모 삭제 시 자식을 NULL로 설정 | 외래 키가 nullable일 때만 가능 |
| `'RESTRICT'` | 부모 삭제 시 에러 발생 (기본값) | 삭제 방지 |
| `'NO ACTION'` | `RESTRICT`와 유사 | 삭제 방지 |

### 4.5 주의사항

- **복합 기본 키**: `MovieUserLike`는 복합 기본 키를 사용하므로, 부모 중 하나만 삭제되어도 해당 레코드는 삭제됩니다.
- **데이터 무결성**: CASCADE 설정으로 인해 의도치 않은 데이터 삭제가 발생할 수 있으므로 주의가 필요합니다.

---

## 5. 좋아요 버그 수정

### 5.1 버그 상황

좋아요 시스템에서 발생할 수 있는 주요 버그들:

1. **중복 좋아요**: 같은 사용자가 같은 영화에 여러 번 좋아요를 누를 수 있음
2. **상태 불일치**: 좋아요를 눌렀는데 `likeStatus`가 `null`로 표시됨
3. **삭제 후 조회**: 좋아요를 취소했는데도 `likeStatus`가 남아있음

### 5.2 버그 수정 사항

#### 1. 복합 기본 키로 중복 방지

```typescript
@PrimaryColumn({ name: 'movieId' })
@PrimaryColumn({ name: 'userId' })
```

- `movieId`와 `userId`의 조합이 고유하므로 중복 방지
- 데이터베이스 레벨에서 제약 조건 보장

#### 2. 삭제 후 결과 조회

```typescript
// 삭제 후 다시 조회하여 정확한 상태 반환
const result = await this.movieUserLikeRepository
  .createQueryBuilder('mul')
  .leftJoinAndSelect('mul.movie', 'movie')
  .leftJoinAndSelect('mul.user', 'user')
  .where('movie.id = :movieId', { movieId })
  .andWhere('user.id = :userId', { userId })
  .getOne();

return {
  isLike: result && result.isLike,  // null이면 false 반환
};
```

**문제점:**
- 좋아요를 취소하면 `result`가 `null`
- `result.isLike` 접근 시 에러 발생 가능

**해결책:**
- `result && result.isLike`로 안전하게 접근
- `null`이면 `false` 반환

#### 3. likeStatus null 처리

```typescript
likeStatus: x.id in likedMovieMap ? likedMovieMap[x.id] : null,
```

**의미:**
- `true`: 좋아요를 눌렀음
- `false`: 싫어요를 눌렀음
- `null`: 아무것도 누르지 않음

### 5.3 추가 개선 사항

#### 좋아요 개수 업데이트

현재는 `likeCount` 필드가 있지만 업데이트되지 않습니다. 필요하다면 트리거나 애플리케이션 로직으로 업데이트할 수 있습니다.

```typescript
// 좋아요 생성/삭제 시 likeCount 업데이트
await this.movieRepository.update(
  { id: movieId },
  { likeCount: () => 'likeCount + 1' }  // 또는 -1
);
```

---

## 정리

### 좋아요 시스템 구조

```
┌─────────────┐         ┌──────────────────┐         ┌─────────────┐
│    Movie    │────────<│  MovieUserLike   │>────────│    User     │
│             │         │                  │         │             │
│ - id        │         │ - movieId (PK)    │         │ - id        │
│ - title     │         │ - userId (PK)    │         │ - email     │
│ - likeCount │         │ - isLike         │         │             │
└─────────────┘         └──────────────────┘         └─────────────┘
```

### 주요 특징

1. **복합 기본 키**: `movieId`와 `userId`의 조합으로 중복 방지
2. **토글 기능**: 같은 상태를 다시 누르면 취소
3. **상태 변경**: 좋아요 ↔ 싫어요 전환 가능
4. **일괄 조회**: N+1 문제 방지를 위한 최적화
5. **CASCADE 삭제**: 부모 삭제 시 자식도 자동 삭제

### API 엔드포인트

| 메서드 | 경로 | 설명 |
|--------|------|------|
| `POST` | `/movie/:id/like` | 좋아요 누르기/취소 |
| `POST` | `/movie/:id/dislike` | 싫어요 누르기/취소 |
| `GET` | `/movie` | 영화 목록 (likeStatus 포함) |

### 응답 형식

```typescript
// 좋아요/싫어요 응답
{
  isLike: boolean | null  // true: 좋아요, false: 싫어요, null: 없음
}

// 영화 목록 응답
{
  data: [
    {
      id: number,
      title: string,
      likeStatus: boolean | null,  // 현재 사용자의 좋아요 상태
      // ... other fields
    }
  ],
  count: number,
  nextCursor: string
}
```

좋아요 시스템은 사용자 경험을 향상시키는 중요한 기능으로, 복합 기본 키와 CASCADE 설정을 통해 데이터 무결성을 보장합니다.
