# Part 25. Logging

## 목차
1. [NestJS 기본 Logger 사용하기](#1-nestjs-기본-logger-사용하기)
2. [Custom Logger 제작하기](#2-custom-logger-제작하기)
3. [Winston 사용하기](#3-winston-사용하기)

---

## 1. NestJS 기본 Logger 사용하기

### 1.1 Logger란?

**Logger(로거)**는 애플리케이션의 실행 상태, 오류, 디버그 정보 등을 기록하는 도구입니다. 개발 및 운영 환경에서 애플리케이션의 동작을 추적하고 문제를 진단하는 데 필수적입니다.

#### Logger의 목적

1. **디버깅**: 애플리케이션 실행 흐름 추적
2. **모니터링**: 시스템 상태 및 성능 모니터링
3. **오류 추적**: 에러 발생 시 원인 파악
4. **감사(Audit)**: 중요한 작업 기록

### 1.2 NestJS 기본 Logger

NestJS는 기본적으로 `Logger` 클래스를 제공합니다. 간단한 로깅 작업에 적합합니다.

#### Logger 사용 방법

```typescript
import { Logger } from '@nestjs/common';

export class SomeService {
  private readonly logger = new Logger(SomeService.name);

  someMethod() {
    this.logger.log('로그 메시지');
    this.logger.error('에러 메시지');
    this.logger.warn('경고 메시지');
    this.logger.debug('디버그 메시지');
    this.logger.verbose('상세 메시지');
  }
}
```

#### Logger 메서드

| 메서드 | 설명 | 사용 시나리오 |
|--------|------|--------------|
| `log()` | 일반 정보 로그 | 일반적인 정보 기록 |
| `error()` | 에러 로그 | 예외 발생, 오류 상황 |
| `warn()` | 경고 로그 | 주의가 필요한 상황 |
| `debug()` | 디버그 로그 | 개발 중 디버깅 |
| `verbose()` | 상세 로그 | 매우 상세한 정보 |

#### Logger 출력 예시

```
[Nest] 12345  - 01/16/2026, 2:00:00 PM     LOG [SomeService] 로그 메시지
[Nest] 12345  - 01/16/2026, 2:00:01 PM   ERROR [SomeService] 에러 메시지
[Nest] 12345  - 01/16/2026, 2:00:02 PM    WARN [SomeService] 경고 메시지
```

### 1.3 Logger의 장단점

#### 장점

- **간단함**: 별도 설정 없이 바로 사용 가능
- **가벼움**: 추가 의존성 없음
- **빠른 시작**: 프로토타입이나 작은 프로젝트에 적합

#### 단점

- **기능 제한**: 로그 레벨 필터링, 파일 저장 등 고급 기능 부족
- **커스터마이징 어려움**: 출력 형식 변경이 제한적
- **프로덕션 부적합**: 운영 환경에서 필요한 기능 부족

---

## 2. Custom Logger 제작하기

### 2.1 Custom Logger가 필요한 이유

기본 `Logger`로는 부족한 경우, `ConsoleLogger`를 상속받아 커스텀 로거를 만들 수 있습니다.

#### Custom Logger의 장점

1. **커스텀 포맷**: 원하는 형식으로 로그 출력
2. **추가 기능**: 특정 레벨에 추가 로직 구현
3. **확장성**: 필요에 따라 기능 추가 가능

### 2.2 Custom Logger 구현

`ConsoleLogger`를 상속받아 커스텀 로거를 만듭니다.

```typescript:src/common/logger/default.logger.ts
import { ConsoleLogger, Injectable } from '@nestjs/common';

@Injectable()
export class DefaultLogger extends ConsoleLogger {
  warn(message: unknown, ...rest: unknown[]): void {
    console.log('---- WARN LOG ----');
    super.warn(message, ...rest);
  }

  error(message: unknown, ...rest: unknown[]): void {
    console.log('---- ERROR LOG ----');
    super.error(message, ...rest);
  }

  fatal(message: unknown, ...rest: unknown[]): void {
    console.log('---- FATAL LOG ----');
    super.fatal(message, ...rest);
  }
}
```

### 2.3 코드 설명

#### ConsoleLogger 상속

```typescript
export class DefaultLogger extends ConsoleLogger {
```

- `ConsoleLogger`는 NestJS의 기본 콘솔 로거 클래스
- 상속받아 필요한 메서드만 오버라이드

#### 메서드 오버라이드

```typescript
warn(message: unknown, ...rest: unknown[]): void {
  console.log('---- WARN LOG ----');
  super.warn(message, ...rest);
}
```

- `warn()` 메서드를 오버라이드하여 커스텀 로직 추가
- `super.warn()`을 호출하여 기본 동작 유지
- 로그 출력 전에 추가 메시지 출력

### 2.4 Custom Logger 사용하기

#### 전역으로 설정

```typescript
import { NestFactory } from '@nestjs/core';
import { DefaultLogger } from './common/logger/default.logger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: new DefaultLogger(),
  });
  await app.listen(3000);
}
```

#### 서비스에서 주입

```typescript
import { Injectable } from '@nestjs/common';
import { DefaultLogger } from './common/logger/default.logger';

@Injectable()
export class SomeService {
  constructor(private readonly logger: DefaultLogger) {}

  someMethod() {
    this.logger.warn('경고 메시지');
    // 출력: ---- WARN LOG ----
    //       [SomeService] 경고 메시지
  }
}
```

### 2.4 Custom Logger의 한계

- 여전히 콘솔 출력만 가능
- 파일 저장, 로그 레벨 필터링 등 고급 기능 부족
- 프로덕션 환경에 부적합

---

## 3. Winston 사용하기

### 3.1 Winston이란?

**Winston**은 Node.js용 강력한 로깅 라이브러리입니다. 다양한 출력 대상(콘솔, 파일, 데이터베이스 등)과 포맷팅 옵션을 제공합니다.

#### Winston의 특징

1. **다양한 Transport**: 콘솔, 파일, HTTP, 데이터베이스 등
2. **유연한 포맷팅**: 원하는 형식으로 로그 출력
3. **로깅 레벨**: `error`, `warn`, `info`, `verbose`, `debug`, `silly`
4. **프로덕션 준비**: 운영 환경에 적합한 기능 제공

### 3.2 Winston 설치

```bash
npm install winston nest-winston
```

- `winston`: Winston 라이브러리
- `nest-winston`: NestJS와 Winston 통합 패키지

### 3.3 WinstonModule 설정

`AppModule`에 `WinstonModule`을 등록합니다.

```typescript:src/app.module.ts
import { WinstonModule } from 'nest-winston';
import * as winston from 'winston';
import { join } from 'path';

@Module({
  imports: [
    WinstonModule.forRoot({
      level: 'debug',
      transports: [
        // 콘솔 출력
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize({
              all: true,
            }),
            winston.format.timestamp(),
            winston.format.printf((info) => {
              return `${info.timestamp} ${info.context} ${info.level}: ${info.message}`;
            }),
          ),
        }),
        // 파일 출력
        new winston.transports.File({
          dirname: join(process.cwd(), 'logs'),
          filename: 'logs.log',
          format: winston.format.combine(
            winston.format.colorize({
              all: true,
            }),
            winston.format.timestamp(),
            winston.format.printf((info) => {
              return `${info.timestamp} ${info.context} ${info.level}: ${info.message}`;
            }),
          ),
        }),
      ],
    }),
  ],
})
export class AppModule {}
```

### 3.4 Winston 설정 설명

#### level

```typescript
level: 'debug',
```

- 최소 로깅 레벨 설정
- `debug` 레벨 이상의 로그만 출력
- 레벨 순서: `error` < `warn` < `info` < `verbose` < `debug` < `silly`

#### transports

**Transport**는 로그를 출력할 대상을 의미합니다.

##### Console Transport

```typescript
new winston.transports.Console({
  format: winston.format.combine(
    winston.format.colorize({ all: true }),
    winston.format.timestamp(),
    winston.format.printf((info) => {
      return `${info.timestamp} ${info.context} ${info.level}: ${info.message}`;
    }),
  ),
})
```

- **`colorize`**: 로그 레벨에 색상 적용
- **`timestamp`**: 타임스탬프 추가
- **`printf`**: 커스텀 포맷 정의
  - `info.timestamp`: 로그 시간
  - `info.context`: 컨텍스트(서비스/컨트롤러 이름)
  - `info.level`: 로그 레벨
  - `info.message`: 로그 메시지

##### File Transport

```typescript
new winston.transports.File({
  dirname: join(process.cwd(), 'logs'),
  filename: 'logs.log',
  format: winston.format.combine(
    winston.format.colorize({ all: true }),
    winston.format.timestamp(),
    winston.format.printf((info) => {
      return `${info.timestamp} ${info.context} ${info.level}: ${info.message}`;
    }),
  ),
})
```

- **`dirname`**: 로그 파일이 저장될 디렉토리
- **`filename`**: 로그 파일 이름
- 파일에 로그를 저장하여 나중에 분석 가능

### 3.5 전역 Logger 설정

`main.ts`에서 Winston 로거를 전역으로 설정합니다.

```typescript:src/main.ts
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Winston 로거를 전역으로 설정
  app.useLogger(app.get(WINSTON_MODULE_NEST_PROVIDER));
  
  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
```

#### 설명

- `WINSTON_MODULE_NEST_PROVIDER`: Winston 모듈에서 제공하는 로거 프로바이더
- `app.useLogger()`: NestJS 애플리케이션의 전역 로거 설정
- 이제 모든 NestJS 내부 로그도 Winston을 통해 출력됨

### 3.6 서비스에서 Winston Logger 사용하기

`LoggerService`를 주입받아 사용합니다.

```typescript:src/common/task.service.ts
import { Injectable, Inject } from '@nestjs/common';
import type { LoggerService } from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

@Injectable()
export class TaskService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER)
    private readonly logger: LoggerService,
  ) {}

  @Cron('*/5 * * * * *')
  logEverySecond() {
    const logger = this.logger as Required<LoggerService>;
    
    logger.fatal('FATAL 레벨 로그', null, TaskService.name);
    logger.error('ERROR 레벨 로그', null, TaskService.name);
    logger.warn('WARN 레벨 로그', TaskService.name);
    logger.log('LOG 레벨 로그', TaskService.name);
    logger.debug('DEBUG 레벨 로그', TaskService.name);
    logger.verbose('VERBOSE 레벨 로그', TaskService.name);
  }
}
```

### 3.7 LoggerService 메서드

#### 메서드 시그니처

```typescript
interface LoggerService {
  log(message: any, context?: string): void;
  error(message: any, trace?: string, context?: string): void;
  warn(message: any, context?: string): void;
  debug(message: any, context?: string): void;
  verbose(message: any, context?: string): void;
  fatal?(message: any, context?: string): void;
}
```

#### 사용 예시

```typescript
// 일반 로그
logger.log('로그 메시지', 'ContextName');

// 에러 로그 (trace는 선택적)
logger.error('에러 메시지', '에러 스택', 'ContextName');

// 경고 로그
logger.warn('경고 메시지', 'ContextName');

// 디버그 로그
logger.debug('디버그 메시지', 'ContextName');

// 상세 로그
logger.verbose('상세 메시지', 'ContextName');

// 치명적 오류 (Winston에 기본 레벨이 없어서 커스텀 설정 필요)
logger.fatal('치명적 오류', null, 'ContextName');
```

### 3.8 Winston 로그 출력 예시

#### 콘솔 출력

```
2026-01-16T14:00:00.000Z TaskService info: LOG 레벨 로그
2026-01-16T14:00:00.001Z TaskService error: ERROR 레벨 로그
2026-01-16T14:00:00.002Z TaskService warn: WARN 레벨 로그
```

#### 파일 출력 (`logs/logs.log`)

```
2026-01-16T14:00:00.000Z TaskService info: LOG 레벨 로그
2026-01-16T14:00:00.001Z TaskService error: ERROR 레벨 로그
2026-01-16T14:00:00.002Z TaskService warn: WARN 레벨 로그
```

### 3.9 Winston 포맷 옵션

#### 주요 포맷

| 포맷 | 설명 | 예시 |
|------|------|------|
| `colorize()` | 로그 레벨에 색상 적용 | `error`는 빨간색 |
| `timestamp()` | 타임스탬프 추가 | `2026-01-16T14:00:00.000Z` |
| `json()` | JSON 형식으로 출력 | `{"level":"info","message":"..."}` |
| `simple()` | 간단한 형식 | `info: 메시지` |
| `printf()` | 커스텀 포맷 | 원하는 형식 정의 |

#### 포맷 조합

```typescript
winston.format.combine(
  winston.format.timestamp(),
  winston.format.colorize(),
  winston.format.printf((info) => {
    return `${info.timestamp} [${info.level}] ${info.message}`;
  }),
)
```

- `combine()`: 여러 포맷을 조합
- 순서대로 적용됨

### 3.10 Winston Transport 옵션

#### 추가 Transport 예시

##### Daily Rotate File

```typescript
import * as winston from 'winston';
import 'winston-daily-rotate-file';

new winston.transports.DailyRotateFile({
  dirname: join(process.cwd(), 'logs'),
  filename: 'application-%DATE%.log',
  datePattern: 'YYYY-MM-DD',
  maxSize: '20m',
  maxFiles: '14d',
})
```

- 날짜별로 로그 파일 분리
- 파일 크기 제한
- 오래된 파일 자동 삭제

##### HTTP Transport

```typescript
new winston.transports.Http({
  host: 'localhost',
  port: 3000,
  path: '/logs',
})
```

- HTTP 요청으로 로그 전송
- 중앙 집중식 로그 수집

### 3.11 환경별 로그 레벨 설정

```typescript
WinstonModule.forRoot({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  transports: [
    // ...
  ],
})
```

- **개발 환경**: `debug` 레벨 (모든 로그 출력)
- **프로덕션 환경**: `info` 레벨 (중요한 로그만 출력)

### 3.12 로그 파일 관리

#### .gitignore에 추가

```gitignore
logs/
*.log
```

- 로그 파일은 버전 관리에서 제외
- 로컬에서만 생성됨

#### 로그 디렉토리 구조

```
logs/
  ├── logs.log          # 일반 로그
  ├── error.log         # 에러만 저장 (선택적)
  └── combined.log      # 모든 로그 (선택적)
```

---

## 정리

### Logger 비교

| 기능 | NestJS Logger | Custom Logger | Winston |
|------|---------------|---------------|---------|
| 사용 난이도 | ⭐ 매우 쉬움 | ⭐⭐ 쉬움 | ⭐⭐⭐ 보통 |
| 기능 | 기본적 | 제한적 | 매우 풍부 |
| 파일 저장 | ❌ | ❌ | ✅ |
| 포맷 커스터마이징 | ❌ | ⚠️ 제한적 | ✅ |
| 프로덕션 준비 | ❌ | ❌ | ✅ |
| 성능 | 빠름 | 빠름 | 빠름 |

### 선택 가이드

1. **프로토타입/학습**: NestJS 기본 Logger
2. **간단한 커스터마이징**: Custom Logger
3. **프로덕션 애플리케이션**: Winston

### 주요 개념

1. **Logger**: 애플리케이션 로그를 기록하는 도구
2. **Log Level**: 로그의 중요도 (`error`, `warn`, `info`, `debug` 등)
3. **Transport**: 로그를 출력할 대상 (콘솔, 파일 등)
4. **Format**: 로그 출력 형식

### 실전 팁

1. **개발 환경**: `debug` 레벨로 상세한 로그 확인
2. **프로덕션 환경**: `info` 레벨로 중요한 로그만 기록
3. **로그 파일**: 파일 크기와 보관 기간 관리
4. **컨텍스트**: 서비스/컨트롤러 이름을 컨텍스트로 전달
5. **에러 로그**: `error()` 메서드에 스택 트레이스 포함
