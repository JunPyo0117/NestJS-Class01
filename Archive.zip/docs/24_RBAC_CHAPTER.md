# Part 15. RBAC

## 목차
1. [RBAC 이론](#1-rbac-이론)
2. [RBAC 구현하기](#2-rbac-구현하기)

---

## 1. RBAC 이론

### 1.1 RBAC란?

**RBAC(Role-Based Access Control, 역할 기반 접근 제어)**는 사용자의 역할(Role)에 따라 시스템 리소스에 대한 접근 권한을 제어하는 보안 모델입니다.

#### RBAC의 핵심 개념

1. **역할(Role)**: 사용자가 수행할 수 있는 작업을 정의하는 권한 집합
2. **권한(Permission)**: 특정 리소스나 작업에 대한 접근 권한
3. **사용자(User)**: 하나 이상의 역할을 가진 시스템 사용자

#### RBAC의 장점

- **유연성**: 역할 기반으로 권한 관리가 용이
- **확장성**: 새로운 역할 추가가 쉬움
- **관리 용이성**: 개별 사용자 대신 역할 단위로 권한 관리
- **보안성**: 최소 권한 원칙 적용 가능

### 1.2 계층적 RBAC (Hierarchical RBAC)

계층적 RBAC에서는 역할 간에 상위-하위 관계를 설정할 수 있습니다. 상위 역할은 하위 역할의 모든 권한을 상속받습니다.

#### 예시: 역할 계층

```
admin (0)
  └─ paidUser (1)
      └─ user (2)
```

- `admin`: 모든 권한 (0)
- `paidUser`: 유료 사용자 권한 (1)
- `user`: 일반 사용자 권한 (2)

#### 숫자 기반 비교

역할을 숫자로 표현하면 간단한 비교 연산으로 권한을 확인할 수 있습니다:

```typescript
// user.role <= requiredRole
// admin (0) <= admin (0) ✅
// paidUser (1) <= admin (0) ❌
// user (2) <= admin (0) ❌
```

### 1.3 Guard와 RBAC의 관계

RBAC는 Guard를 통해 구현됩니다. Guard는 요청을 처리하기 전에 사용자의 역할을 확인하고, 필요한 역할과 비교하여 접근을 허용하거나 거부합니다.

#### RBAC Guard의 동작 흐름

1. 요청 도착
2. RBAC Guard 실행
3. 데코레이터에서 요구되는 역할 확인
4. 사용자의 역할 확인
5. 역할 비교 (`user.role <= requiredRole`)
6. 허용/거부 결정

---

## 2. RBAC 구현하기

### 2.1 Role Enum 정의

먼저 사용자 역할을 정의하는 Enum을 생성합니다.

```typescript:src/user/entity/user.entity.ts
export enum Role {
  admin,
  paidUser,
  user,
}
```

#### Role Enum 설명

- `admin` (0): 관리자, 모든 권한
- `paidUser` (1): 유료 사용자, 제한된 권한
- `user` (2): 일반 사용자, 기본 권한

#### User Entity에 Role 추가

```typescript:src/user/entity/user.entity.ts
@Entity()
export class User extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    unique: true,
  })
  email: string;

  @Column()
  @Exclude({
    toPlainOnly: true,
  })
  password: string;

  @Column({
    enum: Role,
    default: Role.user,
  })
  role: Role;
}
```

**주요 설정:**
- `enum: Role`: TypeScript enum 사용
- `default: Role.user`: 기본값은 일반 사용자
- 데이터베이스에는 integer 타입으로 저장됨

### 2.2 RBAC Decorator 생성

RBAC 데코레이터를 생성하여 컨트롤러 메서드에 필요한 역할을 지정합니다.

```typescript:src/auth/decorator/rbac.decorator.ts
import { Reflector } from '@nestjs/core';
import { Role } from 'src/user/entity/user.entity';

export const RBAC = Reflector.createDecorator<Role>();
```

#### Reflector.createDecorator()

- `Reflector.createDecorator<Role>()`: Role 타입을 받는 커스텀 데코레이터 생성
- 메타데이터를 설정하는 데코레이터를 간단하게 생성
- Guard에서 `reflector.get()`으로 메타데이터 읽기 가능

### 2.3 RBAC Guard 구현

RBAC Guard를 구현하여 역할 기반 접근 제어를 수행합니다.

```typescript:src/auth/guard/rbac.guard.ts
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthService } from '../auth.service';
import { Reflector } from '@nestjs/core';
import { RBAC } from '../decorator/rbac.decorator';
import { Role } from 'src/user/entity/user.entity';

@Injectable()
export class RBACGuard implements CanActivate {
  constructor(
    private readonly authService: AuthService,
    private readonly reflector: Reflector,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const rbac = this.reflector.get<Role>(RBAC, context.getHandler());

    // Role Enum에 해당되는 값이 데코레이터에 들어갔는지 확인하기
    if (!Object.values(Role).includes(rbac)) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      return false;
    }

    return user.role <= rbac;
  }
}
```

#### RBAC Guard 동작 원리

1. **메타데이터 확인**: `@RBAC()` 데코레이터에서 요구되는 역할 가져오기
2. **데코레이터 없음**: 데코레이터가 없거나 유효하지 않으면 `true` 반환 (통과)
3. **사용자 확인**: `request.user`가 없으면 `false` 반환 (거부)
4. **역할 비교**: `user.role <= rbac`로 권한 확인
   - 숫자가 작을수록 높은 권한 (admin=0, paidUser=1, user=2)
   - `user.role <= rbac`이면 허용

#### 역할 비교 예시

```typescript
// admin (0)이 admin (0) 접근 시도
0 <= 0 ✅ 허용

// paidUser (1)이 admin (0) 접근 시도
1 <= 0 ❌ 거부

// user (2)가 paidUser (1) 접근 시도
2 <= 1 ❌ 거부

// admin (0)이 user (2) 접근 시도
0 <= 2 ✅ 허용 (상위 역할은 하위 권한 접근 가능)
```

### 2.4 전역 Guard 등록

`app.module.ts`에서 RBACGuard를 전역 Guard로 등록합니다.

```typescript:src/app.module.ts
import { APP_GUARD } from '@nestjs/core';
import { RBACGuard } from './auth/guard/rbac.guard';

@Module({
  // ... imports
  providers: [
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: RBACGuard,
    },
  ],
})
export class AppModule implements NestModule {
  // ...
}
```

#### Guard 실행 순서

1. **AuthGuard**: 인증 확인 (사용자가 로그인했는지)
2. **RBACGuard**: 인가 확인 (사용자가 필요한 역할을 가지고 있는지)

두 Guard가 모두 통과해야 요청이 처리됩니다.

### 2.5 컨트롤러에서 RBAC 사용

컨트롤러 메서드에 `@RBAC()` 데코레이터를 사용하여 필요한 역할을 지정합니다.

```typescript:src/movie/movie.controller.ts
import { RBAC } from 'src/auth/decorator/rbac.decorator';
import { Role } from 'src/user/entity/user.entity';

@Controller('movie')
export class MovieController {
  @Get()
  @Public()
  getMovies(@Query('title') title?: string) {
    return this.movieService.findAll(title);
  }

  @Get(':id')
  @Public()
  getMovie(@Param('id', ParseIntPipe) id: number) {
    return this.movieService.findOne(id);
  }

  @Post()
  @RBAC(Role.admin)
  createMovie(@Body() body: CreateMovieDto) {
    return this.movieService.create(body);
  }

  @Patch(':id')
  @RBAC(Role.admin)
  updateMovie(
    @Param('id', ParseIntPipe) id: string,
    @Body() body: UpdateMovieDto,
  ) {
    return this.movieService.update(+id, body);
  }

  @Delete(':id')
  @RBAC(Role.admin)
  deleteMovie(@Param('id', ParseIntPipe) id: string) {
    return this.movieService.remove(+id);
  }
}
```

#### 사용 예시 설명

- **@Public()**: 인증 없이 접근 가능 (모든 사용자)
- **@RBAC(Role.admin)**: admin 역할만 접근 가능
- **@RBAC(Role.paidUser)**: paidUser 이상의 역할 접근 가능 (admin, paidUser)
- **@RBAC(Role.user)**: 모든 인증된 사용자 접근 가능

### 2.6 RBAC와 Public Decorator 함께 사용

`@Public()` 데코레이터와 `@RBAC()` 데코레이터를 함께 사용할 수 있습니다.

#### 우선순위

1. `@Public()`이 있으면 인증 없이 접근 가능 (RBAC 체크 스킵)
2. `@Public()`이 없고 `@RBAC()`이 있으면 역할 확인
3. 둘 다 없으면 인증만 확인 (AuthGuard만 통과)

#### 예시

```typescript
@Get()
@Public()  // 인증 없이 접근 가능
getMovies() {
  return this.movieService.findAll();
}

@Post()
@RBAC(Role.admin)  // admin만 접근 가능
createMovie(@Body() body: CreateMovieDto) {
  return this.movieService.create(body);
}

@Patch(':id')
// @Public()도 @RBAC()도 없음 → 인증만 확인
updateMovie(@Param('id') id: number, @Body() body: UpdateMovieDto) {
  return this.movieService.update(id, body);
}
```

---

## 정리

### RBAC의 핵심 개념

1. **역할 기반 접근 제어**: 사용자의 역할에 따라 권한 부여
2. **계층적 구조**: 숫자 기반 비교로 상위 역할이 하위 권한 접근 가능
3. **Guard 기반 구현**: NestJS Guard를 통해 RBAC 구현

### 구현 요약

1. **Role Enum**: 사용자 역할 정의 (admin, paidUser, user)
2. **RBAC Decorator**: 메서드에 필요한 역할 지정
3. **RBAC Guard**: 역할 비교를 통한 접근 제어
4. **전역 등록**: APP_GUARD로 모든 라우트에 적용
5. **컨트롤러 사용**: @RBAC() 데코레이터로 권한 지정

### 역할 비교 로직

```typescript
// user.role <= requiredRole
// 숫자가 작을수록 높은 권한
// admin (0) <= paidUser (1) ✅ (상위 역할은 하위 권한 접근 가능)
// paidUser (1) <= admin (0) ❌ (하위 역할은 상위 권한 접근 불가)
```

### Guard 실행 순서

```
요청 → Middleware → AuthGuard → RBACGuard → Controller
```

1. **Middleware**: 토큰 파싱 및 사용자 정보 설정
2. **AuthGuard**: 인증 확인 (로그인 여부)
3. **RBACGuard**: 인가 확인 (역할 확인)
4. **Controller**: 비즈니스 로직 실행

RBAC는 확장 가능하고 유지보수가 쉬운 권한 관리 시스템을 구축하는 핵심 패턴입니다.
