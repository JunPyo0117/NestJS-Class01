# Transaction

## 목차
1. [Transaction 이론](#transaction-이론)
2. [Create 함수에서 Transaction 적용하기](#create-함수에서-transaction-적용하기)
3. [Update 함수 Transaction 적용하기](#update-함수-transaction-적용하기)

---

## Transaction 이론

### Transaction이란?

**Transaction(트랜잭션)**은 데이터베이스에서 하나의 논리적 작업 단위를 의미합니다. 여러 개의 SQL 문을 하나의 작업으로 묶어서, 모두 성공하거나 모두 실패하도록 보장합니다.

### Transaction의 특징 (ACID)

1. **Atomicity (원자성)**: 트랜잭션의 모든 작업이 성공하거나 모두 실패해야 합니다.
2. **Consistency (일관성)**: 트랜잭션 전후로 데이터베이스의 일관성이 유지되어야 합니다.
3. **Isolation (격리성)**: 동시에 실행되는 트랜잭션들이 서로 영향을 주지 않아야 합니다.
4. **Durability (지속성)**: 트랜잭션이 커밋되면 결과가 영구적으로 저장되어야 합니다.

### Transaction의 문제점 (Transaction Anomalies)

동시에 여러 트랜잭션이 실행될 때 발생할 수 있는 문제들입니다.

#### 1. Lost Update (Lost Reads)

**정의**: 두 트랜잭션이 같은 데이터를 업데이트해서 하나의 업데이트가 손실되는 경우

**예시**:

```sql
-- 초기 상태
account 테이블: id = 1, balance = 1000

-- Transaction 1
BEGIN TRANSACTION;
SELECT balance FROM account WHERE id = 1; -- 1000 반환
UPDATE account SET balance = balance - 100 WHERE id = 1; -- 900으로 변경

-- Transaction 2 (동시 실행)
BEGIN TRANSACTION;
SELECT balance FROM account WHERE id = 1; -- 1000 반환 (Transaction 1이 아직 커밋 전)
UPDATE account SET balance = balance - 200 WHERE id = 1; -- 800으로 변경

-- Transaction 1 진행
COMMIT; -- Balance = 900

-- Transaction 2 진행
COMMIT; -- Balance = 800

-- 최종 결과
account 테이블: id = 1, balance = 800
```

**문제점**:
- Transaction 1이 100을 차감했지만, Transaction 2가 초기값(1000)을 기준으로 200을 차감하여 Transaction 1의 변경사항이 손실되었습니다.
- 예상 결과: 1000 - 100 - 200 = 700
- 실제 결과: 800

**해결 방법**: Optimistic Lock 전략 사용

#### 2. Dirty Reads

**정의**: 아직 Commit 되지 않은 값을 다른 트랜잭션이 읽는 경우

**예시**:

```sql
-- 초기 상태
account 테이블: id = 1, balance = 1000

-- Transaction 1
BEGIN TRANSACTION;
UPDATE account SET balance = balance - 100 WHERE id = 1; -- balance = 900

-- Transaction 2
BEGIN TRANSACTION;
SELECT balance FROM account WHERE id = 1; -- 900 반환 (아직 커밋되지 않은 값)

-- Transaction 1 Rollback
ROLLBACK; -- Balance 1000으로 되돌림

-- Transaction 2 진행
-- Transaction 2에서 읽은 balance 값은 잘못된 값임.
```

**문제점**:
- Transaction 2가 Transaction 1의 커밋되지 않은 값을 읽었습니다.
- Transaction 1이 롤백되면 Transaction 2가 읽은 값(900)은 잘못된 값이 됩니다.

**해결 방법**: Read Committed 트랜잭션 레벨 사용

#### 3. Non-repeatable Reads

**정의**: 한 트랜잭션에서 데이터를 두 번 읽을 때 다른 결과가 나오는 경우

**예시**:

```sql
-- 초기 상태
account 테이블: id = 1, balance = 1000

-- Transaction 1
BEGIN TRANSACTION;
SELECT balance FROM account WHERE id = 1; -- 1000 반환

-- Transaction 2
BEGIN TRANSACTION;
UPDATE account SET balance = balance - 100 WHERE id = 1; -- balance = 900
COMMIT;

-- Transaction 1 계속 진행
SELECT balance FROM account WHERE id = 1; -- 900 반환 (non-repeatable read)
COMMIT;
```

**문제점**:
- Transaction 1이 같은 데이터를 두 번 읽었는데 다른 결과가 나왔습니다.
- 첫 번째 읽기: 1000
- 두 번째 읽기: 900

**해결 방법**: Repeatable Read 트랜잭션 레벨 사용

#### 4. Phantom Reads

**정의**: 첫 Read 이후에 다른 트랜잭션에서 데이터를 추가한 경우

**예시**:

```sql
-- 초기 상태
account 테이블:
  id = 1, balance = 1000
  id = 2, balance = 1500

-- Transaction 1 (첫 번째 읽기)
BEGIN TRANSACTION;
SELECT * FROM account WHERE balance > 1000; -- account 2 반환

-- Transaction 2
BEGIN TRANSACTION;
INSERT INTO account (id, balance) VALUES (3, 1200);
COMMIT;

-- Transaction 1 (두 번째 읽기)
SELECT * FROM account WHERE balance > 1000; -- account 2 and account 3 반환 (phantom read)
COMMIT;
```

**문제점**:
- Transaction 1이 같은 쿼리를 두 번 실행했는데 결과가 달라졌습니다.
- 첫 번째 읽기: account 2만 반환
- 두 번째 읽기: account 2와 account 3 반환 (새로 추가된 행)

**해결 방법**: Serializable 트랜잭션 레벨 사용

### Transaction Isolation Level

트랜잭션 격리 수준에 따라 발생할 수 있는 문제가 달라집니다.

| Isolation Level | Dirty Read | Non-Repeatable Read | Phantom Read |
|----------------|------------|---------------------|--------------|
| **Read Uncommitted** | 가능 | 가능 | 가능 |
| **Read Committed** | 불가능 | 가능 | 가능 |
| **Repeatable Read** | 불가능 | 불가능 | 가능 |
| **Serializable** | 불가능 | 불가능 | 불가능 |

**설명**:
- **Read Uncommitted**: 가장 낮은 격리 수준, 모든 문제 발생 가능
- **Read Committed**: Dirty Read 방지
- **Repeatable Read**: Dirty Read, Non-Repeatable Read 방지
- **Serializable**: 모든 문제 방지 (가장 높은 격리 수준, 성능 저하 가능)

### Transaction의 필요성

여러 개의 데이터베이스 작업을 하나의 트랜잭션으로 묶으면:

1. **원자성 보장**: 모든 작업이 성공하거나 모두 실패
2. **데이터 일관성**: 중간 상태의 데이터가 노출되지 않음
3. **에러 처리**: 에러 발생 시 자동으로 롤백

**예시**: 영화 생성 시
- MovieDetail 생성
- Movie 생성
- Movie-Genre 관계 설정

이 세 작업 중 하나라도 실패하면 모든 작업이 롤백되어야 합니다.

---

## Create 함수에서 Transaction 적용하기

### 1. DataSource 주입

**파일**: `src/movie/movie.service.ts`

```typescript
import { DataSource } from 'typeorm';

@Injectable()
export class MovieService {
  constructor(
    @InjectRepository(Movie)
    private readonly movieRepository: Repository<Movie>,
    @InjectRepository(MovieDetail)
    private readonly movieDetailRepository: Repository<MovieDetail>,
    @InjectRepository(Director)
    private readonly directorRepository: Repository<Director>,
    @InjectRepository(Genre)
    private readonly genreRepository: Repository<Genre>,
    private readonly dataSource: DataSource,  // DataSource 주입
  ) {}
}
```

**설명**:
- `DataSource`: TypeORM의 데이터베이스 연결을 관리하는 객체
- QueryRunner를 생성하기 위해 필요합니다.

### 2. QueryRunner를 사용한 Transaction 구현

**파일**: `src/movie/movie.service.ts`

#### 기존 방식 (Transaction 없음)

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  const director = await this.directorRepository.findOne({
    where: { id: CreateMovieDto.directorId },
  });

  const genres = await this.genreRepository.find({
    where: { id: In(CreateMovieDto.genreIds) },
  });

  const movieDetail = await this.movieDetailRepository
    .createQueryBuilder()
    .insert()
    .into(MovieDetail)
    .values({ detail: CreateMovieDto.detail })
    .execute();

  const movie = await this.movieRepository
    .createQueryBuilder()
    .insert()
    .into(Movie)
    .values({ ... })
    .execute();

  await this.movieRepository
    .createQueryBuilder()
    .relation(Movie, 'genres')
    .of(movieId)
    .add(genres.map((genre) => genre.id));

  return movie;
}
```

**문제점**:
- 중간에 에러가 발생하면 일부 작업만 완료된 상태로 남을 수 있습니다.
- 예: MovieDetail은 생성되었지만 Movie 생성 실패 시 데이터 불일치

#### Transaction 적용 방식

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  // 1. QueryRunner 생성 및 연결
  const qr = this.dataSource.createQueryRunner();
  await qr.connect();
  await qr.startTransaction();

  try {
    // 2. Transaction 내에서 모든 작업 수행
    const director = await qr.manager.findOne(Director, {
      where: { id: CreateMovieDto.directorId },
    });

    if (!director) {
      throw new NotFoundException(
        `Director with ID ${CreateMovieDto.directorId} not found`,
      );
    }

    const genres = await qr.manager.find(Genre, {
      where: { id: In(CreateMovieDto.genreIds) },
    });

    if (genres.length !== CreateMovieDto.genreIds.length) {
      throw new NotFoundException(
        `존재하지 않는 장르가 있습니다. 존재하는 장르: ${genres.map((genre) => genre.id).join(', ')}`,
      );
    }

    // MovieDetail 생성
    const movieDetail = await qr.manager
      .createQueryBuilder()
      .insert()
      .into(MovieDetail)
      .values({
        detail: CreateMovieDto.detail,
      })
      .execute();

    const movieDetailId = movieDetail.identifiers[0].id;

    // Movie 생성
    const movie = await qr.manager
      .createQueryBuilder()
      .insert()
      .into(Movie)
      .values({
        title: CreateMovieDto.title,
        detail: {
          id: movieDetailId,
        },
        director: director,
      })
      .execute();

    const movieId = movie.identifiers[0].id;

    // Many-to-Many 관계 설정
    await qr.manager
      .createQueryBuilder()
      .relation(Movie, 'genres')
      .of(movieId)
      .add(genres.map((genre) => genre.id));

    // 3. 모든 작업 성공 시 커밋
    await qr.commitTransaction();

    // 4. 최종 결과 반환
    return this.movieRepository.findOne({
      where: { id: movieId },
      relations: ['detail', 'director', 'genres'],
    });
  } catch (e) {
    // 5. 에러 발생 시 롤백
    await qr.rollbackTransaction();
    throw e;
  } finally {
    // 6. QueryRunner 해제
    await qr.release();
  }
}
```

**설명**:

1. **QueryRunner 생성 및 연결**:
   ```typescript
   const qr = this.dataSource.createQueryRunner();
   await qr.connect();
   await qr.startTransaction();
   ```
   - `createQueryRunner()`: 새로운 QueryRunner 인스턴스 생성
   - `connect()`: 데이터베이스 연결
   - `startTransaction()`: 트랜잭션 시작

2. **Transaction 내에서 작업 수행**:
   - `qr.manager`: QueryRunner의 EntityManager 사용
   - 모든 데이터베이스 작업을 `qr.manager`를 통해 수행
   - `qr.manager.findOne()`, `qr.manager.find()`, `qr.manager.createQueryBuilder()` 등

3. **커밋**:
   ```typescript
   await qr.commitTransaction();
   ```
   - 모든 작업이 성공하면 커밋하여 변경사항을 영구 저장

4. **롤백**:
   ```typescript
   catch (e) {
     await qr.rollbackTransaction();
     throw e;
   }
   ```
   - 에러 발생 시 롤백하여 모든 변경사항 취소
   - 에러를 다시 throw하여 상위로 전파

5. **QueryRunner 해제**:
   ```typescript
   finally {
     await qr.release();
   }
   ```
   - 성공/실패와 관계없이 QueryRunner 리소스 해제

### 3. QueryRunner의 장점

1. **명시적 제어**: 트랜잭션의 시작과 종료를 명확하게 제어
2. **에러 처리**: try-catch-finally로 안전한 에러 처리
3. **복잡한 로직**: 여러 단계의 작업을 하나의 트랜잭션으로 묶을 수 있음

---

## Update 함수 Transaction 적용하기

### Update 메서드에 Transaction 적용

**파일**: `src/movie/movie.service.ts`

#### 기존 방식 (Transaction 없음)

```typescript
async update(id: number, UpdateMovieDto: UpdateMovieDto) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'genres'],
  });

  // ... 검증 로직

  await this.movieRepository
    .createQueryBuilder()
    .update(Movie)
    .set(movieUpdateFields)
    .where('id = :id', { id })
    .execute();

  if (detail) {
    await this.movieDetailRepository
      .createQueryBuilder()
      .update(MovieDetail)
      .set({ detail })
      .where('id = :id', { id: movie.detail.id })
      .execute();
  }

  if (newGenres) {
    await this.movieRepository
      .createQueryBuilder()
      .relation(Movie, 'genres')
      .of(id)
      .addAndRemove(...);
  }

  return this.movieRepository.findOne({ ... });
}
```

**문제점**:
- Movie 업데이트는 성공했지만 MovieDetail 업데이트 실패 시 데이터 불일치
- Genre 관계 업데이트 실패 시 부분적으로만 업데이트됨

#### Transaction 적용 방식

```typescript
async update(id: number, UpdateMovieDto: UpdateMovieDto) {
  // 1. QueryRunner 생성 및 연결
  const qr = this.dataSource.createQueryRunner();
  await qr.connect();
  await qr.startTransaction();

  try {
    // 2. Transaction 내에서 모든 작업 수행
    const movie = await qr.manager.findOne(Movie, {
      where: { id },
      relations: ['detail', 'genres'],
    });

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${id} not found`);
    }

    const { detail, directorId, genreIds, ...movieRest } = UpdateMovieDto;

    // Director 조회
    let newDirector;
    if (directorId) {
      const director = await qr.manager.findOne(Director, {
        where: { id: directorId },
      });

      if (!director) {
        throw new NotFoundException(
          `Director with ID ${directorId} not found`,
        );
      }

      newDirector = director;
    }

    // Genre 조회
    let newGenres;
    if (genreIds) {
      const genres = await qr.manager.find(Genre, {
        where: { id: In(genreIds) },
      });

      if (genres.length !== genreIds.length) {
        throw new NotFoundException(
          `존재하지 않는 장르가 있습니다. 존재하는 장르: ${genres.map((genre) => genre.id).join(', ')}`,
        );
      }

      newGenres = genres;
    }

    const movieUpdateFields = {
      ...movieRest,
      ...(newDirector && { director: newDirector }),
    };

    // Movie 업데이트
    await qr.manager
      .createQueryBuilder()
      .update(Movie)
      .set(movieUpdateFields)
      .where('id = :id', { id })
      .execute();

    // MovieDetail 업데이트
    if (detail) {
      await qr.manager
        .createQueryBuilder()
        .update(MovieDetail)
        .set({ detail })
        .where('id = :id', { id: movie.detail.id })
        .execute();
    }

    // Many-to-Many 관계 업데이트
    if (newGenres) {
      await qr.manager
        .createQueryBuilder()
        .relation(Movie, 'genres')
        .of(id)
        .addAndRemove(
          newGenres.map((genre) => genre.id),
          movie.genres.map((genre) => genre.id),
        );
    }

    // 3. 모든 작업 성공 시 커밋
    await qr.commitTransaction();

    // 4. 최종 결과 반환
    return this.movieRepository.findOne({
      where: { id },
      relations: ['detail', 'director', 'genres'],
    });
  } catch (e) {
    // 5. 에러 발생 시 롤백
    await qr.rollbackTransaction();
    throw e;
  } finally {
    // 6. QueryRunner 해제
    await qr.release();
  }
}
```

**설명**:
- Create 메서드와 동일한 패턴으로 Transaction 적용
- Movie, MovieDetail, Genre 관계 업데이트를 하나의 트랜잭션으로 묶음
- 에러 발생 시 모든 변경사항이 롤백됨

---

## QueryRunner 주요 메서드

### QueryRunner 생성 및 관리

| 메서드 | 설명 | 반환 타입 |
|--------|------|-----------|
| `createQueryRunner()` | QueryRunner 인스턴스 생성 | `QueryRunner` |
| `connect()` | 데이터베이스 연결 | `Promise<void>` |
| `startTransaction()` | 트랜잭션 시작 | `Promise<void>` |
| `commitTransaction()` | 트랜잭션 커밋 | `Promise<void>` |
| `rollbackTransaction()` | 트랜잭션 롤백 | `Promise<void>` |
| `release()` | QueryRunner 리소스 해제 | `Promise<void>` |

### EntityManager 사용

QueryRunner의 `manager` 속성을 통해 EntityManager에 접근합니다.

```typescript
qr.manager.findOne(Entity, options)
qr.manager.find(Entity, options)
qr.manager.createQueryBuilder()
qr.manager.save(entity)
qr.manager.remove(entity)
```

**주의사항**:
- Transaction 내에서 작업하려면 반드시 `qr.manager`를 사용해야 합니다.
- 일반 `repository`를 사용하면 Transaction 밖에서 실행됩니다.

---

## Transaction 패턴 정리

### 표준 Transaction 패턴

```typescript
async method() {
  // 1. QueryRunner 생성 및 연결
  const qr = this.dataSource.createQueryRunner();
  await qr.connect();
  await qr.startTransaction();

  try {
    // 2. Transaction 내에서 작업 수행
    // qr.manager를 사용하여 모든 데이터베이스 작업 수행
    
    // 3. 커밋
    await qr.commitTransaction();
    
    // 4. 결과 반환
    return result;
  } catch (e) {
    // 5. 롤백
    await qr.rollbackTransaction();
    throw e;
  } finally {
    // 6. 리소스 해제
    await qr.release();
  }
}
```

### 주의사항

1. **항상 finally에서 release() 호출**: 리소스 누수 방지
2. **에러는 다시 throw**: 상위로 에러 전파
3. **qr.manager 사용**: Transaction 내에서 작업하려면 반드시 `qr.manager` 사용
4. **중첩 Transaction**: TypeORM은 중첩 Transaction을 지원하지 않음

---

## 프로젝트 파일 구조

```
src/
└── movie/
    └── movie.service.ts
        ├── constructor
        │   └── dataSource: DataSource 주입
        ├── create()          # QueryRunner Transaction 적용
        └── update()           # QueryRunner Transaction 적용
```

---

## 핵심 개념 정리

### 1. Transaction의 필요성

- 여러 데이터베이스 작업을 하나의 논리적 단위로 묶음
- 원자성 보장: 모두 성공하거나 모두 실패
- 데이터 일관성 유지

### 2. Transaction Anomalies

- **Lost Update**: 두 트랜잭션이 같은 데이터를 업데이트하여 하나가 손실
- **Dirty Reads**: 커밋되지 않은 값을 읽음
- **Non-repeatable Reads**: 같은 데이터를 두 번 읽었을 때 다른 결과
- **Phantom Reads**: 쿼리 결과에 새로운 행이 나타남

### 3. Transaction Isolation Level

- **Read Uncommitted**: 모든 문제 발생 가능
- **Read Committed**: Dirty Read 방지
- **Repeatable Read**: Dirty Read, Non-repeatable Read 방지
- **Serializable**: 모든 문제 방지

### 4. QueryRunner 사용

- `createQueryRunner()`: QueryRunner 생성
- `connect()`, `startTransaction()`: 트랜잭션 시작
- `qr.manager`: Transaction 내에서 작업 수행
- `commitTransaction()`: 커밋
- `rollbackTransaction()`: 롤백
- `release()`: 리소스 해제

### 5. Transaction 패턴

- try-catch-finally 구조 사용
- 에러 발생 시 롤백 후 에러 재throw
- finally에서 항상 release() 호출

---

## 참고사항

1. **DataSource 주입**: QueryRunner를 생성하기 위해 DataSource를 주입받아야 합니다.
2. **qr.manager 사용**: Transaction 내에서 작업하려면 반드시 `qr.manager`를 사용해야 합니다.
3. **에러 처리**: Transaction 내에서 에러가 발생하면 자동으로 롤백되도록 catch 블록에서 처리합니다.
4. **리소스 관리**: finally 블록에서 항상 `qr.release()`를 호출하여 리소스를 해제합니다.
5. **성능 고려**: Transaction은 데이터베이스 락을 사용하므로 불필요하게 긴 Transaction은 피해야 합니다.
