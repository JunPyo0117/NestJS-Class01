# Database Migration

## 목차
1. [Migration이란?](#migration이란)
2. [Migration이 필요한 이유](#migration이-필요한-이유)
3. [Migration 파일의 동작 방식](#migration-파일의-동작-방식)
4. [Migration Configuration](#migration-configuration)
5. [Migration 작성 방법](#migration-작성-방법)
6. [Migration CLI 커맨드](#migration-cli-커맨드)

---

## Migration이란?

### Migration의 정의

**Migration(마이그레이션)**은 데이터베이스 변경사항을 스크립트로 작성해서 반영하는 방법입니다. 통제된 상황에서 데이터베이스 스키마 변경 및 복구를 진행할 수 있습니다.

### Migration의 특징

1. **스크립트 기반**: 데이터베이스 변경사항을 코드로 작성
2. **버전 관리**: Git과 같은 버전 관리 시스템으로 추적 가능
3. **반복 가능**: 동일한 변경사항을 여러 환경에 적용 가능
4. **되돌리기 가능**: 변경사항을 쉽게 롤백할 수 있음

---

## Migration이 필요한 이유

### 왜 sync 옵션으로는 부족한가?

TypeORM의 `synchronize: true` 옵션은 개발 환경에서는 편리하지만, 프로덕션 환경에서는 사용하지 않는 것이 좋습니다. Migration을 사용해야 하는 이유는 다음과 같습니다.

#### 1. Controlled Changes (제어된 변경)

**설명**: 원하는 상황에 원하는 형태로 마이그레이션을 자유롭게 실행할 수 있습니다.

**장점**:
- 언제 마이그레이션을 실행할지 결정할 수 있습니다.
- 배포 전에 마이그레이션을 검토하고 테스트할 수 있습니다.
- 여러 마이그레이션을 순차적으로 실행할 수 있습니다.

#### 2. Reversible (되돌리기 가능)

**설명**: 진행한 마이그레이션을 쉽게 되돌릴 수 있습니다.

**장점**:
- 문제가 발생하면 마이그레이션을 롤백할 수 있습니다.
- `down` 메서드를 통해 정확히 이전 상태로 복구 가능합니다.
- 실수로 잘못된 변경을 적용해도 안전하게 되돌릴 수 있습니다.

#### 3. Versioning (버전 관리)

**설명**: 마이그레이션은 스키마 변경에 대한 히스토리를 담고 있습니다. 디버깅에 매우 유용합니다.

**장점**:
- 데이터베이스 스키마의 변경 이력을 추적할 수 있습니다.
- 언제 어떤 변경이 이루어졌는지 확인 가능합니다.
- 문제 발생 시 특정 시점으로 되돌릴 수 있습니다.
- Git과 함께 사용하면 코드와 스키마 변경을 함께 관리할 수 있습니다.

#### 4. Consistency (일관성)

**설명**: 다양한 환경에서 데이터베이스 스키마가 같게 유지되도록 할 수 있습니다.

**장점**:
- 개발, 스테이징, 프로덕션 환경의 스키마를 동일하게 유지할 수 있습니다.
- 팀원들 간에 동일한 데이터베이스 스키마를 공유할 수 있습니다.
- 새로운 개발자가 프로젝트에 합류해도 동일한 스키마를 쉽게 구축할 수 있습니다.

#### 5. Complex Changes (복잡한 변경)

**설명**: 복잡한 데이터베이스의 변화를 직접 컨트롤할 수 있습니다.

**장점**:
- 데이터 마이그레이션과 함께 스키마 변경을 수행할 수 있습니다.
- 복잡한 인덱스, 제약 조건, 트리거 등을 정확하게 제어할 수 있습니다.
- 성능 최적화를 위한 세밀한 조정이 가능합니다.

---

## Migration 파일의 동작 방식

### Migration 파일의 순차적 적용

Migration 파일들은 타임스탬프를 포함한 이름으로 생성되며, 순차적으로 적용됩니다.

```
Migration 1
Migration 2  ← Database 1에 적용됨
Migration 3
Migration 4
Migration 5
Migration 6
```

**설명**:
- 각 데이터베이스는 어느 마이그레이션까지 적용되었는지 추적합니다.
- 예: Database 1은 Migration 2까지 적용됨
- 예: Database 2는 Migration 4까지 적용됨
- 새로운 마이그레이션을 실행하면 아직 적용되지 않은 마이그레이션만 실행됩니다.

### Migration 적용 과정

1. **마이그레이션 파일 생성**: 타임스탬프가 포함된 파일명으로 생성
2. **마이그레이션 실행**: `migration:run` 명령으로 실행
3. **적용 상태 추적**: TypeORM이 적용된 마이그레이션을 추적
4. **되돌리기**: `migration:revert` 명령으로 마지막 마이그레이션 롤백

---

## Migration Configuration

### ormconfig.json 설정

TypeORM에서 Migration을 사용하려면 `ormconfig.json` 파일에 Migration 관련 설정을 추가해야 합니다.

```json
{
  "type": "postgres",
  "host": "localhost",
  "port": 5432,
  "username": "test",
  "password": "test",
  "database": "test",
  "entities": ["src/entity/**/*.ts"],
  "migrations": ["src/migration/**/*.ts"],
  "cli": {
    "entitiesDir": "src/entity",
    "migrationsDir": "src/migration"
  }
}
```

**설명**:
- `"migrations": ["src/migration/**/*.ts"]`: 마이그레이션 파일이 위치한 경로 지정
- `"cli.migrationsDir": "src/migration"`: CLI로 마이그레이션 생성 시 저장될 디렉토리 지정

---

## Migration 작성 방법

### Migration 인터페이스

모든 Migration 클래스는 `MigrationInterface`를 구현해야 합니다.

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class MigrationName1234567890123 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // 마이그레이션 적용 시 실행되는 코드
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // 마이그레이션 롤백 시 실행되는 코드
  }
}
```

**설명**:
- `up()`: 마이그레이션을 적용할 때 실행되는 메서드
- `down()`: 마이그레이션을 롤백할 때 실행되는 메서드
- `QueryRunner`: 데이터베이스 쿼리를 실행하는 객체

### 1. 테이블 생성

#### RAW SQL 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateMovieAndDirectorTables1634567890123 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "director" (
        "id" SERIAL NOT NULL,
        "name" VARCHAR NOT NULL,
        "dob" DATE,
        "nationality" VARCHAR,
        PRIMARY KEY ("id")
      )
    `);

    await queryRunner.query(`
      CREATE TABLE "movie" (
        "id" SERIAL NOT NULL,
        "title" VARCHAR NOT NULL,
        "genre" VARCHAR,
        "directorId" INTEGER,
        PRIMARY KEY ("id"),
        FOREIGN KEY ("directorId") REFERENCES "director" ("id") ON DELETE SET NULL
      )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "movie"`);
    await queryRunner.query(`DROP TABLE "director"`);
  }
}
```

#### Migration API 방식

```typescript
import { MigrationInterface, QueryRunner, Table, TableForeignKey } from "typeorm";

export class CreateMovieAndDirectorTables1634567890123 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: "movie",
        columns: [
          {
            name: "id",
            type: "int",
            isPrimary: true,
            isGenerated: true,
            generationStrategy: "increment",
          },
          {
            name: "title",
            type: "varchar",
          },
          {
            name: "genre",
            type: "varchar",
            isNullable: true,
          },
          {
            name: "directorId",
            type: "int",
            isNullable: true,
          },
        ],
      }),
      true
    );

    await queryRunner.createForeignKey(
      "movie",
      new TableForeignKey({
        columnNames: ["directorId"],
        referencedColumnNames: ["id"],
        referencedTableName: "director",
        onDelete: "SET NULL",
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable("movie");
    await queryRunner.dropTable("director");
  }
}
```

**설명**:
- **RAW SQL**: 직접 SQL 문을 작성하여 실행
- **Migration API**: TypeORM의 API를 사용하여 테이블 생성
- `createTable()`: 테이블 생성
- `createForeignKey()`: 외래 키 생성
- `dropTable()`: 테이블 삭제

### 2. 칼럼 추가

#### RAW SQL 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDateOfBirthToDirector1634567890124 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      ADD "dateOfBirth" DATE
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      DROP COLUMN "dateOfBirth"
    `);
  }
}
```

#### Migration API 방식

```typescript
import { MigrationInterface, QueryRunner, TableColumn } from "typeorm";

export class AddDateOfBirthToDirector1634567890124 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      "director",
      new TableColumn({
        name: "dateOfBirth",
        type: "date",
        isNullable: true,
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn("director", "dateOfBirth");
  }
}
```

**설명**:
- `addColumn()`: 칼럼 추가
- `dropColumn()`: 칼럼 삭제
- `TableColumn`: 칼럼 정의 객체

### 3. 칼럼 이름 변경

#### RAW SQL 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class RenameNameToFullNameInDirector1634567890125 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      RENAME COLUMN "name" TO "fullName"
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      RENAME COLUMN "fullName" TO "name"
    `);
  }
}
```

#### Migration API 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class RenameNameToFullNameInDirector1634567890125 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.renameColumn("director", "name", "fullName");
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.renameColumn("director", "fullName", "name");
  }
}
```

**설명**:
- `renameColumn()`: 칼럼 이름 변경
- `renameColumn(tableName, oldColumnName, newColumnName)`

### 4. 칼럼 타입 변경

#### RAW SQL 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class ChangeEmailTypeInDirector1634567890126 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      ALTER COLUMN "email" TYPE TEXT
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "director"
      ALTER COLUMN "email" TYPE VARCHAR
    `);
  }
}
```

#### Migration API 방식

```typescript
import { MigrationInterface, QueryRunner, TableColumn } from "typeorm";

export class ChangeEmailTypeInDirector1634567890126 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      "director",
      "email",
      new TableColumn({
        name: "email",
        type: "text",
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      "director",
      "email",
      new TableColumn({
        name: "email",
        type: "varchar",
      })
    );
  }
}
```

**설명**:
- `changeColumn()`: 칼럼 타입 변경
- `changeColumn(tableName, columnName, newColumnDefinition)`

### 5. Relationship 작업 (Many-to-Many)

#### RAW SQL 방식

```typescript
import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateGenreAndMovieGenreTables1634567890127 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "genre" (
        "id" SERIAL NOT NULL,
        "name" VARCHAR NOT NULL,
        PRIMARY KEY ("id")
      )
    `);

    await queryRunner.query(`
      CREATE TABLE "movie_genres_genre" (
        "movieId" INTEGER NOT NULL,
        "genreId" INTEGER NOT NULL,
        PRIMARY KEY ("movieId", "genreId"),
        FOREIGN KEY ("movieId") REFERENCES "movie" ("id") ON DELETE CASCADE,
        FOREIGN KEY ("genreId") REFERENCES "genre" ("id") ON DELETE CASCADE
      )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "movie_genres_genre"`);
    await queryRunner.query(`DROP TABLE "genre"`);
  }
}
```

#### Migration API 방식

```typescript
import { MigrationInterface, QueryRunner, Table, TableForeignKey } from "typeorm";

export class CreateGenreAndMovieGenreTables1634567890127 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: "genre",
        columns: [
          {
            name: "id",
            type: "int",
            isPrimary: true,
            isGenerated: true,
            generationStrategy: "increment",
          },
          {
            name: "name",
            type: "varchar",
          },
        ],
      }),
      true
    );

    await queryRunner.createTable(
      new Table({
        name: "movie_genres_genre",
        columns: [
          {
            name: "movieId",
            type: "int",
          },
          {
            name: "genreId",
            type: "int",
          },
        ],
      }),
      true
    );

    await queryRunner.createForeignKey(
      "movie_genres_genre",
      new TableForeignKey({
        columnNames: ["movieId"],
        referencedColumnNames: ["id"],
        referencedTableName: "movie",
        onDelete: "CASCADE",
      })
    );

    await queryRunner.createForeignKey(
      "movie_genres_genre",
      new TableForeignKey({
        columnNames: ["genreId"],
        referencedColumnNames: ["id"],
        referencedTableName: "genre",
        onDelete: "CASCADE",
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable("movie_genres_genre");
    await queryRunner.dropTable("genre");
  }
}
```

**설명**:
- Many-to-Many 관계는 중간 테이블(Join Table)이 필요합니다.
- 중간 테이블에 두 개의 외래 키를 생성합니다.
- `onDelete: "CASCADE"`: 참조된 레코드가 삭제되면 관련 레코드도 함께 삭제

---

## Migration CLI 커맨드

### Migration 파일 생성하기

```bash
npx typeorm migration:generate -n <MigrationName>
```

**설명**:
- 엔티티 변경사항을 기반으로 마이그레이션 파일을 자동 생성합니다.
- `<MigrationName>`: 마이그레이션 이름 (예: `CreateMovieTable`)
- 타임스탬프가 자동으로 파일명에 포함됩니다.
- 예: `1634567890123-CreateMovieTable.ts`

**예시**:
```bash
npx typeorm migration:generate -n CreateMovieTable
```

### Migration 실행하기

```bash
npx typeorm migration:run
```

**설명**:
- 아직 적용되지 않은 모든 마이그레이션을 실행합니다.
- 마이그레이션은 순차적으로 실행됩니다.
- 각 마이그레이션의 `up()` 메서드가 실행됩니다.

### Migration 되돌리기

```bash
npx typeorm migration:revert
```

**설명**:
- 마지막으로 적용된 마이그레이션을 롤백합니다.
- 해당 마이그레이션의 `down()` 메서드가 실행됩니다.
- 여러 번 실행하면 이전 마이그레이션들도 순차적으로 롤백됩니다.

### Migration 상태 확인

```bash
npx typeorm migration:show
```

**설명**:
- 적용된 마이그레이션과 대기 중인 마이그레이션을 표시합니다.
- 데이터베이스의 마이그레이션 상태를 확인할 수 있습니다.

---

## RAW SQL vs Migration API

### RAW SQL 방식

**장점**:
- 모든 SQL 기능을 사용할 수 있습니다.
- 복잡한 쿼리를 직접 제어할 수 있습니다.
- 데이터베이스별 특수 기능을 활용할 수 있습니다.

**단점**:
- 데이터베이스별로 다른 SQL 문법을 사용해야 할 수 있습니다.
- 타입 안정성이 낮습니다.

**사용 시기**:
- 복잡한 데이터 마이그레이션이 필요한 경우
- 데이터베이스별 특수 기능이 필요한 경우

### Migration API 방식

**장점**:
- 데이터베이스에 독립적인 코드 작성 가능
- 타입 안정성 제공
- TypeORM이 데이터베이스별 SQL로 변환

**단점**:
- 모든 기능을 지원하지 않을 수 있습니다.
- 복잡한 쿼리는 제한적일 수 있습니다.

**사용 시기**:
- 간단한 스키마 변경
- 데이터베이스 독립적인 코드가 필요한 경우

---

## Migration 작성 시 주의사항

### 1. up()과 down() 메서드

- `up()`: 마이그레이션 적용 시 실행
- `down()`: 마이그레이션 롤백 시 실행
- `down()`은 `up()`의 정확한 역순으로 작성해야 합니다.

### 2. 데이터 마이그레이션

스키마 변경뿐만 아니라 데이터 마이그레이션도 함께 수행할 수 있습니다.

```typescript
public async up(queryRunner: QueryRunner): Promise<void> {
  // 스키마 변경
  await queryRunner.addColumn("user", new TableColumn({
    name: "email",
    type: "varchar",
  }));

  // 데이터 마이그레이션
  await queryRunner.query(`
    UPDATE "user"
    SET "email" = "username" || '@example.com'
    WHERE "email" IS NULL
  `);
}
```

### 3. 외래 키 순서

테이블을 생성할 때는 외래 키가 참조하는 테이블을 먼저 생성해야 합니다.

```typescript
// ✅ 올바른 순서
await queryRunner.createTable("director", ...);
await queryRunner.createTable("movie", ...);
await queryRunner.createForeignKey("movie", ...);

// ❌ 잘못된 순서
await queryRunner.createTable("movie", ...);  // director가 없어서 실패
await queryRunner.createTable("director", ...);
```

### 4. 롤백 순서

`down()` 메서드에서는 생성 순서의 역순으로 삭제해야 합니다.

```typescript
public async down(queryRunner: QueryRunner): Promise<void> {
  // 외래 키가 있는 테이블을 먼저 삭제
  await queryRunner.dropTable("movie");
  await queryRunner.dropTable("director");
}
```

---

## Migration 파일 구조

### 파일명 규칙

```
<Timestamp>-<MigrationName>.ts
```

**예시**:
- `1634567890123-CreateMovieTable.ts`
- `1634567890124-AddDateOfBirthToDirector.ts`

**설명**:
- 타임스탬프는 마이그레이션 실행 순서를 결정합니다.
- 타임스탬프가 작을수록 먼저 실행됩니다.

### 디렉토리 구조

```
src/
└── migration/
    ├── 1634567890123-CreateMovieTable.ts
    ├── 1634567890124-AddDateOfBirthToDirector.ts
    └── 1634567890125-RenameNameToFullName.ts
```

---

## 핵심 개념 정리

### 1. Migration의 필요성

- **제어된 변경**: 원하는 시점에 마이그레이션 실행
- **되돌리기 가능**: 롤백 기능 제공
- **버전 관리**: 스키마 변경 이력 추적
- **일관성**: 다양한 환경에서 동일한 스키마 유지
- **복잡한 변경**: 세밀한 제어 가능

### 2. Migration 작성 방법

- **RAW SQL**: 직접 SQL 문 작성
- **Migration API**: TypeORM API 사용
- **up()**: 마이그레이션 적용
- **down()**: 마이그레이션 롤백

### 3. Migration CLI

- `migration:generate`: 마이그레이션 파일 생성
- `migration:run`: 마이그레이션 실행
- `migration:revert`: 마이그레이션 롤백
- `migration:show`: 마이그레이션 상태 확인

### 4. 주의사항

- `up()`과 `down()`의 정확한 역순 관계
- 외래 키가 있는 테이블의 생성/삭제 순서
- 데이터 마이그레이션과 스키마 변경의 조합

---

## 참고사항

1. **synchronize 옵션**: 프로덕션 환경에서는 `synchronize: false`로 설정하고 Migration을 사용해야 합니다.
2. **마이그레이션 파일 관리**: Git으로 버전 관리하여 팀원들과 공유합니다.
3. **테스트**: 마이그레이션을 적용하기 전에 개발 환경에서 테스트합니다.
4. **백업**: 프로덕션 환경에서 마이그레이션을 실행하기 전에 데이터베이스를 백업합니다.
5. **문서화**: 복잡한 마이그레이션은 주석으로 설명을 추가합니다.

---

## 참고 자료

- [TypeORM Migration 공식 문서](https://typeorm.io/migrations)
