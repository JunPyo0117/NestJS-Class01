# Pipe

## 목차
1. [Pipe 소개](#pipe-소개)
2. [기본 Pipe 사용해보기](#기본-pipe-사용해보기)
3. [프로젝트에 Pipe 적용하기](#프로젝트에-pipe-적용하기)
4. [Custom Validation Pipe](#custom-validation-pipe)
5. [MovieTitleValidationPipe 버그 수정](#movietitlevalidationpipe-버그-수정)

---

## Pipe 소개

### Pipe란?

**Pipe(파이프)**는 NestJS에서 요청 데이터를 변환(transform)하거나 검증(validate)하는 데 사용되는 클래스입니다.

### Pipe의 역할

1. **변환(Transformation)**: 입력 데이터를 원하는 형태로 변환
   - 예: 문자열을 숫자로 변환 (`"123"` → `123`)
   - 예: 문자열을 대문자로 변환 (`"hello"` → `"HELLO"`)

2. **검증(Validation)**: 입력 데이터가 유효한지 검증
   - 예: 숫자 여부 확인
   - 예: 문자열 길이 확인
   - 예: 이메일 형식 확인

### Pipe의 실행 시점

Pipe는 **라우트 핸들러가 실행되기 전**에 실행됩니다.

```
요청 → Pipe (변환/검증) → 라우트 핸들러 → 응답
```

### Pipe의 위치

Pipe는 다음 위치에서 사용할 수 있습니다:

1. **파라미터 레벨**: `@Param()`, `@Query()`, `@Body()` 데코레이터와 함께 사용
2. **메서드 레벨**: `@UsePipes()` 데코레이터로 메서드에 적용
3. **컨트롤러 레벨**: `@UsePipes()` 데코레이터로 컨트롤러에 적용
4. **전역 레벨**: `app.useGlobalPipes()`로 전체 애플리케이션에 적용

---

## 기본 Pipe 사용해보기

### NestJS 내장 Pipe

NestJS는 여러 내장 Pipe를 제공합니다:

#### 1. ParseIntPipe

문자열을 정수로 변환합니다.

**사용 예시**:

```typescript
import { ParseIntPipe } from '@nestjs/common';

@Get(':id')
getMovie(@Param('id', ParseIntPipe) id: number) {
  return this.movieService.findOne(id);
}
```

**설명**:
- `@Param('id', ParseIntPipe)`: URL 파라미터 `id`를 정수로 변환
- 변환 실패 시 자동으로 `BadRequestException` 발생
- `id`의 타입이 `number`로 자동 추론됨

**동작**:
- 입력: `"123"` (문자열)
- 출력: `123` (숫자)
- 변환 실패: `"abc"` → `BadRequestException`

#### 2. ParseFloatPipe

문자열을 부동소수점 숫자로 변환합니다.

```typescript
@Get(':price')
getPrice(@Param('price', ParseFloatPipe) price: number) {
  return price;
}
```

#### 3. ParseBoolPipe

문자열을 불리언으로 변환합니다.

```typescript
@Get(':active')
getActive(@Query('active', ParseBoolPipe) active: boolean) {
  return active;
}
```

#### 4. ParseUUIDPipe

문자열이 유효한 UUID인지 검증합니다.

```typescript
@Get(':uuid')
getUser(@Param('uuid', ParseUUIDPipe) uuid: string) {
  return this.userService.findOne(uuid);
}
```

#### 5. ParseEnumPipe

문자열이 특정 enum 값인지 검증합니다.

```typescript
enum Status {
  Active = 'active',
  Inactive = 'inactive',
}

@Get(':status')
getStatus(@Param('status', new ParseEnumPipe(Status)) status: Status) {
  return status;
}
```

#### 6. DefaultValuePipe

값이 없을 때 기본값을 제공합니다.

```typescript
@Get()
getMovies(@Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number) {
  return this.movieService.findAll(page);
}
```

**설명**:
- `page` 쿼리 파라미터가 없으면 기본값 `1` 사용
- 여러 Pipe를 체이닝하여 사용 가능

### Pipe 체이닝

여러 Pipe를 순차적으로 적용할 수 있습니다.

```typescript
@Get(':id')
getMovie(
  @Param('id', new DefaultValuePipe('1'), ParseIntPipe) id: number
) {
  return this.movieService.findOne(id);
}
```

**실행 순서**:
1. `DefaultValuePipe`: 값이 없으면 `'1'` 반환
2. `ParseIntPipe`: 문자열을 숫자로 변환

---

## 프로젝트에 Pipe 적용하기

### 1. ParseIntPipe 적용

**파일**: `src/movie/movie.controller.ts`

```typescript
import { ParseIntPipe } from '@nestjs/common';

@Controller('movie')
export class MovieController {
  @Get(':id')
  getMovie(
    @Param('id', ParseIntPipe)
    id: number,
  ) {
    return this.movieService.findOne(id);
  }

  @Patch(':id')
  updateMovie(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: UpdateMovieDto,
  ) {
    return this.movieService.update(id, body);
  }

  @Delete(':id')
  deleteMovie(@Param('id', ParseIntPipe) id: number) {
    return this.movieService.remove(id);
  }
}
```

**설명**:
- `@Param('id', ParseIntPipe)`: URL 파라미터를 정수로 변환
- 변환 실패 시 자동으로 `400 Bad Request` 에러 발생
- `id` 타입이 `number`로 자동 추론되어 `+id` 같은 수동 변환 불필요

**장점**:
- 타입 안정성: `id`가 항상 `number` 타입
- 에러 처리: 잘못된 입력 시 자동으로 에러 응답
- 코드 간결성: 수동 변환 코드 제거

### 2. ValidationPipe 전역 설정

**파일**: `src/main.ts`

```typescript
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
  );
  
  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
```

**설명**:
- `app.useGlobalPipes()`: 전체 애플리케이션에 Pipe 적용
- `ValidationPipe`: DTO의 `class-validator` 데코레이터를 기반으로 검증
- `whitelist: true`: DTO에 정의되지 않은 속성 제거
- `forbidNonWhitelisted: true`: DTO에 정의되지 않은 속성이 있으면 에러 발생

**동작**:
- 모든 요청의 `@Body()` 데이터가 DTO로 검증됨
- `@IsNotEmpty()`, `@IsString()` 등의 데코레이터가 자동으로 검증됨

### 3. 다른 컨트롤러에도 ParseIntPipe 적용

**파일**: `src/director/director.controller.ts`

```typescript
import { ParseIntPipe } from '@nestjs/common';

@Controller('director')
export class DirectorController {
  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.directorService.findOne(id);
  }

  @Patch(':id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateDirectorDto: UpdateDirectorDto,
  ) {
    return this.directorService.update(id, updateDirectorDto);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.directorService.remove(id);
  }
}
```

**파일**: `src/genre/genre.controller.ts`

```typescript
import { ParseIntPipe } from '@nestjs/common';

@Controller('genre')
export class GenreController {
  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.genreService.findOne(id);
  }

  @Patch(':id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateGenreDto: UpdateGenreDto,
  ) {
    return this.genreService.update(id, updateGenreDto);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.genreService.remove(id);
  }
}
```

---

## Custom Validation Pipe

### 커스텀 Pipe 생성

커스텀 Pipe를 생성하여 특정 검증 로직을 구현할 수 있습니다.

### Pipe 인터페이스

모든 Pipe는 `PipeTransform` 인터페이스를 구현해야 합니다.

```typescript
import { PipeTransform, ArgumentMetadata } from '@nestjs/common';

export interface PipeTransform<T = any, R = any> {
  transform(value: T, metadata: ArgumentMetadata): R;
}
```

**설명**:
- `T`: 입력 타입
- `R`: 출력 타입
- `value`: 변환/검증할 값
- `metadata`: 파라미터 메타데이터 (타입, 데이터, 파라미터 이름 등)

### MovieTitleValidationPipe 생성

**파일**: `src/movie/pipe/movie-title-validation.pipe.ts`

```typescript
import {
  ArgumentMetadata,
  BadRequestException,
  Injectable,
  PipeTransform,
} from '@nestjs/common';

@Injectable()
export class MovieTitleValidationPipe implements PipeTransform<string, string> {
  transform(value: string, metadata: ArgumentMetadata): string {
    if (!value) {
      return value;
    }
    // 만약의 글자 길이가 2자 이하일 경우 에러 발생
    if (value.length <= 2) {
      throw new BadRequestException('제목은 3자 이상이어야 합니다.');
    }
    return value;
  }
}
```

**설명**:

1. **클래스 선언**:
   - `@Injectable()`: NestJS의 의존성 주입 시스템에 등록
   - `implements PipeTransform<string, string>`: 문자열을 입력받아 문자열을 반환

2. **transform 메서드**:
   - `value: string`: 변환/검증할 값 (쿼리 파라미터)
   - `metadata: ArgumentMetadata`: 파라미터 메타데이터
   - 반환값: 검증 통과 시 원본 값 반환

3. **검증 로직**:
   - `if (!value)`: 값이 없으면 그대로 반환 (선택적 파라미터 처리)
   - `if (value.length <= 2)`: 길이가 2자 이하면 에러 발생
   - `throw new BadRequestException()`: 400 에러 발생

4. **에러 처리**:
   - `BadRequestException`: NestJS의 HTTP 예외 클래스
   - 자동으로 `400 Bad Request` 응답 반환

### MovieTitleValidationPipe 사용

**파일**: `src/movie/movie.controller.ts`

```typescript
import { MovieTitleValidationPipe } from './pipe/movie-title-validation.pipe';

@Controller('movie')
export class MovieController {
  @Get()
  getMovies(@Query('title', MovieTitleValidationPipe) title?: string) {
    return this.movieService.findAll(title);
  }
}
```

**설명**:
- `@Query('title', MovieTitleValidationPipe)`: 쿼리 파라미터 `title`에 커스텀 Pipe 적용
- `title`이 제공되면 3자 이상인지 검증
- 검증 실패 시 `400 Bad Request` 에러 발생

**동작 예시**:

```bash
# ✅ 성공
GET /movie?title=인셉션
# title = "인셉션" (3자 이상)

# ❌ 실패
GET /movie?title=인
# 400 Bad Request: "제목은 3자 이상이어야 합니다."

# ✅ 성공 (title 없음)
GET /movie
# title = undefined (선택적 파라미터)
```

---

## MovieTitleValidationPipe 버그 수정

### 버그 상황

초기 구현에서 `value`가 `undefined`일 때 `value.length`를 호출하면 에러가 발생할 수 있습니다.

### 수정 전 코드

```typescript
@Injectable()
export class MovieTitleValidationPipe implements PipeTransform<string, string> {
  transform(value: string, metadata: ArgumentMetadata): string {
    // 버그: value가 undefined일 때 value.length 호출 시 에러
    if (value.length <= 2) {
      throw new BadRequestException('제목은 3자 이상이어야 합니다.');
    }
    return value;
  }
}
```

**문제점**:
- `value`가 `undefined`이면 `value.length` 호출 시 `TypeError` 발생
- 선택적 쿼리 파라미터(`title?`)를 처리하지 못함

### 수정 후 코드

```typescript
@Injectable()
export class MovieTitleValidationPipe implements PipeTransform<string, string> {
  transform(value: string, metadata: ArgumentMetadata): string {
    // 수정: value가 없으면 그대로 반환
    if (!value) {
      return value;
    }
    // value가 있을 때만 길이 검증
    if (value.length <= 2) {
      throw new BadRequestException('제목은 3자 이상이어야 합니다.');
    }
    return value;
  }
}
```

**수정 사항**:
- `if (!value)`: 값이 없으면(`undefined`, `null`, 빈 문자열) 그대로 반환
- 선택적 파라미터를 안전하게 처리
- 값이 있을 때만 검증 로직 실행

### 개선된 버전 (타입 안정성 강화)

```typescript
@Injectable()
export class MovieTitleValidationPipe implements PipeTransform<string | undefined, string | undefined> {
  transform(value: string | undefined, metadata: ArgumentMetadata): string | undefined {
    if (!value) {
      return value;
    }
    if (value.length <= 2) {
      throw new BadRequestException('제목은 3자 이상이어야 합니다.');
    }
    return value;
  }
}
```

**개선 사항**:
- 타입을 `PipeTransform<string | undefined, string | undefined>`로 명시
- `value`와 반환값의 타입을 `string | undefined`로 명확히 지정
- 타입 안정성 향상

---

## Pipe 사용 위치별 비교

### 1. 파라미터 레벨 (가장 일반적)

```typescript
@Get(':id')
getMovie(@Param('id', ParseIntPipe) id: number) {
  return this.movieService.findOne(id);
}
```

**장점**:
- 특정 파라미터에만 적용
- 가장 세밀한 제어 가능

### 2. 메서드 레벨

```typescript
@UsePipes(ParseIntPipe)
@Get(':id')
getMovie(@Param('id') id: number) {
  return this.movieService.findOne(id);
}
```

**설명**:
- 메서드의 모든 파라미터에 적용
- 여러 파라미터에 동일한 Pipe를 적용할 때 유용

### 3. 컨트롤러 레벨

```typescript
@Controller('movie')
@UsePipes(ValidationPipe)
export class MovieController {
  // 모든 메서드에 ValidationPipe 적용
}
```

**설명**:
- 컨트롤러의 모든 메서드에 적용
- 컨트롤러 전체에 공통 검증이 필요할 때 유용

### 4. 전역 레벨

```typescript
// main.ts
app.useGlobalPipes(new ValidationPipe());
```

**설명**:
- 전체 애플리케이션에 적용
- 모든 요청에 공통 검증이 필요할 때 유용

### 우선순위

파라미터 레벨 > 메서드 레벨 > 컨트롤러 레벨 > 전역 레벨

더 구체적인 레벨의 Pipe가 우선 적용됩니다.

---

## Pipe와 Interceptor의 차이

### Pipe

- **실행 시점**: 라우트 핸들러 실행 전
- **역할**: 입력 데이터 변환/검증
- **대상**: 요청 데이터 (`@Param()`, `@Query()`, `@Body()`)

### Interceptor

- **실행 시점**: 라우트 핸들러 실행 전후
- **역할**: 요청/응답 가로채기, 로깅, 변환
- **대상**: 요청과 응답 전체

---

## 프로젝트 파일 구조

```
src/
├── main.ts                                    # ValidationPipe 전역 설정
├── movie/
│   ├── movie.controller.ts                   # ParseIntPipe, MovieTitleValidationPipe 사용
│   └── pipe/
│       └── movie-title-validation.pipe.ts    # 커스텀 Pipe
├── director/
│   └── director.controller.ts                # ParseIntPipe 사용
└── genre/
    └── genre.controller.ts                   # ParseIntPipe 사용
```

---

## 핵심 개념 정리

### 1. Pipe의 역할

- **변환(Transformation)**: 데이터 타입 변환
- **검증(Validation)**: 데이터 유효성 검증

### 2. Pipe 사용 위치

- **파라미터 레벨**: `@Param('id', Pipe)`
- **메서드 레벨**: `@UsePipes(Pipe)`
- **컨트롤러 레벨**: `@Controller() @UsePipes(Pipe)`
- **전역 레벨**: `app.useGlobalPipes()`

### 3. 내장 Pipe

- `ParseIntPipe`: 문자열 → 정수
- `ParseFloatPipe`: 문자열 → 부동소수점
- `ParseBoolPipe`: 문자열 → 불리언
- `ParseUUIDPipe`: UUID 검증
- `ParseEnumPipe`: Enum 값 검증
- `DefaultValuePipe`: 기본값 제공
- `ValidationPipe`: DTO 검증

### 4. 커스텀 Pipe 생성

- `PipeTransform` 인터페이스 구현
- `@Injectable()` 데코레이터 추가
- `transform(value, metadata)` 메서드 구현

### 5. 에러 처리

- 검증 실패 시 `BadRequestException` 등 HTTP 예외 발생
- NestJS가 자동으로 적절한 HTTP 응답 반환

---

## 참고사항

1. **Pipe 체이닝**: 여러 Pipe를 순차적으로 적용 가능
2. **타입 안정성**: Pipe를 사용하면 타입 변환이 자동으로 이루어져 타입 안정성 향상
3. **에러 처리**: Pipe에서 예외를 던지면 자동으로 HTTP 에러 응답 반환
4. **선택적 파라미터**: `undefined` 체크를 통해 선택적 파라미터 안전하게 처리
5. **성능**: Pipe는 요청마다 실행되므로 무거운 작업은 피해야 함

---

## 실전 팁

### 1. 선택적 파라미터 처리

```typescript
transform(value: string | undefined, metadata: ArgumentMetadata): string | undefined {
  if (!value) {
    return value;  // undefined/null/빈 문자열 처리
  }
  // 검증 로직
}
```

### 2. 타입 안정성

```typescript
// ✅ 좋은 예
@Param('id', ParseIntPipe) id: number

// ❌ 나쁜 예
@Param('id') id: string
// +id 같은 수동 변환 필요
```

### 3. 에러 메시지 커스터마이징

```typescript
if (value.length <= 2) {
  throw new BadRequestException('제목은 3자 이상이어야 합니다.');
}
```

### 4. 여러 Pipe 조합

```typescript
@Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number
```

---

## 참고 자료

- [NestJS Pipe 공식 문서](https://docs.nestjs.com/pipes)
- [NestJS ValidationPipe 문서](https://docs.nestjs.com/techniques/validation)
