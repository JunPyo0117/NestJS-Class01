# Ch 38. End to End Test

## 목차
1. [E2E 테스트 개요](#1-e2e-테스트-개요)
2. [E2E 테스트 세팅하기](#2-e2e-테스트-세팅하기)
3. [E2E 테스트 작성하기](#3-e2e-테스트-작성하기)
4. [실제 테스트 케이스 분석](#4-실제-테스트-케이스-분석)

---

## 1. E2E 테스트 개요

### 1.1 E2E 테스트란?

**End-to-End (E2E) 테스트**는 애플리케이션의 전체 흐름을 실제 사용자 시나리오처럼 테스트하는 방법입니다. 단위 테스트나 통합 테스트와 달리, 실제 HTTP 요청을 보내고 전체 애플리케이션 스택(컨트롤러, 서비스, 데이터베이스 등)을 통해 응답을 검증합니다.

### 1.2 E2E 테스트의 특징

- **실제 환경 시뮬레이션**: 실제 HTTP 요청/응답을 테스트
- **전체 스택 검증**: 컨트롤러부터 데이터베이스까지 전체 흐름 검증
- **인증/인가 테스트**: JWT 토큰, Guard, Interceptor 등 실제 보안 로직 검증
- **파일 업로드 테스트**: 실제 파일 업로드 시나리오 테스트

### 1.3 통합 테스트 vs E2E 테스트

| 구분 | 통합 테스트 | E2E 테스트 |
|------|------------|-----------|
| **범위** | 서비스 레이어 + 데이터베이스 | 전체 애플리케이션 스택 |
| **요청 방식** | 직접 함수 호출 | HTTP 요청 (supertest) |
| **인증** | 직접 서비스 주입 | JWT 토큰 사용 |
| **파일 업로드** | Mock 객체 사용 | 실제 multipart/form-data |
| **실행 속도** | 빠름 | 상대적으로 느림 |

---

## 2. E2E 테스트 세팅하기

### 2.1 Jest E2E 설정 파일

프로젝트 루트에 `jest-e2e.json` 파일을 생성하여 E2E 테스트 전용 설정을 구성합니다.

```json
{
  "moduleFileExtensions": ["js", "json", "ts"],
  "roots": ["src"],
  "testEnvironment": "node",
  "testRegex": ".e2e.spec.ts$",
  "transform": {
    "^.+\\.(t|j)s$": [
      "ts-jest",
      {
        "tsconfig": {
          "esModuleInterop": true,
          "allowSyntheticDefaultImports": true
        }
      }
    ]
  },
  "moduleNameMapper": {
    "^src/(.*)$": "<rootDir>/src/$1",
    "^uuid$": "<rootDir>/src/__mocks__/uuid.js"
  },
  "transformIgnorePatterns": [
    "node_modules/(?!(@nestjs|uuid|@paralleldrive|cuid2|formidable|superagent|supertest)/)"
  ]
}
```

**주요 설정 설명:**

- **`testRegex`**: `.e2e.spec.ts`로 끝나는 파일만 E2E 테스트로 인식
- **`moduleNameMapper`**: `src/` 경로를 올바르게 매핑하고, ES Module인 `uuid` 패키지를 Mock으로 처리
- **`transformIgnorePatterns`**: 특정 패키지들(`supertest`, `uuid` 등)은 변환 대상에 포함

### 2.2 package.json 스크립트

```json
{
  "scripts": {
    "test:e2e": "NODE_ENV=test jest --config ./jest-e2e.json"
  }
}
```

### 2.3 환경 변수 설정

E2E 테스트 실행 시 `NODE_ENV=test`로 설정되므로, `test.env` 파일이 필요합니다.

```env
ENV=test
DB_TYPE=postgres
DB_HOST=localhost
DB_PORT=5555
DB_USERNAME=postgres
DB_PASSWORD=postgres
DB_DATABASE=test
HASH_ROUNDS=10
ACCESS_TOKEN_SECRET=codefactory
REFRESH_TOKEN_SECRET=codefactory
```

---

## 3. E2E 테스트 작성하기

### 3.1 기본 구조

```typescript
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../app.module';
import { DataSource } from 'typeorm';

describe('MovieController (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;

  beforeAll(async () => {
    // 테스트 모듈 생성 및 앱 초기화
  });

  afterAll(async () => {
    // 리소스 정리
  });

  describe('[GET] /movie', () => {
    it('should get all movies', async () => {
      // 테스트 케이스
    });
  });
});
```

### 3.2 beforeAll: 테스트 환경 설정

#### 3.2.1 테스트 모듈 생성 및 앱 초기화

```typescript
beforeAll(async () => {
  const moduleFixture: TestingModule = await Test.createTestingModule({
    imports: [AppModule],
  }).compile();

  app = moduleFixture.createNestApplication();
  
  // ValidationPipe 설정 (실제 앱과 동일하게)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );
  
  await app.init();
  dataSource = app.get<DataSource>(DataSource);
});
```

**주요 포인트:**

- **`Test.createTestingModule()`**: 실제 `AppModule`을 사용하여 전체 애플리케이션 컨텍스트 생성
- **`app.useGlobalPipes()`**: 실제 앱과 동일한 ValidationPipe 설정으로 일관성 유지
- **`app.init()`**: 애플리케이션 초기화 (의존성 주입, 모듈 로드 등)

#### 3.2.2 데이터베이스 초기화

```typescript
const movieUserLikeRepository = dataSource.getRepository(MovieUserLike);
const movieRepository = dataSource.getRepository(Movie);
const movieDetailRepository = dataSource.getRepository(MovieDetail);
const userRepository = dataSource.getRepository(User);
const directorRepository = dataSource.getRepository(Director);
const genreRepository = dataSource.getRepository(Genre);

// 외래 키 제약 조건을 고려하여 순서대로 삭제
await movieUserLikeRepository
  .createQueryBuilder()
  .delete()
  .from(MovieUserLike)
  .execute();

await movieRepository.createQueryBuilder().delete().from(Movie).execute();
await movieDetailRepository
  .createQueryBuilder()
  .delete()
  .from(MovieDetail)
  .execute();
await userRepository.createQueryBuilder().delete().from(User).execute();
await directorRepository
  .createQueryBuilder()
  .delete()
  .from(Director)
  .execute();
await genreRepository.createQueryBuilder().delete().from(Genre).execute();
```

**⚠️ 중요: 외래 키 제약 조건 고려**

- `delete({})`는 빈 객체를 허용하지 않아 오류 발생
- `createQueryBuilder().delete().from(Entity).execute()`를 사용하여 모든 레코드 삭제
- **외래 키 의존성 순서**를 고려하여 삭제 순서 결정:
  1. `MovieUserLike` (Movie에 의존)
  2. `Movie` (MovieDetail, Director, User에 의존)
  3. `MovieDetail`
  4. `User`
  5. `Director`
  6. `Genre`

#### 3.2.3 테스트 데이터 생성

```typescript
// 사용자 생성
users = [1, 2].map((x) =>
  userRepository.create({
    id: x,
    email: `${x}@test.com`,
    password: `123123`,
  }),
);
await userRepository.save(users);

// 감독 생성
directors = [1, 2].map((x) =>
  directorRepository.create({
    id: x,
    dob: new Date('1992-11-23'),
    nationality: 'South Korea',
    name: `Director Name ${x}`,
  }),
);
await directorRepository.save(directors);

// 장르 생성
genres = [1, 2].map((x) =>
  genreRepository.create({
    id: x,
    name: `Genre ${x}`,
  }),
);
await genreRepository.save(genres);

// 영화 생성
movies = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((x) =>
  movieRepository.create({
    id: x,
    title: `Movie ${x}`,
    creator: users[0],
    genres: genres,
    likeCount: 0,
    dislikeCount: 0,
    detail: movieDetailRepository.create({
      detail: `Movie Detail ${x}`,
    }),
    movieFilePath: 'movies/movie1.mp4',
    director: directors[0],
    createdAt: new Date(`2023-9-${x}`),
  }),
);
await movieRepository.save(movies);
```

#### 3.2.4 인증 토큰 발급

```typescript
const authService = moduleFixture.get<AuthService>(AuthService);
token = await authService.issueToken(
  { id: users[0].id, role: Role.admin },
  false,
);
```

**주요 포인트:**

- `moduleFixture.get()`으로 실제 `AuthService` 인스턴스 가져오기
- 실제 JWT 토큰을 발급하여 인증이 필요한 엔드포인트 테스트 가능

### 3.3 afterAll: 리소스 정리

```typescript
afterAll(async () => {
  await new Promise((resolve) => setTimeout(resolve, 500));
  await dataSource.destroy();
  await app.close();
});
```

**주요 포인트:**

- **`setTimeout`**: 비동기 작업 완료 대기
- **`dataSource.destroy()`**: 데이터베이스 연결 종료
- **`app.close()`**: NestJS 애플리케이션 종료

---

## 4. 실제 테스트 케이스 분석

### 4.1 GET /movie - 전체 영화 목록 조회

```typescript
describe('[GET] /movie', () => {
  it('should get all movies', async () => {
    const { body, statusCode, error } = await request(
      app.getHttpServer(),
    ).get('/movie');

    expect(statusCode).toBe(200);
    expect(body).toHaveProperty('data');
    expect(body).toHaveProperty('nextCursor');
    expect(body).toHaveProperty('count');

    expect(body.data).toHaveLength(5);
  });
});
```

**주요 포인트:**

- **`request(app.getHttpServer())`**: `supertest`를 사용하여 실제 HTTP 요청
- **`.get('/movie')`**: GET 요청 전송
- **응답 검증**: `statusCode`, `body` 구조, 데이터 개수 검증

### 4.2 GET /movie/recent - 최근 영화 조회

```typescript
describe('[GET] /movie/recent', () => {
  it('should get recent movies', async () => {
    const { body, statusCode, error } = await request(app.getHttpServer())
      .get('/movie/recent')
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(200);
    expect(body).toHaveLength(10);
  });
});
```

**주요 포인트:**

- **`.set('authorization', \`Bearer ${token}\`)`**: JWT 토큰을 헤더에 설정
- 인증이 필요한 엔드포인트 테스트

### 4.3 GET /movie/:id - 영화 상세 조회

```typescript
describe('[GET] /movie/:id', () => {
  it('should get movie by id', async () => {
    const movieId = movies[0].id;

    const { body, statusCode, error } = await request(app.getHttpServer())
      .get(`/movie/${movieId}`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(200);
    expect(body.id).toBe(movieId);
  });

  it('should throw 404 error if movie id is not found', async () => {
    const movieId = 9999999;

    const { body, statusCode, error } = await request(app.getHttpServer())
      .get(`/movie/${movieId}`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(404);
  });
});
```

**주요 포인트:**

- **정상 케이스**: 존재하는 ID로 조회 성공 검증
- **에러 케이스**: 존재하지 않는 ID로 404 에러 검증

### 4.4 POST /movie - 영화 생성 (파일 업로드 포함)

```typescript
describe('[POST /movie]', () => {
  it('should create movie', async () => {
    // 1. 비디오 파일 업로드
    const {
      body: { filename },
    } = await request(app.getHttpServer())
      .post(`/common/video`)
      .set('authorization', `Bearer ${token}`)
      .attach('video', Buffer.from('test'), 'movie.mp4')
      .expect(201);

    // 2. 영화 생성 DTO 준비
    const dto = {
      title: 'Test Movie',
      detail: 'Test Movie Detail',
      directorId: directors[0].id,
      genreIds: genres.map((x) => x.id),
      movieFileName: filename,
    };

    // 3. 영화 생성 요청
    const { body, statusCode } = await request(app.getHttpServer())
      .post(`/movie`)
      .set('authorization', `Bearer ${token}`)
      .send(dto);

    // 4. 응답 검증
    expect(statusCode).toBe(201);
    expect(body).toBeDefined();
    expect(body.title).toBe(dto.title);
    expect(body.detail.detail).toBe(dto.detail);
    expect(body.director.id).toBe(dto.directorId);
    expect(body.genres.map((x) => x.id)).toEqual(dto.genreIds);
    expect(body.movieFilePath).toContain(filename);
  });
});
```

**주요 포인트:**

- **`.attach('video', Buffer.from('test'), 'movie.mp4')`**: `multipart/form-data`로 파일 업로드
  - 첫 번째 인자: 필드명 (`video`)
  - 두 번째 인자: 파일 내용 (Buffer)
  - 세 번째 인자: 파일명 (`movie.mp4`)
- **2단계 프로세스**: 
  1. `/common/video`로 파일 업로드 → `filename` 반환
  2. `/movie`로 영화 생성 → `filename` 사용
- **중첩 객체 검증**: `body.detail.detail`, `body.director.id`, `body.genres.map(...)`

### 4.5 PATCH /movie/:id - 영화 수정

```typescript
describe('[PATCH /movie/{id}]', () => {
  it('should update movie if exists', async () => {
    const dto = {
      title: 'Updated Test Movie',
      detail: 'Updated Test Movie Detail',
      directorId: directors[0].id,
      genreIds: [genres[0].id],
    };

    const movieId = movies[0].id;

    const { body, statusCode } = await request(app.getHttpServer())
      .patch(`/movie/${movieId}`)
      .set('authorization', `Bearer ${token}`)
      .send(dto);

    expect(statusCode).toBe(200);
    expect(body).toBeDefined();
    expect(body.title).toBe(dto.title);
    expect(body.detail.detail).toBe(dto.detail);
    expect(body.director.id).toBe(dto.directorId);
    expect(body.genres.map((x) => x.id)).toEqual(dto.genreIds);
  });
});
```

**주요 포인트:**

- **`.patch()`**: PATCH 메서드 사용
- **`.send(dto)`**: JSON 본문 전송

### 4.6 DELETE /movie/:id - 영화 삭제

```typescript
describe('[DELETE /movie/{id}]', () => {
  it('should delete existing movie', async () => {
    const movieId = movies[0].id;

    const { body, statusCode } = await request(app.getHttpServer())
      .delete(`/movie/${movieId}`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(200);
  });

  it('should throw 404 error if movie does not exist', async () => {
    const movieId = 99999;

    const { statusCode } = await request(app.getHttpServer())
      .delete(`/movie/${movieId}`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(404);
  });
});
```

**주요 포인트:**

- **`.delete()`**: DELETE 메서드 사용
- 정상 삭제 및 에러 케이스 모두 테스트

### 4.7 POST /movie/:id/like - 좋아요

```typescript
describe('[POST /movie/{id}/like]', () => {
  it('should like a movie', async () => {
    const movieId = movies[1].id;

    const { statusCode, body } = await request(app.getHttpServer())
      .post(`/movie/${movieId}/like`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(201);
    expect(body).toBeDefined();
    expect(body.isLike).toBe(true);
  });

  it('should cancel like a movie', async () => {
    const movieId = movies[1].id;

    const { statusCode, body } = await request(app.getHttpServer())
      .post(`/movie/${movieId}/like`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(201);
    expect(body).toBeDefined();
    expect(body.isLike).toBeNull();
  });
});
```

**주요 포인트:**

- **토글 동작**: 같은 엔드포인트를 두 번 호출하여 좋아요 → 취소 테스트
- **상태 검증**: `isLike` 값으로 좋아요 상태 확인

### 4.8 POST /movie/:id/dislike - 싫어요

```typescript
describe('[POST /movie/{id}/dislike]', () => {
  it('should dislike a movie', async () => {
    const movieId = movies[1].id;

    const { statusCode, body } = await request(app.getHttpServer())
      .post(`/movie/${movieId}/dislike`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(201);
    expect(body).toBeDefined();
    expect(body.isLike).toBe(false);
  });

  it('should cancel dislike a movie', async () => {
    const movieId = movies[1].id;

    const { statusCode, body } = await request(app.getHttpServer())
      .post(`/movie/${movieId}/dislike`)
      .set('authorization', `Bearer ${token}`);

    expect(statusCode).toBe(201);
    expect(body).toBeDefined();
    expect(body.isLike).toBeNull();
  });
});
```

---

## 5. E2E 테스트 작성 시 주의사항

### 5.1 데이터 격리

- 각 테스트는 독립적으로 실행되어야 함
- `beforeAll`에서 데이터를 초기화하고, 각 테스트는 필요한 데이터만 사용

### 5.2 외래 키 제약 조건

- 데이터 삭제 시 외래 키 의존성 순서를 고려
- `createQueryBuilder().delete().from(Entity).execute()` 사용

### 5.3 인증 토큰 관리

- `beforeAll`에서 토큰을 한 번 발급하여 재사용
- 필요시 여러 사용자 역할의 토큰을 발급하여 테스트

### 5.4 파일 업로드 테스트

- `Buffer.from('test')`로 간단한 테스트 파일 생성
- 실제 파일 시스템에 저장되므로 테스트 후 정리 필요

### 5.5 비동기 작업 대기

- `afterAll`에서 `setTimeout`을 사용하여 비동기 작업 완료 대기
- 데이터베이스 연결 종료 전 충분한 대기 시간 확보

---

## 6. 실행 및 디버깅

### 6.1 테스트 실행

```bash
pnpm test:e2e
```

### 6.2 특정 테스트만 실행

```bash
pnpm test:e2e -- --testNamePattern="should get all movies"
```

### 6.3 디버깅 팁

- **`console.log(body, statusCode)`**: 응답 내용 확인
- **`console.log(error)`**: 에러 정보 확인
- **`.expect(201)`**: 중간 단계에서 상태 코드 검증

---

## 7. 요약

E2E 테스트는 실제 사용자 시나리오를 시뮬레이션하여 전체 애플리케이션 스택을 검증하는 중요한 테스트 방법입니다. 

**핵심 포인트:**

1. ✅ 실제 `AppModule`을 사용하여 전체 컨텍스트 생성
2. ✅ `supertest`로 실제 HTTP 요청/응답 테스트
3. ✅ 외래 키 제약 조건을 고려한 데이터 초기화
4. ✅ JWT 토큰을 사용한 인증/인가 테스트
5. ✅ 파일 업로드를 포함한 복잡한 시나리오 테스트
6. ✅ 정상 케이스와 에러 케이스 모두 검증

이를 통해 실제 프로덕션 환경과 유사한 조건에서 애플리케이션의 동작을 검증할 수 있습니다.
