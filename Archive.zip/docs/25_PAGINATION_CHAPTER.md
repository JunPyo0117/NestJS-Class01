# Part 16. Pagination

## 목차
1. [Pagination 이론](#1-pagination-이론)
2. [Page Based Pagination 구현하기](#2-page-based-pagination-구현하기)
3. [EnableImplicitConversion 설정](#3-enableimplicitconversion-설정)
4. [커서 기반 페이지네이션](#4-커서-기반-페이지네이션)
   - [커서 기반 페이지네이션의 개념](#41-커서-기반-페이지네이션의-개념)
   - [CursorPaginationDto 생성](#42-cursorpaginationdto-생성)
   - [CommonService에 커서 페이지네이션 메서드 추가](#43-commonservice에-커서-페이지네이션-메서드-추가)
   - [다음 커서 생성](#44-다음-커서-생성)
   - [Service에서 커서 페이지네이션 사용](#45-service에서-커서-페이지네이션-사용)
   - [사용 예시](#47-사용-예시)

---

## 1. Pagination 이론

### 1.1 Pagination이란?

**Pagination(페이지네이션)**은 대량의 데이터를 작은 단위로 나누어 보여주는 기법입니다. 모든 데이터를 한 번에 조회하는 대신, 페이지 단위로 나누어 효율적으로 데이터를 제공합니다.

#### Pagination의 필요성

1. **성능 향상**: 대량의 데이터를 한 번에 조회하지 않아 쿼리 성능 향상
2. **메모리 효율**: 클라이언트와 서버 모두 메모리 사용량 감소
3. **사용자 경험**: 필요한 데이터만 빠르게 로드하여 응답 속도 개선
4. **네트워크 효율**: 전송 데이터량 감소

### 1.2 페이지네이션 방식

#### 1. Offset 기반 페이지네이션 (Page Based)

- **방식**: 페이지 번호와 페이지 크기를 사용
- **예시**: `page=1, take=10` → 첫 10개 항목
- **장점**: 구현이 간단하고 직관적
- **단점**: 대용량 데이터에서 성능 저하 가능 (OFFSET이 클수록 느림)

```
페이지 1: LIMIT 10 OFFSET 0  (1-10번째)
페이지 2: LIMIT 10 OFFSET 10 (11-20번째)
페이지 3: LIMIT 10 OFFSET 20 (21-30번째)
```

#### 2. Cursor 기반 페이지네이션

- **방식**: 특정 기준점(커서)을 기준으로 다음 데이터 조회
- **예시**: `cursor=123, take=10` → ID 123 이후 10개
- **장점**: 대용량 데이터에서도 일정한 성능 유지
- **단점**: 구현이 복잡하고 이전 페이지로 이동 어려움

```
커서 0: LIMIT 10 WHERE id > 0   (1-10번째)
커서 10: LIMIT 10 WHERE id > 10  (11-20번째)
커서 20: LIMIT 10 WHERE id > 20  (21-30번째)
```

### 1.3 페이지네이션 파라미터

#### 공통 파라미터

- **page**: 현재 페이지 번호 (1부터 시작)
- **take**: 한 페이지에 가져올 항목 수 (page size)
- **skip**: 건너뛸 항목 수 (계산: `skip = (page - 1) * take`)

#### 응답 형식

```typescript
{
  data: [...],      // 실제 데이터 배열
  total: 100,      // 전체 항목 수
  page: 1,         // 현재 페이지
  take: 10,        // 페이지 크기
  totalPages: 10   // 전체 페이지 수 (선택적)
}
```

---

## 2. Page Based Pagination 구현하기

### 2.1 PagePagenationDto 생성

페이지네이션을 위한 공통 DTO를 생성합니다.

```typescript:src/common/dto/page-pagenation.dto.ts
import { IsInt, IsOptional } from 'class-validator';

export class PagePagenationDto {
  @IsOptional()
  @IsInt()
  page: number = 1;

  @IsOptional()
  @IsInt()
  take: number = 5;
}
```

#### 주요 설정

- **@IsOptional()**: 선택적 파라미터 (없으면 기본값 사용)
- **@IsInt()**: 정수 타입 검증
- **기본값**: `page = 1`, `take = 5`
- **타입**: `page: number` (옵셔널 마커 `?` 없음 - 기본값이 있으므로)

### 2.2 CommonService에 페이지네이션 메서드 추가

공통 서비스에 QueryBuilder에 페이지네이션을 적용하는 메서드를 추가합니다.

```typescript:src/common/common.service.ts
import { Injectable } from '@nestjs/common';
import { ObjectLiteral, SelectQueryBuilder } from 'typeorm';
import { PagePagenationDto } from './dto/page-pagenation.dto';

@Injectable()
export class CommonService {
  constructor() {}

  applyPagePaginationParamsToQb<T extends ObjectLiteral>(
    qb: SelectQueryBuilder<T>,
    dto: PagePagenationDto,
  ) {
    const { page, take } = dto;
    const skip = (page - 1) * take;
    qb.take(take);
    qb.skip(skip);
  }
}
```

#### 메서드 설명

- **제네릭 타입 제약**: `T extends ObjectLiteral` - TypeORM의 `SelectQueryBuilder`가 요구하는 제약 조건
- **skip 계산**: `(page - 1) * take` - 첫 페이지는 0, 두 번째 페이지는 take만큼 건너뛰기
- **take**: 한 페이지에 가져올 항목 수
- **skip**: 건너뛸 항목 수

#### CommonModule 설정

```typescript:src/common/common.module.ts
import { Module } from '@nestjs/common';
import { CommonService } from './common.service';

@Module({
  imports: [],
  controllers: [],
  providers: [CommonService],
  exports: [CommonService],  // 다른 모듈에서 사용할 수 있도록 export
})
export class CommonModule {}
```

### 2.3 Service에서 페이지네이션 적용

MovieService에서 페이지네이션을 사용합니다.

```typescript:src/movie/movie.service.ts
import { CommonService } from 'src/common/common.service';

@Injectable()
export class MovieService {
  constructor(
    // ... other dependencies
    private readonly commonService: CommonService,
  ) {}

  async findAll(dto: GetMoviesDto) {
    const { title, take, page } = dto;

    const qb = this.movieRepository
      .createQueryBuilder('movie')
      .leftJoinAndSelect('movie.director', 'director')
      .leftJoinAndSelect('movie.genres', 'genres');

    if (title) {
      qb.where('movie.title LIKE :title', { title: `%${title}%` });
    }

    if (take && page) {
      this.commonService.applyPagePaginationParamsToQb(qb, dto);
    }

    return await qb.getManyAndCount();
  }
}
```

#### 동작 방식

1. QueryBuilder 생성 및 조인 설정
2. 조건부 필터링 (title이 있으면 WHERE 추가)
3. 페이지네이션 적용 (`take`와 `page`가 있으면)
4. `getManyAndCount()` 반환: `[데이터 배열, 전체 개수]`

#### MovieModule에 CommonModule 추가

```typescript:src/movie/movie.module.ts
import { CommonModule } from 'src/common/common.module';

@Module({
  imports: [
    // ... other imports
    CommonModule,
  ],
  // ...
})
export class MovieModule {}
```

### 2.4 DTO에서 PagePagenationDto 상속

GetMoviesDto가 PagePagenationDto를 상속받도록 설정합니다.

```typescript:src/movie/dto/get-movies.dto.ts
import { IsOptional, IsString } from 'class-validator';
import { PagePagenationDto } from 'src/common/dto/page-pagenation.dto';

export class GetMoviesDto extends PagePagenationDto {
  @IsOptional()
  @IsString()
  title?: string;
}
```

#### 상속의 장점

- **코드 재사용**: 페이지네이션 로직을 여러 DTO에서 재사용
- **일관성**: 모든 엔드포인트에서 동일한 페이지네이션 파라미터 사용
- **유지보수**: 페이지네이션 로직 변경 시 한 곳만 수정

### 2.5 Controller에서 사용

Controller에서 DTO를 받아 Service에 전달합니다.

```typescript:src/movie/movie.controller.ts
import { GetMoviesDto } from './dto/get-movies.dto';

@Controller('movie')
export class MovieController {
  @Get()
  @Public()
  getMovies(@Query() dto: GetMoviesDto) {
    return this.movieService.findAll(dto);
  }
}
```

#### 쿼리 파라미터 예시

```
GET /movie?page=1&take=10
GET /movie?page=2&take=10&title=action
GET /movie?title=comedy  (페이지네이션 없이 전체 조회)
```

### 2.6 응답 형식

`getManyAndCount()`는 `[데이터 배열, 전체 개수]`를 반환합니다.

```typescript
// Service
return await qb.getManyAndCount();

// 응답 예시
[
  [
    { id: 1, title: "Movie 1", ... },
    { id: 2, title: "Movie 2", ... },
    // ... 10개 항목
  ],
  100  // 전체 개수
]
```

#### 클라이언트에서 활용

클라이언트는 전체 개수를 알 수 있어 다음과 같은 정보를 표시할 수 있습니다:
- 전체 페이지 수: `Math.ceil(total / take)`
- 현재 페이지
- 다음/이전 페이지 존재 여부

---

## 3. EnableImplicitConversion 설정

### 3.1 문제 상황

쿼리 파라미터는 기본적으로 문자열로 전달됩니다. 하지만 DTO에서는 `number` 타입을 기대합니다.

```
GET /movie?page=1&take=10
// page: "1" (string)
// take: "10" (string)
```

### 3.2 해결 방법: enableImplicitConversion

`ValidationPipe`에 `enableImplicitConversion: true` 옵션을 추가하여 자동 타입 변환을 활성화합니다.

```typescript:src/main.ts
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transformOptions: {
        enableImplicitConversion: true,  // 자동 타입 변환 활성화
      },
    }),
  );
  await app.listen(process.env.PORT ?? 3000);
}
```

#### enableImplicitConversion의 동작

- **문자열 → 숫자**: `"1"` → `1`
- **문자열 → 불린**: `"true"` → `true`
- **자동 변환**: `@IsInt()` 같은 데코레이터가 있으면 자동으로 변환 시도

#### 설정 전후 비교

**설정 전:**
```typescript
// 쿼리: ?page=1&take=10
// DTO: { page: "1", take: "10" }  // 문자열
// 오류: 타입 불일치
```

**설정 후:**
```typescript
// 쿼리: ?page=1&take=10
// DTO: { page: 1, take: 10 }  // 숫자
// 정상: 자동 변환됨
```

### 3.3 ValidationPipe 옵션 설명

```typescript
new ValidationPipe({
  whitelist: true,                    // DTO에 정의되지 않은 속성 제거
  forbidNonWhitelisted: true,         // DTO에 정의되지 않은 속성 있으면 오류
  transformOptions: {
    enableImplicitConversion: true,   // 자동 타입 변환
  },
})
```

---

## 4. 커서 기반 페이지네이션

### 4.1 커서 기반 페이지네이션의 개념

커서 기반 페이지네이션은 특정 기준점(커서)을 기준으로 다음 데이터를 조회하는 방식입니다. Offset 기반과 달리 데이터의 위치를 기준으로 하므로 대용량 데이터에서도 일정한 성능을 유지합니다.

#### 커서의 구조

커서는 Base64로 인코딩된 JSON 객체입니다:

```json
{
  "values": {
    "likeCount": 20,
    "id": 35,
    "createdAt": "2026-01-14T14:55:34.278Z"
  },
  "order": ["likeCount_DESC", "id_DESC", "createdAt_DESC"]
}
```

#### 멀티 컬럼 커서

여러 컬럼을 기준으로 정렬할 때는 모든 컬럼 값을 커서에 포함시켜야 합니다. 이를 통해 정확한 위치를 지정할 수 있습니다.

### 4.2 CursorPaginationDto 생성

커서 기반 페이지네이션을 위한 DTO를 생성합니다.

```typescript:src/common/dto/cursor-pagination.dto.ts
import { IsArray, IsInt, IsOptional, IsString } from 'class-validator';

export class CursorPaginationDto {
  @IsString()
  @IsOptional()
  cursor?: string;

  @IsArray()
  @IsString({
    each: true,
  })
  @IsOptional()
  // [id_DESC, likeCount_ASC]
  order: string[] = ['id_DESC'];

  @IsOptional()
  @IsInt()
  take: number = 5;
}
```

#### 주요 속성

- **cursor**: Base64로 인코딩된 커서 문자열 (선택적)
- **order**: 정렬 기준 배열 (예: `['likeCount_DESC', 'id_DESC']`)
- **take**: 한 번에 가져올 항목 수 (기본값: 5)

### 4.3 CommonService에 커서 페이지네이션 메서드 추가

```typescript:src/common/common.service.ts
async applyCursorPaginationParamsToQb<T extends ObjectLiteral>(
  qb: SelectQueryBuilder<T>,
  dto: CursorPaginationDto,
) {
  let { cursor, take, order } = dto;

  // 커서가 있으면 디코딩하여 WHERE 조건 추가
  if (cursor) {
    const decodedCursor = Buffer.from(cursor, 'base64').toString('utf-8');
    const cursorObj = JSON.parse(decodedCursor);

    order = cursorObj.order;
    const { values } = cursorObj;

    // Row Comparison을 사용한 WHERE 조건
    // (column1, column2, column3) < (value1, value2, value3)
    const columns = Object.keys(values);
    const comparisonOperator = order.some((o) => o.endsWith('DESC'))
      ? '<'
      : '>';

    const whereConditions = columns.map((c) => `${qb.alias}.${c}`).join(',');
    const whereParams = columns.map((c) => `:${c}`).join(',');

    qb.where(
      `(${whereConditions}) ${comparisonOperator} (${whereParams})`,
      values,
    );
  }

  // ORDER BY 설정
  for (let i = 0; i < order.length; i++) {
    const [column, direction] = order[i].split('_');

    if (direction !== 'ASC' && direction !== 'DESC') {
      throw new BadRequestException(
        'Order는 ASC 또는 DESC 형식이어야 합니다.',
      );
    }

    if (i === 0) {
      qb.orderBy(`${qb.alias}.${column}`, direction);
    } else {
      qb.addOrderBy(`${qb.alias}.${column}`, direction);
    }
  }

  qb.take(take);

  const results = await qb.getMany();

  const nextCursor = this.generateNextCursor(results, order);
  return {
    qb,
    nextCursor,
  };
}
```

#### Row Comparison 설명

PostgreSQL의 Row Comparison을 사용하여 여러 컬럼을 한 번에 비교합니다:

```sql
-- 단일 컬럼 비교
WHERE id < 35

-- 멀티 컬럼 비교 (Row Comparison)
WHERE (likeCount, id, createdAt) < (20, 35, '2026-01-14 14:55:34.278105')
```

Row Comparison은 다음과 같이 동작합니다:
- `(a, b, c) < (x, y, z)`는 `a < x OR (a = x AND b < y) OR (a = x AND b = y AND c < z)`와 동일

#### 비교 연산자 결정

```typescript
const comparisonOperator = order.some((o) => o.endsWith('DESC'))
  ? '<'  // 내림차순: 더 작은 값 (이전 페이지)
  : '>'; // 오름차순: 더 큰 값 (다음 페이지)
```

- **DESC 정렬**: `WHERE (columns) < (values)` - 커서보다 작은 값
- **ASC 정렬**: `WHERE (columns) > (values)` - 커서보다 큰 값

### 4.4 다음 커서 생성

마지막 항목의 값을 기반으로 다음 커서를 생성합니다.

```typescript:src/common/common.service.ts
generateNextCursor<T>(results: T[], order: string[]): string | null {
  if (results.length === 0) {
    return null;
  }

  const lastItem = results[results.length - 1];
  const values = {};

  // order에 따라 마지막 항목의 값들을 추출
  order.forEach((columnOrder) => {
    const [column] = columnOrder.split('_');
    values[column] = lastItem[column];
  });

  const cursorObj = { values, order };
  const nextCursor = Buffer.from(JSON.stringify(cursorObj)).toString(
    'base64',
  );

  return nextCursor;
}
```

#### 동작 방식

1. 결과 배열의 마지막 항목 추출
2. `order`에 지정된 컬럼들의 값을 추출
3. `values`와 `order`를 포함한 객체 생성
4. JSON 문자열로 변환 후 Base64 인코딩

### 4.5 Service에서 커서 페이지네이션 사용

MovieService에서 커서 페이지네이션을 적용합니다.

```typescript:src/movie/movie.service.ts
async findAll(dto: GetMoviesDto) {
  const { title } = dto;

  const qb = this.movieRepository
    .createQueryBuilder('movie')
    .leftJoinAndSelect('movie.director', 'director')
    .leftJoinAndSelect('movie.genres', 'genres');

  if (title) {
    qb.where('movie.title LIKE :title', { title: `%${title}%` });
  }

  // 커서 페이지네이션 적용
  const { nextCursor } =
    await this.commonService.applyCursorPaginationParamsToQb(qb, dto);

  const [data, count] = await qb.getManyAndCount();
  return { data, count, nextCursor };
}
```

#### 응답 형식

```typescript
{
  data: [...],           // 실제 데이터 배열
  count: 100,           // 전체 개수
  nextCursor: "eyJ2YWx1ZXMiOnsiaWQiOjM1fSwib3JkZXIiOlsiaWRfREVTQyJdfQ=="  // 다음 커서 (없으면 null)
}
```

### 4.6 DTO에서 CursorPaginationDto 상속

GetMoviesDto가 CursorPaginationDto를 상속받도록 설정합니다.

```typescript:src/movie/dto/get-movies.dto.ts
import { IsOptional, IsString } from 'class-validator';
import { CursorPaginationDto } from 'src/common/dto/cursor-pagination.dto';

export class GetMoviesDto extends CursorPaginationDto {
  @IsOptional()
  @IsString()
  title?: string;
}
```

### 4.7 사용 예시

#### 첫 페이지 요청

```
GET /movie?order[]=likeCount_DESC&order[]=id_DESC&take=5
```

**응답:**
```json
{
  "data": [
    { "id": 39, "likeCount": 25, ... },
    { "id": 38, "likeCount": 25, ... },
    { "id": 37, "likeCount": 20, ... },
    { "id": 36, "likeCount": 20, ... },
    { "id": 35, "likeCount": 20, ... }
  ],
  "count": 100,
  "nextCursor": "eyJ2YWx1ZXMiOnsibGlrZUNvdW50IjoyMCwiaWQiOjM1fSwib3JkZXIiOlsibGlrZUNvdW50X0RFU0MiLCJpZF9ERVNDIl19"
}
```

#### 다음 페이지 요청

```
GET /movie?cursor=eyJ2YWx1ZXMiOnsibGlrZUNvdW50IjoyMCwiaWQiOjM1fSwib3JkZXIiOlsibGlrZUNvdW50X0RFU0MiLCJpZF9ERVNDIl19&take=5
```

**SQL 생성:**
```sql
SELECT * FROM movie
WHERE (likeCount, id) < (20, 35)
ORDER BY likeCount DESC, id DESC
LIMIT 5
```

### 4.8 커서 기반 vs 페이지 기반 비교

| 구분 | 페이지 기반 | 커서 기반 |
|------|------------|----------|
| **파라미터** | `page`, `take` | `cursor`, `take` |
| **성능** | OFFSET이 클수록 느림 | 일정한 성능 |
| **이전 페이지** | 가능 | 어려움 |
| **구현 복잡도** | 간단 | 복잡 |
| **용도** | 일반적인 페이지네이션 | 대용량 데이터, 실시간 피드 |

### 4.9 주의사항

1. **정렬 순서 일치**: 커서의 `order`와 실제 ORDER BY가 일치해야 함
2. **컬럼 타입**: 날짜/시간 값은 작은따옴표(`'`)로 감싸야 함 (SQL에서)
3. **NULL 처리**: NULL 값이 있는 경우 추가 처리 필요
4. **인덱스**: 정렬 컬럼에 인덱스가 있으면 성능 향상

---

## 정리

### 페이지 기반 페이지네이션의 핵심

1. **DTO**: `PagePagenationDto`로 공통 파라미터 정의
2. **Service**: `CommonService`의 메서드로 QueryBuilder에 적용
3. **계산**: `skip = (page - 1) * take`
4. **응답**: `getManyAndCount()`로 데이터와 전체 개수 반환

### 커서 기반 페이지네이션의 핵심

1. **DTO**: `CursorPaginationDto`로 커서와 정렬 기준 정의
2. **커서 구조**: Base64 인코딩된 JSON 객체
3. **Row Comparison**: PostgreSQL의 튜플 비교 기능 활용
4. **다음 커서**: 마지막 항목의 값으로 생성

### 구현 요약

#### 페이지 기반
1. **PagePagenationDto**: `page`, `take` 파라미터 정의
2. **CommonService**: `applyPagePaginationParamsToQb()` 메서드
3. **Service**: QueryBuilder에 페이지네이션 적용
4. **Controller**: DTO를 받아 Service에 전달

#### 커서 기반
1. **CursorPaginationDto**: `cursor`, `order`, `take` 파라미터 정의
2. **CommonService**: `applyCursorPaginationParamsToQb()` 메서드
3. **Row Comparison**: 멀티 컬럼 비교를 위한 WHERE 조건
4. **다음 커서 생성**: `generateNextCursor()` 메서드

### 사용 예시

#### 페이지 기반
```typescript
// 쿼리
GET /movie?page=2&take=10

// DTO
{ page: 2, take: 10 }

// SQL
SELECT * FROM movie 
LIMIT 10 
OFFSET 10  // (2-1) * 10 = 10

// 응답
[
  [/* 10개 항목 */],
  100  // 전체 개수
]
```

#### 커서 기반
```typescript
// 쿼리
GET /movie?order[]=likeCount_DESC&order[]=id_DESC&take=5

// DTO
{ 
  order: ['likeCount_DESC', 'id_DESC'], 
  take: 5 
}

// SQL
SELECT * FROM movie
ORDER BY likeCount DESC, id DESC
LIMIT 5

// 응답
{
  data: [/* 5개 항목 */],
  count: 100,
  nextCursor: "eyJ2YWx1ZXMiOnsibGlrZUNvdW50IjoyMCwiaWQiOjM1fSwib3JkZXIiOlsibGlrZUNvdW50X0RFU0MiLCJpZF9ERVNDIl19"
}
```

### 선택 가이드

- **페이지 기반**: 일반적인 페이지네이션, 이전/다음 페이지 이동 필요, 구현 간단
- **커서 기반**: 대용량 데이터, 실시간 피드, 성능이 중요한 경우, 이전 페이지 불필요

각 방식은 장단점이 있으므로 프로젝트의 요구사항에 맞게 선택하는 것이 중요합니다.
