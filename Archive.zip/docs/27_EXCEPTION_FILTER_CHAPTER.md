# Part 19. Exception Filter

## 목차
1. [Exception Filter 이론](#1-exception-filter-이론)
2. [Forbidden Exception Filter 구현하기](#2-forbidden-exception-filter-구현하기)
3. [Query Failed Exception Filter 구현하기](#3-query-failed-exception-filter-구현하기)

---

## 1. Exception Filter 이론

### 1.1 Exception Filter란?

**Exception Filter(예외 필터)**는 애플리케이션에서 발생하는 예외를 전역적으로 처리하는 컴포넌트입니다. 예외가 발생했을 때 사용자에게 보여줄 응답 형식을 일관되게 관리할 수 있습니다.

#### Exception Filter의 특징

1. **전역 예외 처리**: 애플리케이션 전체에서 발생하는 예외를 중앙에서 처리
2. **일관된 응답 형식**: 모든 예외에 대해 동일한 형식의 응답 제공
3. **예외별 커스텀 처리**: 특정 예외 타입에 대해 맞춤형 처리 가능
4. **로깅 및 모니터링**: 예외 발생 시 로깅 및 모니터링 정보 수집

### 1.2 Exception Filter의 실행 순서

Exception Filter는 NestJS의 요청 처리 파이프라인에서 **가장 마지막**에 실행됩니다. 예외가 발생하면 해당 예외를 처리하는 Filter가 실행됩니다.

```
요청 → Middleware → Guard → Interceptor → Pipe → Controller → Service
                                                                    ↓
                                                              예외 발생
                                                                    ↓
응답 ← Exception Filter ← 예외 처리 및 응답 생성
```

#### 실행 흐름

1. 요청 처리 중 예외 발생
2. Exception Filter가 예외를 캐치
3. 예외 타입에 맞는 Filter 실행
4. 일관된 형식의 에러 응답 반환

### 1.3 ExceptionFilter 인터페이스

Exception Filter는 `ExceptionFilter` 인터페이스를 구현해야 합니다.

```typescript
export interface ExceptionFilter<T = any> {
  catch(exception: T, host: ArgumentsHost): any;
}
```

- `catch` 메서드를 구현해야 함
- `exception`: 발생한 예외 객체
- `ArgumentsHost`: 현재 실행 컨텍스트 (HTTP, WebSocket, RPC 등)

### 1.4 @Catch 데코레이터

`@Catch()` 데코레이터를 사용하여 특정 예외 타입을 처리할 Filter를 지정합니다.

```typescript
@Catch(ForbiddenException)
export class ForbiddenExceptionFilter implements ExceptionFilter {
  // ForbiddenException만 처리
}

@Catch()  // 인자 없음 - 모든 예외 처리
export class AllExceptionsFilter implements ExceptionFilter {
  // 모든 예외 처리
}
```

### 1.5 ArgumentsHost

`ArgumentsHost`는 현재 실행 컨텍스트에 대한 정보를 제공합니다.

```typescript
const ctx = host.switchToHttp();
const response = ctx.getResponse();  // Express Response 객체
const request = ctx.getRequest();    // Express Request 객체
```

- `switchToHttp()`: HTTP 컨텍스트로 전환
- `getResponse()`: 응답 객체 가져오기
- `getRequest()`: 요청 객체 가져오기

---

## 2. Forbidden Exception Filter 구현하기

### 2.1 ForbiddenExceptionFilter 생성

`ForbiddenException`을 처리하는 Filter를 생성합니다.

```typescript:src/common/filter/forbidden.filter.ts
import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  ForbiddenException,
} from '@nestjs/common';

@Catch(ForbiddenException)
export class ForbiddenExceptionFilter implements ExceptionFilter {
  catch(exception: ForbiddenException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();

    const status = exception.getStatus();

    console.log(
      `[UnauthorizedException] ${request.method} ${request.path} ${status}`,
    );

    response.status(status).json({
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      message: '권한이 없습니다!!!',
    });
  }
}
```

#### 구현 설명

1. **@Catch 데코레이터**: `ForbiddenException`만 처리하도록 지정
2. **ArgumentsHost 사용**: HTTP 컨텍스트로 전환하여 Request/Response 접근
3. **상태 코드**: `exception.getStatus()`로 예외의 HTTP 상태 코드 가져오기
4. **로깅**: 콘솔에 예외 정보 로깅
5. **응답 형식**: 일관된 형식의 JSON 응답 반환

#### 응답 형식

```json
{
  "statusCode": 403,
  "timestamp": "2026-01-14T15:30:00.000Z",
  "path": "/movie",
  "message": "권한이 없습니다!!!"
}
```

### 2.2 전역 Filter 등록

`app.module.ts`에서 전역 Filter로 등록합니다.

```typescript:src/app.module.ts
import { APP_FILTER } from '@nestjs/core';
import { ForbiddenExceptionFilter } from './common/filter/forbidden.filter';

@Module({
  // ... imports
  providers: [
    // ... other providers
    {
      provide: APP_FILTER,
      useClass: ForbiddenExceptionFilter,
    },
  ],
})
export class AppModule implements NestModule {
  // ...
}
```

#### APP_FILTER 사용

- `APP_FILTER` 토큰을 사용하여 전역 Filter 등록
- 모든 라우트에서 발생하는 해당 예외를 자동으로 처리
- 여러 Filter를 등록하면 예외 타입에 맞는 Filter가 실행됨

### 2.3 사용 시나리오

`ForbiddenException`이 발생하는 경우:

1. **RBAC Guard에서 권한 부족**: 사용자가 필요한 역할을 가지지 않음
2. **수동으로 예외 발생**: Service나 Controller에서 `throw new ForbiddenException()`

모든 경우에 `ForbiddenExceptionFilter`가 자동으로 처리하여 일관된 응답을 반환합니다.

---

## 3. Query Failed Exception Filter 구현하기

### 3.1 QueryFailedFilter 생성

TypeORM의 `QueryFailedError`를 처리하는 Filter를 생성합니다.

```typescript:src/common/filter/query-failed.filter.ts
import { ArgumentsHost, Catch, ExceptionFilter } from '@nestjs/common';
import { QueryFailedError } from 'typeorm';

@Catch(QueryFailedError)
export class QueryFailedFilter implements ExceptionFilter {
  catch(exception: QueryFailedError, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();

    const status = 400;

    let message = '쿼리 실패!!!';

    if (exception.message.includes('duplicate key value')) {
      message = '중복된 값이 있습니다!!!';
    }

    response.status(status).json({
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      message,
    });
  }
}
```

#### 구현 설명

1. **@Catch 데코레이터**: `QueryFailedError`만 처리하도록 지정
2. **에러 메시지 분석**: 예외 메시지를 분석하여 사용자 친화적인 메시지 생성
3. **중복 키 처리**: `duplicate key value` 메시지가 포함된 경우 특별한 메시지 반환
4. **일관된 응답**: 다른 Filter와 동일한 형식의 응답 반환

#### 에러 메시지 처리

- **기본 메시지**: `'쿼리 실패!!!'`
- **중복 키**: `'중복된 값이 있습니다!!!'`
- 확장 가능: 다른 에러 타입에 따라 메시지 추가 가능

### 3.2 전역 Filter 등록

`app.module.ts`에서 전역 Filter로 등록합니다.

```typescript:src/app.module.ts
import { APP_FILTER } from '@nestjs/core';
import { QueryFailedFilter } from './common/filter/query-failed.filter';

@Module({
  // ... imports
  providers: [
    // ... other providers
    {
      provide: APP_FILTER,
      useClass: QueryFailedFilter,
    },
  ],
})
export class AppModule implements NestModule {
  // ...
}
```

### 3.3 사용 시나리오

`QueryFailedError`가 발생하는 경우:

1. **중복 키 제약 위반**: UNIQUE 제약 조건 위반
2. **외래 키 제약 위반**: FOREIGN KEY 제약 조건 위반
3. **NOT NULL 제약 위반**: 필수 필드에 NULL 값 삽입
4. **기타 데이터베이스 오류**: SQL 문법 오류 등

모든 경우에 `QueryFailedFilter`가 자동으로 처리하여 사용자 친화적인 메시지를 반환합니다.

#### 예시: 중복 키 오류

```typescript
// Service에서 중복된 이메일로 사용자 생성 시도
await this.userRepository.save({ email: 'existing@example.com' });

// QueryFailedError 발생
// QueryFailedFilter가 자동으로 처리
// 응답: { statusCode: 400, message: '중복된 값이 있습니다!!!', ... }
```

### 3.4 에러 메시지 확장

더 많은 에러 타입을 처리하려면 메시지 로직을 확장할 수 있습니다:

```typescript
let message = '쿼리 실패!!!';

if (exception.message.includes('duplicate key value')) {
  message = '중복된 값이 있습니다!!!';
} else if (exception.message.includes('foreign key constraint')) {
  message = '관련된 데이터가 존재합니다!!!';
} else if (exception.message.includes('not null constraint')) {
  message = '필수 값이 누락되었습니다!!!';
}
```

---

## 정리

### Exception Filter의 핵심 개념

1. **전역 예외 처리**: 애플리케이션 전체의 예외를 중앙에서 처리
2. **일관된 응답 형식**: 모든 예외에 대해 동일한 형식의 응답 제공
3. **예외별 커스텀 처리**: `@Catch()` 데코레이터로 특정 예외 타입 처리

### 구현 요약

1. **ForbiddenExceptionFilter**: 권한 관련 예외 처리
2. **QueryFailedFilter**: 데이터베이스 쿼리 오류 처리
3. **전역 등록**: `APP_FILTER`로 모든 라우트에 적용

### Exception Filter의 장점

#### 1. 예외 처리 코드 중복 제거

**기존 방식:**
```typescript
// 각 Controller/Service에서 개별 처리
try {
  // 비즈니스 로직
} catch (e) {
  if (e instanceof ForbiddenException) {
    return res.status(403).json({ message: '권한 없음' });
  }
  // ...
}
```

**Filter 방식:**
```typescript
// Filter에서 전역 처리
@Catch(ForbiddenException)
export class ForbiddenExceptionFilter {
  // 모든 ForbiddenException 자동 처리
}
```

#### 2. 일관된 응답 형식

모든 예외에 대해 동일한 형식의 응답을 제공하여 클라이언트가 일관되게 처리할 수 있습니다:

```json
{
  "statusCode": 400,
  "timestamp": "2026-01-14T15:30:00.000Z",
  "path": "/movie",
  "message": "에러 메시지"
}
```

#### 3. 예외 처리 로직 분리

비즈니스 로직과 예외 처리를 분리하여 코드 가독성과 유지보수성을 향상시킵니다.

### Exception Filter vs 다른 컴포넌트

| 구분 | Middleware | Guard | Interceptor | Pipe | Exception Filter |
|------|-----------|-------|-------------|------|------------------|
| **실행 순서** | 가장 먼저 | Middleware 이후 | Guard 이후 | Interceptor 이후 | 예외 발생 시 |
| **주요 역할** | 요청 전처리 | 인가 확인 | 요청/응답 변환 | 데이터 변환/검증 | 예외 처리 |
| **실행 조건** | 항상 | 요청 시 | 요청 시 | 요청 시 | 예외 발생 시 |

### 예외 처리 흐름

```
1. 요청 처리 중 예외 발생
   ↓
2. 예외 타입 확인
   ↓
3. 해당 예외를 처리하는 Filter 찾기
   ↓
4. Filter의 catch() 메서드 실행
   ↓
5. 일관된 형식의 에러 응답 반환
```

### 주의사항

1. **Filter 순서**: 여러 Filter가 등록된 경우 예외 타입에 맞는 Filter가 실행됨
2. **예외 전파**: Filter에서 예외를 다시 throw하면 다음 Filter로 전파됨
3. **로깅**: 예외 발생 시 로깅하여 모니터링 및 디버깅에 활용

Exception Filter는 예외 처리를 중앙화하여 코드 중복을 줄이고 일관된 사용자 경험을 제공하는 핵심 컴포넌트입니다.
