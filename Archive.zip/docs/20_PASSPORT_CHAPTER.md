# Ch 4. Passport

## 목차
1. [Passport 이론](#1-passport-이론)
2. [Local Strategy 적용하기](#2-local-strategy-적용하기)

---

## 1. Passport 이론

### 1.1 Passport란?

**Passport**는 Node.js용 인증 미들웨어입니다. Express 애플리케이션에서 사용자 인증을 간단하고 모듈화된 방식으로 처리할 수 있게 해줍니다.

#### 주요 특징
- **전략(Strategy) 기반 인증**: 다양한 인증 방식을 플러그인처럼 사용 가능
- **모듈화**: 각 인증 방식이 독립적인 전략으로 구현됨
- **유연성**: 여러 전략을 동시에 사용 가능
- **표준화**: 일관된 인터페이스로 인증 로직 관리

### 1.2 NestJS에서의 Passport

NestJS는 `@nestjs/passport` 패키지를 통해 Passport를 통합했습니다.

#### 설치된 패키지
```json
"@nestjs/passport": "^11.0.5",
"passport": "^0.7.0",
"passport-local": "^1.0.0",
"passport-jwt": "^4.0.1"
```

#### NestJS Passport의 구조
1. **Strategy**: 인증 로직을 담당하는 클래스
2. **Guard**: 라우트 보호를 담당하는 가드
3. **Module**: Strategy를 providers에 등록

### 1.3 Passport 전략(Strategy)의 동작 원리

#### 전략 패턴(Strategy Pattern)
- 다양한 인증 방식을 동일한 인터페이스로 처리
- 각 전략은 독립적으로 구현되고 교체 가능

#### Passport 전략의 흐름
```
1. 요청이 들어옴
2. Guard가 전략을 실행
3. Strategy의 validate 메서드 호출
4. validate가 성공하면 user 객체 반환
5. user 객체가 Request 객체에 자동으로 추가됨 (req.user)
```

### 1.4 주요 Passport 전략

#### Local Strategy
- **용도**: 사용자명과 비밀번호 기반 인증
- **사용 시나리오**: 로그인 폼, API 키 인증
- **패키지**: `passport-local`

#### JWT Strategy
- **용도**: JWT 토큰 기반 인증
- **사용 시나리오**: RESTful API, SPA 인증
- **패키지**: `passport-jwt`

#### 기타 전략
- OAuth (Google, Facebook, GitHub 등)
- OpenID Connect
- SAML
- 등등...

### 1.5 Guard와 Strategy의 관계

#### AuthGuard
- NestJS의 Guard는 Passport 전략을 실행하는 역할
- `@UseGuards(AuthGuard('strategy-name'))` 형태로 사용
- 전략 이름은 Strategy 클래스에서 자동으로 결정됨

#### 전략 이름 규칙
- `LocalStrategy` → `'local'`
- `JwtStrategy` → `'jwt'`
- 전략 이름은 Strategy 클래스의 이름에서 `Strategy`를 제거하고 소문자로 변환

---

## 2. Local Strategy 적용하기

### 2.1 Local Strategy 구현

프로젝트에서 Local Strategy를 구현한 파일을 확인해보겠습니다.

#### LocalStrategy 클래스

```1:31:src/auth/strategy/local.strategy.ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthGuard, PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-local';
import { AuthService } from '../auth.service';

export class LocalAuthGuard extends AuthGuard('local') {}

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly authService: AuthService) {
    super({
      usernameField: 'email',
    });
  }

  /**
   * LocalStrategy 클래스의 validate 메서드
   *
   * validate : username, password를 받아서 user 객체를 반환
   * return -> Request()
   */
  async validate(email: string, password: string) {
    const user = await this.authService.authenticate(email, password);

    if (!user) {
      throw new UnauthorizedException('Invalid username or password');
    }

    return user;
  }
}
```

#### 코드 설명

1. **PassportStrategy 상속**
   ```typescript
   export class LocalStrategy extends PassportStrategy(Strategy)
   ```
   - `PassportStrategy`는 NestJS에서 제공하는 기본 클래스
   - `Strategy`는 `passport-local`에서 가져온 Local 전략

2. **생성자에서 설정**
   ```typescript
   super({
     usernameField: 'email',
   });
   ```
   - `usernameField: 'email'`: 기본값인 `username` 대신 `email` 필드를 사용
   - 이메일 기반 로그인을 위해 설정

3. **validate 메서드**
   ```typescript
   async validate(email: string, password: string) {
     const user = await this.authService.authenticate(email, password);
     // ...
     return user;
   }
   ```
   - **역할**: 인증 로직을 처리하는 핵심 메서드
   - **매개변수**: `email`, `password` (usernameField 설정에 따라 변경됨)
   - **반환값**: 인증된 사용자 객체 (이 객체가 `req.user`에 자동으로 추가됨)
   - **에러 처리**: 인증 실패 시 `UnauthorizedException` 발생

### 2.2 LocalAuthGuard 구현

```typescript
export class LocalAuthGuard extends AuthGuard('local') {}
```

- `AuthGuard('local')`: `'local'` 전략을 사용하는 Guard
- Guard 이름은 `LocalStrategy`에서 자동으로 `'local'`로 결정됨
- 이 Guard를 컨트롤러에 적용하면 Local Strategy가 실행됨

### 2.3 AuthModule에 Strategy 등록

```1:16:src/auth/auth.module.ts
import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { JwtModule } from '@nestjs/jwt';
import { LocalStrategy } from './strategy/local.strategy';
import { JwtStrategy } from './strategy/jwt.strategy';

@Module({
  imports: [TypeOrmModule.forFeature([User]), JwtModule.register({})],
  controllers: [AuthController],
  providers: [AuthService, LocalStrategy, JwtStrategy],
  exports: [AuthService],
})
export class AuthModule {}
```

#### 중요 사항
- `LocalStrategy`를 `providers` 배열에 등록해야 함
- NestJS의 DI 시스템이 Strategy를 인스턴스화하고 주입함
- `AuthService`를 주입받기 위해 `LocalStrategy`가 `@Injectable()` 데코레이터를 가져야 함

### 2.4 컨트롤러에서 Guard 사용

```28:35:src/auth/auth.controller.ts
  @UseGuards(LocalAuthGuard)
  @Post('login/passport')
  async loginUserPassport(@Request() req) {
    return {
      refreshToken: await this.authService.issueToken(req.user, true),
      accessToken: await this.authService.issueToken(req.user, false),
    };
  }
```

#### 동작 과정

1. **요청이 들어옴**
   ```json
   POST /auth/login/passport
   {
     "email": "test@gmail.com",
     "password": "qweqweqwe"
   }
   ```

2. **LocalAuthGuard 실행**
   - `LocalAuthGuard`가 요청을 가로챔
   - `LocalStrategy`의 `validate` 메서드 호출

3. **validate 메서드 실행**
   ```typescript
   async validate(email: string, password: string) {
     const user = await this.authService.authenticate(email, password);
     return user; // 이 user가 req.user에 자동으로 추가됨
   }
   ```

4. **인증 성공 시**
   - `validate`가 반환한 `user` 객체가 `req.user`에 자동으로 추가됨
   - 컨트롤러 메서드가 실행됨
   - `req.user`를 통해 인증된 사용자 정보에 접근 가능

5. **인증 실패 시**
   - `UnauthorizedException`이 발생
   - 401 Unauthorized 응답 반환

### 2.5 기존 로그인 방식과의 비교

#### 기존 방식 (Basic Token)
```23:26:src/auth/auth.controller.ts
  @Post('login')
  loginUser(@Headers('authorization') token: string) {
    return this.authService.login(token);
  }
```

- 수동으로 토큰 파싱
- 수동으로 인증 로직 호출
- 코드가 길고 반복적

#### Passport 방식
```28:35:src/auth/auth.controller.ts
  @UseGuards(LocalAuthGuard)
  @Post('login/passport')
  async loginUserPassport(@Request() req) {
    return {
      refreshToken: await this.authService.issueToken(req.user, true),
      accessToken: await this.authService.issueToken(req.user, false),
    };
  }
```

- **장점**:
  - 코드가 간결함
  - 인증 로직이 Strategy로 분리되어 재사용 가능
  - `req.user`에 자동으로 사용자 정보가 추가됨
  - 여러 엔드포인트에서 동일한 Guard 재사용 가능

### 2.6 AuthService의 authenticate 메서드

LocalStrategy에서 사용하는 `authenticate` 메서드를 확인해보겠습니다.

```63:77:src/auth/auth.service.ts
  async authenticate(email: string, password: string) {
    const user = await this.userRepository.findOne({ where: { email } });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    const passOk = await bcrypt.compare(password, user.password);

    if (!passOk) {
      throw new BadRequestException('Invalid password');
    }

    return user;
  }
```

#### 동작 과정
1. 이메일로 사용자 조회
2. 사용자가 없으면 예외 발생
3. bcrypt로 비밀번호 비교
4. 비밀번호가 일치하지 않으면 예외 발생
5. 인증 성공 시 사용자 객체 반환

### 2.7 JWT Strategy도 함께 구현

프로젝트에는 JWT Strategy도 구현되어 있습니다.

#### JwtStrategy 클래스

```1:21:src/auth/strategy/jwt.strategy.ts
import { AuthGuard, PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

export class JwtAuthGuard extends AuthGuard('jwt') {}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get<string>('ACCESS_TOKEN_SECRET')!,
    });
  }

  validate(payload: any) {
    return payload;
  }
}
```

#### JWT Strategy 특징
- **토큰 추출**: `ExtractJwt.fromAuthHeaderAsBearerToken()` - Authorization 헤더에서 Bearer 토큰 추출
- **만료 검증**: `ignoreExpiration: false` - 만료된 토큰 거부
- **시크릿 키**: 환경 변수에서 가져온 `ACCESS_TOKEN_SECRET` 사용
- **validate**: JWT 페이로드를 그대로 반환 (이미 검증됨)

#### JWT Guard 사용 예시

```37:41:src/auth/auth.controller.ts
  @UseGuards(JwtAuthGuard)
  @Get('private')
  private(@Request() req) {
    return req.user;
  }
```

- JWT 토큰이 유효한 경우에만 접근 가능한 보호된 엔드포인트
- `req.user`에는 JWT 페이로드가 들어있음

---

## 3. 정리

### 3.1 Passport의 장점

1. **모듈화**: 인증 로직이 Strategy로 분리되어 재사용 가능
2. **표준화**: 일관된 인터페이스로 다양한 인증 방식 지원
3. **간결성**: Guard 하나로 인증 처리
4. **유연성**: 여러 전략을 동시에 사용 가능

### 3.2 프로젝트에서의 활용

- **Local Strategy**: 이메일/비밀번호 기반 로그인
- **JWT Strategy**: 토큰 기반 인증으로 보호된 엔드포인트 접근
- **확장 가능**: OAuth, SAML 등 다른 전략도 쉽게 추가 가능

### 3.3 다음 단계

- JWT Strategy를 활용한 보호된 엔드포인트 구현
- Role 기반 접근 제어 (RBAC)
- Refresh Token 갱신 로직
- OAuth 전략 추가 (Google, GitHub 등)

---

## 참고 자료

- [NestJS Passport 공식 문서](https://docs.nestjs.com/security/authentication)
- [Passport.js 공식 문서](http://www.passportjs.org/)
- [passport-local 문서](https://github.com/jaredhanson/passport-local)
- [passport-jwt 문서](https://github.com/mikenicholson/passport-jwt)
