# Ch 37. Integration Test (통합 테스트)

## 목차
1. [통합 테스트 개요](#통합-테스트-개요)
2. [통합 테스트 설정](#통합-테스트-설정)
3. [통합 테스트 파일 구조](#통합-테스트-파일-구조)
4. [TypeORM 통합 테스트 설정](#typeorm-통합-테스트-설정)
5. [테스트 데이터 준비](#테스트-데이터-준비)
6. [QueryRunner 사용하기](#queryrunner-사용하기)
7. [실제 통합 테스트 예제](#실제-통합-테스트-예제)
8. [통합 테스트 실행](#통합-테스트-실행)

---

## 통합 테스트 개요

### 통합 테스트란?
통합 테스트(Integration Test)는 여러 컴포넌트를 함께 테스트하여 실제 환경과 유사한 상황에서 시스템이 올바르게 작동하는지 확인하는 테스트입니다.

### 단위 테스트 vs 통합 테스트

| 구분 | 단위 테스트 | 통합 테스트 |
|------|------------|------------|
| **목적** | 개별 함수/메서드 검증 | 여러 컴포넌트 간 상호작용 검증 |
| **의존성** | Mock 사용 | 실제 의존성 사용 |
| **데이터베이스** | Mock Repository | 실제 데이터베이스 (SQLite in-memory) |
| **속도** | 빠름 | 상대적으로 느림 |
| **파일명** | `*.spec.ts` | `*.integration.spec.ts` |

### 프로젝트에서의 통합 테스트
- **파일명 규칙**: `*.integration.spec.ts`
- **실행 명령어**: `pnpm test:integration`
- **데이터베이스**: SQLite in-memory (`:memory:`)
- **테스트 대상**: Service 레이어의 실제 로직 검증

---

## 통합 테스트 설정

### 1. package.json 설정

```json
{
  "scripts": {
    "test:integration": "jest --testRegex='.*\\integration.spec\\.ts$'"
  },
  "devDependencies": {
    "sqlite3": "^5.1.7",
    "@nestjs/testing": "^11.0.1"
  }
}
```

### 2. 필요한 패키지 설치

```bash
# SQLite 드라이버 설치
pnpm add -D sqlite3

# 빌드 (네이티브 모듈)
cd node_modules/.pnpm/sqlite3@*/node_modules/sqlite3
npm run install
```

**주의**: `sqlite3`는 네이티브 모듈이므로 설치 후 빌드가 필요합니다.

---

## 통합 테스트 파일 구조

### 기본 구조

```typescript
import { Test, TestingModule } from '@nestjs/testing';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { CacheModule, CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { ConfigModule } from '@nestjs/config';

describe('ServiceName - Integration Test', () => {
  let service: ServiceName;
  let dataSource: DataSource;
  let cacheManager: Cache;

  // 테스트 데이터
  let users: User[];
  let directors: Director[];
  let genres: Genre[];

  beforeAll(async () => {
    // 모듈 설정
  });

  afterAll(async () => {
    // 정리 작업
  });

  beforeEach(async () => {
    // 각 테스트 전 데이터 준비
  });

  describe('methodName', () => {
    it('should ...', async () => {
      // 테스트 로직
    });
  });
});
```

---

## TypeORM 통합 테스트 설정

### SQLite In-Memory 데이터베이스 설정

```typescript
beforeAll(async () => {
  const module: TestingModule = await Test.createTestingModule({
    imports: [
      // 캐시 모듈
      CacheModule.register(),
      
      // TypeORM 설정 - SQLite in-memory
      TypeOrmModule.forRoot({
        type: 'sqlite',
        database: ':memory:',        // 메모리 데이터베이스
        dropSchema: true,            // 스키마 삭제
        entities: [                  // 엔티티 등록
          Movie,
          MovieDetail,
          Director,
          Genre,
          User,
          MovieUserLike,
        ],
        synchronize: true,           // 자동 스키마 동기화
        logging: false,              // 로깅 비활성화
      }),
      
      // Repository 등록
      TypeOrmModule.forFeature([
        Movie,
        MovieDetail,
        Director,
        Genre,
        User,
        MovieUserLike,
      ]),
      
      // Config 모듈
      ConfigModule.forRoot(),
    ],
    providers: [
      MovieService,
      CommonService,
    ],
  }).compile();

  // 서비스 및 의존성 주입
  service = module.get<MovieService>(MovieService);
  cacheManager = module.get<Cache>(CACHE_MANAGER);
  dataSource = module.get<DataSource>(DataSource);
});
```

### 주요 설정 설명

| 설정 | 설명 |
|------|------|
| `type: 'sqlite'` | SQLite 데이터베이스 사용 |
| `database: ':memory:'` | 메모리 내 데이터베이스 (테스트 후 자동 삭제) |
| `dropSchema: true` | 테스트 시작 시 스키마 삭제 |
| `synchronize: true` | 엔티티 변경사항 자동 반영 |
| `logging: false` | SQL 쿼리 로깅 비활성화 (테스트 속도 향상) |

### 정리 작업

```typescript
afterAll(async () => {
  await dataSource.destroy();  // 데이터베이스 연결 종료
});
```

---

## 테스트 데이터 준비

### beforeEach에서 데이터 준비

```typescript
beforeEach(async () => {
  // Repository 가져오기
  const movieRepository = dataSource.getRepository(Movie);
  const movieDetailRepository = dataSource.getRepository(MovieDetail);
  const directorRepository = dataSource.getRepository(Director);
  const genreRepository = dataSource.getRepository(Genre);
  const userRepository = dataSource.getRepository(User);

  // 사용자 데이터 생성
  users = [1, 2].map((x) =>
    userRepository.create({
      id: x,
      email: `${x}@test.com`,
      password: `123123`,
    }),
  );
  await userRepository.save(users);

  // 감독 데이터 생성
  directors = [1, 2].map((x) =>
    directorRepository.create({
      id: x,
      dob: new Date('1992-11-23'),
      nationality: 'South Korea',
      name: `Director Name ${x}`,
    }),
  );
  await directorRepository.save(directors);

  // 장르 데이터 생성
  genres = [1, 2].map((x) =>
    genreRepository.create({
      id: x,
      name: `Genre ${x}`,
    }),
  );
  await genreRepository.save(genres);

  // 영화 데이터 생성
  movies = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((x) =>
    movieRepository.create({
      id: x,
      title: `Movie ${x}`,
      creator: users[0],
      genres: genres,
      likeCount: 0,
      dislikeCount: 0,
      detail: movieDetailRepository.create({
        detail: `Movie Detail ${x}`,
      }),
      movieFilePath: 'movies/movie1.mp4',
      director: directors[0],
      createdAt: new Date(`2023-9-${x}`),
    }),
  );
  await movieRepository.save(movies);
});
```

### 데이터 준비 패턴

1. **Repository 가져오기**: `dataSource.getRepository(Entity)`
2. **엔티티 생성**: `repository.create(data)`
3. **데이터 저장**: `repository.save(entities)`
4. **관계 설정**: 엔티티 생성 시 관계 객체 직접 할당

---

## QueryRunner 사용하기

### QueryRunner란?
QueryRunner는 트랜잭션을 수동으로 관리할 수 있게 해주는 TypeORM의 기능입니다.

### 통합 테스트에서 QueryRunner 사용

#### ❌ 잘못된 사용법

```typescript
// QueryRunner를 생성만 하고 연결하지 않음
const result = await service.create(
  createMovieDto,
  dataSource.createQueryRunner(),  // ❌ manager가 undefined
  users[0].id,
);
```

#### ✅ 올바른 사용법

```typescript
it('should create movie correctly', async () => {
  const createMovieDto: CreateMovieDto = {
    title: 'Test Movie',
    detail: 'A Test Movie Detail',
    directorId: directors[0].id,
    genreIds: genres.map((x) => x.id),
    movieFileName: 'test.mp4',
  };

  // 1. QueryRunner 생성
  const qr = dataSource.createQueryRunner();
  
  // 2. 데이터베이스 연결
  await qr.connect();
  
  // 3. 트랜잭션 시작
  await qr.startTransaction();

  try {
    // 4. 서비스 메서드 호출
    const result = await service.create(
      createMovieDto,
      qr,              // 연결된 QueryRunner 전달
      users[0].id,
    );

    // 5. 검증
    expect(result.title).toBe(createMovieDto.title);
    expect(result.director.id).toBe(createMovieDto.directorId);
    expect(result.genres.map((g) => g.id)).toEqual(genres.map((g) => g.id));
    expect(result.detail.detail).toBe(createMovieDto.detail);

    // 6. 트랜잭션 커밋
    await qr.commitTransaction();
  } catch (error) {
    // 7. 에러 발생 시 롤백
    await qr.rollbackTransaction();
    throw error;
  } finally {
    // 8. 리소스 해제
    await qr.release();
  }
});
```

### QueryRunner 사용 순서

1. **생성**: `dataSource.createQueryRunner()`
2. **연결**: `await qr.connect()` ⚠️ **필수!**
3. **트랜잭션 시작**: `await qr.startTransaction()`
4. **사용**: 서비스 메서드에 QueryRunner 전달
5. **커밋**: `await qr.commitTransaction()` (성공 시)
6. **롤백**: `await qr.rollbackTransaction()` (에러 시)
7. **해제**: `await qr.release()` (항상 실행)

### TransactionInterceptor와의 차이

**프로덕션 코드 (Controller)**:
```typescript
@Post()
@UseInterceptors(TransactionInterceptor)  // 인터셉터가 QueryRunner 관리
createMovie(
  @Body() body: CreateMovieDto,
  @QueryRunner() queryRunner: QueryRunner,  // 인터셉터가 자동 연결
  @UserId() userId: number,
) {
  return this.movieService.create(body, queryRunner, userId);
}
```

**통합 테스트**:
- 인터셉터가 없으므로 **수동으로** QueryRunner를 연결해야 함
- `connect()`와 `startTransaction()` 필수

---

## 실제 통합 테스트 예제

### 1. findRecent 테스트

```typescript
describe('findRecent', () => {
  it('should return recent movies', async () => {
    const result = (await service.findRecent()) as Movie[];

    // 최신순으로 정렬
    const sortedResult = [...movies];
    sortedResult.sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
    const sortedResultIds = sortedResult.slice(0, 10).map((x) => x.id);

    expect(result).toHaveLength(10);
    expect(result.map((x) => x.id)).toEqual(sortedResultIds);
  });

  it('should cache recent movies', async () => {
    const result = (await service.findRecent()) as Movie[];

    const cachedData = await cacheManager.get('MOVIE_RECENT');

    expect(cachedData).toEqual(result);
  });
});
```

### 2. findAll 테스트

```typescript
describe('findAll', () => {
  it('should return movies with correct titles', async () => {
    const dto = {
      title: 'Movie 15',
      order: ['createdAt_DESC'],
      take: 10,
    };

    const result = await service.findAll(dto);

    expect(result.data).toHaveLength(1);
    expect(result.data[0].title).toBe(dto.title);
    expect(result.data[0]).not.toHaveProperty('likeStatus');
  });

  it('should return likeStatus if userId is provided', async () => {
    const dto = { order: ['createdAt_ASC'], take: 10 };

    const result = await service.findAll(dto, users[0].id);

    expect(result.data).toHaveLength(10);
    expect(result.data[0]).toHaveProperty('likeStatus');
  });
});
```

### 3. findOne 테스트

```typescript
describe('findOne', () => {
  it('should return movie correctly', async () => {
    const movieId = movies[0].id;

    const result = await service.findOne(movieId);

    expect(result.id).toBe(movieId);
  });

  it('should throw NotFoundException if movie does not exist', async () => {
    await expect(service.findOne(999999999999)).rejects.toThrow(
      NotFoundException,
    );
  });
});
```

### 4. create 테스트 (QueryRunner 사용)

```typescript
describe('create', () => {
  beforeEach(() => {
    // 파일 시스템 작업 Mock
    jest.spyOn(service, 'renameMovieFile').mockResolvedValue();
  });

  it('should create movie correctly', async () => {
    const createMovieDto: CreateMovieDto = {
      title: 'Test Movie',
      detail: 'A Test Movie Detail',
      directorId: directors[0].id,
      genreIds: genres.map((x) => x.id),
      movieFileName: 'test.mp4',
    };

    const qr = dataSource.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();

    try {
      const result = await service.create(
        createMovieDto,
        qr,
        users[0].id,
      );

      expect(result.title).toBe(createMovieDto.title);
      expect(result.director.id).toBe(createMovieDto.directorId);
      expect(result.genres.map((g) => g.id)).toEqual(genres.map((g) => g.id));
      expect(result.detail.detail).toBe(createMovieDto.detail);

      await qr.commitTransaction();
    } catch (error) {
      await qr.rollbackTransaction();
      throw error;
    } finally {
      await qr.release();
    }
  });
});
```

### 5. update 테스트

```typescript
describe('update', () => {
  it('should update movie correctly', async () => {
    const movieId = movies[0].id;

    const updateMovieDto: UpdateMovieDto = {
      title: 'Changed Title',
      detail: 'Changed Detail',
      directorId: directors[1].id,
      genreIds: [genres[0].id],
    };

    const result = await service.update(movieId, updateMovieDto);

    expect(result.title).toBe(updateMovieDto.title);
    expect(result.detail.detail).toBe(updateMovieDto.detail);
    expect(result.director.id).toBe(updateMovieDto.directorId);
    expect(result.genres.map((x) => x.id)).toEqual(updateMovieDto.genreIds);
  });

  it('should throw error if movie does not exist', async () => {
    const updateMovieDto: UpdateMovieDto = {
      title: 'Change',
    };

    await expect(service.update(9999999, updateMovieDto)).rejects.toThrow(
      NotFoundException,
    );
  });
});
```

### 6. toggleMovieLike 테스트

```typescript
describe('toggleMovieLike', () => {
  it('should create like correctly', async () => {
    const userId = users[0].id;
    const movieId = movies[0].id;

    const result = await service.toggleMovieLike(movieId, userId, true);

    expect(result).toEqual({ isLike: true });
  });

  it('should toggle like correctly', async () => {
    const userId = users[0].id;
    const movieId = movies[0].id;

    // 첫 번째 호출: 좋아요 생성
    await service.toggleMovieLike(movieId, userId, true);
    
    // 두 번째 호출: 좋아요 취소
    const result = await service.toggleMovieLike(movieId, userId, true);

    expect(result.isLike).toBeNull();
  });
});
```

---

## 통합 테스트 실행

### 실행 명령어

```bash
# 통합 테스트 실행
pnpm test:integration

# 특정 파일만 실행
pnpm test:integration -- src/movie/movie.service.integration.spec.ts

# Watch 모드
pnpm test:integration -- --watch
```

### 실행 결과 예시

```
PASS src/movie/movie.service.integration.spec.ts
  MovieService - Integration Test
    ✓ should be defined (19 ms)
    findRecent
      ✓ should return recent movies (11 ms)
      ✓ should cache recent movies (8 ms)
    findAll
      ✓ should return movies with correct titles (10 ms)
      ✓ should return likeStatus if userId is provided (11 ms)
    findOne
      ✓ should return movie correctly (8 ms)
      ✓ should throw NotFoundException if movie does not exist (15 ms)
    create
      ✓ should create movie correctly (11 ms)
    update
      ✓ should update movie correctly (22 ms)
      ✓ should throw error if movie does not exist (7 ms)
    remove
      ✓ should remove movie correctly (8 ms)
      ✓ should throw error if movie does not exist (7 ms)
    toggleMovieLike
      ✓ should create like correctly (8 ms)
      ✓ should create dislike correctly (9 ms)
      ✓ should toggle like correctly (8 ms)
      ✓ should toggle dislike correctly (9 ms)

Test Suites: 1 passed, 1 total
Tests:       16 passed, 16 total
```

---

## 주의사항 및 Best Practices

### 1. QueryRunner 연결 필수
- `dataSource.createQueryRunner()`만으로는 부족
- 반드시 `await qr.connect()` 호출 필요
- `qr.manager`가 undefined인 경우 연결 누락 확인

### 2. 트랜잭션 관리
- 성공 시: `commitTransaction()`
- 실패 시: `rollbackTransaction()`
- 항상: `release()` (finally 블록에서)

### 3. 테스트 격리
- `beforeEach`에서 각 테스트 전 데이터 초기화
- `afterAll`에서 데이터베이스 연결 종료

### 4. Mock 사용
- 파일 시스템 작업은 Mock 처리
- 외부 API 호출은 Mock 처리
- 데이터베이스는 실제 사용 (통합 테스트의 목적)

### 5. 성능 고려
- `logging: false`로 설정하여 속도 향상
- 불필요한 데이터 생성 최소화
- `:memory:` 데이터베이스 사용

---

## 요약

### 통합 테스트 핵심 포인트

1. **파일명**: `*.integration.spec.ts`
2. **데이터베이스**: SQLite in-memory (`:memory:`)
3. **실행**: `pnpm test:integration`
4. **QueryRunner**: 반드시 `connect()` 호출 필요
5. **트랜잭션**: try-catch-finally로 관리
6. **데이터 준비**: `beforeEach`에서 초기화

### 단위 테스트와의 차이

| 항목 | 단위 테스트 | 통합 테스트 |
|------|-----------|------------|
| Repository | Mock | 실제 Repository |
| 데이터베이스 | 없음 | SQLite in-memory |
| QueryRunner | Mock | 실제 QueryRunner (연결 필요) |
| 파일 시스템 | Mock | Mock (필요 시) |
| 속도 | 빠름 | 상대적으로 느림 |

통합 테스트는 실제 환경과 유사하게 여러 컴포넌트를 함께 테스트하여 시스템의 신뢰성을 높입니다.
