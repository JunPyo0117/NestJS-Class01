# 인증 이론

## 목차
1. [Hashing 이론](#hashing-이론)
2. [Token 이론](#token-이론)

---

## Hashing 이론

### Hashing이란?

**Hashing(해싱)**은 원본 데이터를 고정된 길이의 문자열로 변환하는 일방향 암호화 과정입니다.

### Hashing 과정

```
원본 비밀번호 → Hashing 암호화 → Hashing된 비밀번호
"123123"      →   [Hashing]    →  "apzxlcbkjo31248sasdf"
```

**특징**:
- **일방향 함수(One-way Function)**: Hashing된 값에서 원본을 역으로 추출할 수 없습니다.
- **고정된 길이**: 입력 데이터의 크기와 관계없이 항상 같은 길이의 해시값을 생성합니다.
- **결정론적**: 같은 입력은 항상 같은 출력을 생성합니다.

### Hashing이 제공하는 보안

#### 시나리오: 다른 웹사이트에서 해킹된 비밀번호 사용 시도

**상황**:
1. **웹사이트 A**가 해킹되어 사용자 비밀번호가 노출됨
2. 해커가 노출된 비밀번호로 **웹사이트 B**에 로그인 시도

**웹사이트 A (해킹됨)**:
```
id | email                    | password
1  | jc@codefactory.ai       | a8fz&1a
2  | admin@codefactory.ai     | abcabc
```

**웹사이트 B (보안 적용)**:
- 해커가 `jc@codefactory.ai`와 `a8fz&1a`로 로그인 시도
- 웹사이트 B는 입력된 비밀번호를 Hashing: `a8fz&1a` → `zjuvjwqoi23jza`
- 데이터베이스에 저장된 해시값과 비교: `zjuvjwqoi23jza` ≠ `a8fz&1a`
- **결과**: 비밀번호 미스매치 → 로그인 실패

**보안 효과**:
- 웹사이트 A에서 노출된 원본 비밀번호로는 웹사이트 B에 로그인할 수 없습니다.
- 각 웹사이트가 다른 해시값을 사용하므로 한 곳이 해킹되어도 다른 곳은 안전합니다.

### Dictionary Attack (사전 공격)

#### Dictionary Attack이란?

**Dictionary Attack(사전 공격)**은 미리 계산된 해시값들을 저장한 사전을 사용하여 해시된 비밀번호를 역으로 찾는 공격 방법입니다.

#### 공격 과정

**1. 사전 생성**:
```
password      | hash
vqwerzza      | a8fz&1a
zvasedfqwe    | pasdovjq
...           | ...
수백만개의 미리 해싱된 값들
```

**2. 해킹된 데이터베이스**:
```
id | email                    | password (해시값)
1  | jo@codefactory.ai       | a8fz&1a
2  | admin@codefactory.ai     | abcabc
```

**3. 매칭**:
- 해킹된 데이터베이스의 해시값 `a8fz&1a`를 사전에서 검색
- 사전에서 `a8fz&1a`에 해당하는 원본 비밀번호 `vqwerzza` 발견
- 해커가 원본 비밀번호를 알아냄

**문제점**:
- 일반적인 비밀번호는 이미 사전에 포함되어 있을 가능성이 높습니다.
- 해시값만으로도 원본 비밀번호를 찾을 수 있습니다.

### Salt (소금)

#### Salt란?

**Salt(소금)**는 비밀번호를 Hashing하기 전에 추가하는 랜덤 문자열입니다.

#### Salt 사용 과정

```
원본 비밀번호 → Salt 추가 → Hashing 암호화 → Hashing된 비밀번호
"123123"      → "123123codefactory" → [Hashing] → "apzxlcbkjo31248sasdf"
```

**특징**:
- 각 사용자마다 고유한 Salt 값을 사용합니다.
- Salt 값은 데이터베이스에 저장됩니다.
- 비밀번호와 Salt를 결합한 후 Hashing합니다.

#### Salt의 보안 효과

**Salt 없이**:
- 같은 비밀번호 → 같은 해시값
- Dictionary Attack에 취약

**Salt 사용**:
- 같은 비밀번호라도 Salt가 다르면 → 다른 해시값
- Dictionary Attack 방어
- 각 사용자마다 고유한 해시값 생성

#### Salt 값까지 알아낸다면?

**문제**:
- Salt 값까지 노출되면 Dictionary Attack이 여전히 가능합니다.
- Salt + 비밀번호 조합에 대한 사전을 만들 수 있습니다.

**해결책**:
- **느린 Hashing 알고리즘 사용**: Bcrypt 등
- **강력한 비밀번호 정책**: 복잡한 비밀번호 사용 강제
- **추가 보안 계층**: 2FA (Two-Factor Authentication) 등

### Hashing Algorithms 비교

#### SHA256

**특징**:
- ✅ **해싱이 빠르다**: 빠른 처리 속도
- ❌ **Salt를 필요로 하지 않는다**: Salt 없이도 사용 가능하지만, 보안을 위해 Salt 사용 권장

**사용 시나리오**:
- 데이터 무결성 검증
- 빠른 해싱이 필요한 경우
- Salt를 별도로 관리하는 경우

#### Bcrypt

**특징**:
- ❌ **해싱이 느리다**: 의도적으로 느리게 설계됨 (공격 방어)
- ✅ **Salt를 요구한다**: 자동으로 Salt를 생성하고 관리

**사용 시나리오**:
- 비밀번호 저장 (권장)
- 보안이 중요한 인증 시스템
- Dictionary Attack 방어가 필요한 경우

#### 비교표

| 알고리즘 | 속도 | Salt | 비밀번호 저장 | Dictionary Attack 방어 |
|---------|------|------|--------------|----------------------|
| SHA256  | 빠름 | 선택적 | 권장하지 않음 | 약함 |
| Bcrypt  | 느림 | 필수 | 권장 | 강함 |

**권장사항**:
- **비밀번호 저장**: Bcrypt 사용
- **데이터 무결성**: SHA256 사용

---

## Token 이론

### 보안에 사용되는 토큰 종류

#### 1. Basic Token

**정의**: 사용자 정보를 보내는 데 사용되는 토큰

**특징**:
- `username:password`를 Base64로 인코딩한 값
- HTTP Basic Authentication에 사용
- 보안 수준이 낮음 (Base64는 암호화가 아님)

**사용 예시**:
```
Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=
```

#### 2. Access Token

**정의**: 프라이빗 리소스를 접근하는데 사용되는 토큰

**특징**:
- 인증된 사용자의 권한을 나타냄
- 짧은 수명 (보통 15분 ~ 1시간)
- 만료되면 Refresh Token으로 재발급

**사용 예시**:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

#### 3. Refresh Token

**정의**: Access Token을 재발급 받는데 사용되는 토큰

**특징**:
- 긴 수명 (보통 7일 ~ 30일)
- Access Token 재발급에만 사용
- 안전하게 저장해야 함 (HttpOnly Cookie 권장)

**사용 예시**:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 로그인 과정

#### 1단계: ID/Password 전송

**Client → API Server**:
```
[Header]
authorization: Basic $token
token → 'username:password' base64 encoded
```

**설명**:
- 사용자가 ID와 비밀번호를 입력
- `username:password`를 Base64로 인코딩
- `Authorization` 헤더에 `Basic` 스키마로 전송

#### 2단계: ID/Password 검증

**API Server 내부 처리**:
- Base64 디코딩하여 ID와 비밀번호 추출
- 데이터베이스에서 사용자 조회
- 비밀번호 해시값 비교
- 검증 성공 시 토큰 발급

#### 3단계: Access/Refresh Token 전송

**API Server → Client**:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**설명**:
- Access Token과 Refresh Token을 함께 발급
- Client는 두 토큰을 안전하게 저장

### Access Token 사용 과정

#### 1단계: Access Token으로 프라이빗 리소스 접근

**Client → API Server**:
```
[Header]
authorization: Bearer $accessToken
```

**설명**:
- Client가 보호된 리소스에 접근 요청
- `Authorization` 헤더에 `Bearer` 스키마로 Access Token 전송

#### 2단계: Signature 검증

**API Server 내부 처리**:
- Access Token의 Signature 검증
- Token이 유효하고 만료되지 않았는지 확인
- Token에서 사용자 정보 추출

#### 3단계: 리소스 응답

**API Server → Client**:
- 검증 성공 시 요청한 리소스 반환
- 검증 실패 시 `401 Unauthorized` 에러 반환

### Refresh Token 사용 과정

#### 1단계: Access Token 재발급 요청

**Client → API Server**:
```
[Header]
authorization: Bearer $refreshToken
```

**설명**:
- Access Token이 만료되었을 때
- Refresh Token을 사용하여 새로운 Access Token 요청

#### 2단계: Signature 검증

**API Server 내부 처리**:
- Refresh Token의 Signature 검증
- Refresh Token이 유효하고 만료되지 않았는지 확인

#### 3단계: Access Token 생성

**API Server 내부 처리**:
- 새로운 Access Token 생성
- 사용자 정보를 포함한 JWT 생성

#### 4단계: Access Token 전송

**API Server → Client**:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**설명**:
- 새로운 Access Token만 전송 (Refresh Token은 재발급하지 않음)
- Client는 새로운 Access Token으로 리소스 접근 재시도

### Access Token 만료시 재요청

#### 전체 흐름

1. **Access Token으로 프라이빗 리소스 접근**
   - Client가 Access Token으로 보호된 리소스 요청

2. **Signature 검증**
   - API Server가 Access Token 검증

3. **401 Unauthorized 에러**
   - Access Token이 만료되었거나 유효하지 않음
   - API Server가 `401 Unauthorized` 에러 반환

4. **Refresh Token으로 Access Token 재발급 시도**
   - Client가 Refresh Token을 사용하여 새로운 Access Token 요청

5. **Signature 검증**
   - API Server가 Refresh Token 검증

6. **Access Token 발급**
   - 새로운 Access Token 생성

7. **Access Token 전달**
   - 새로운 Access Token을 Client에 전송

8. **신규 Access Token으로 재요청**
   - Client가 새로운 Access Token으로 원래 요청 재시도

9. **Signature 검증**
   - API Server가 새로운 Access Token 검증

10. **프라이빗 리소스 반환**
    - 검증 성공 시 요청한 리소스 반환

**장점**:
- 사용자가 다시 로그인할 필요 없음
- 보안을 유지하면서 사용자 경험 향상

---

## JWT (JSON Web Token)

### JWT란?

**JWT(JSON Web Token)**는 인터넷 표준(RFC 7519)으로 정의된 인증 및 인가를 위한 토큰 형식입니다.

### JWT의 특징

1. **무상태(Stateless) 인증에 사용된다**
   - 서버에 세션을 저장할 필요 없음
   - 토큰 자체에 모든 정보가 포함됨

2. **인터넷으로 전송할만큼 작으며 인증에 필요한 모든 정보가 자체적으로 담겨있다**
   - 컴팩트한 크기
   - 자체 포함적(Self-contained)

3. **Header, Payload, Signature 세개의 구간으로 이루어져있다**
   - 구조가 명확하고 표준화됨

4. **표준화된 클레임이 존재한다 (iss, exp, sub, aud 등)**
   - `iss` (issuer): 토큰 발급자
   - `exp` (expiration): 토큰 만료 시간
   - `sub` (subject): 토큰 주제 (보통 사용자 ID)
   - `aud` (audience): 토큰 대상

5. **인증(Authentication), 인가(Authorization)에 효율적이다**
   - 빠른 검증
   - 분산 시스템에 적합

### JWT 구조

#### JWT 문자열 형식

```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkNvZGUgRmFjdG9yeSIsImlhdCI6MTUxNjIzOTAyMn0.cWDGmiL30VMO-9QZdutjOUaYs4loK97Mj2H9GnC396E
```

**구성**:
- 세 부분이 점(`.`)으로 구분됨
- `Header.Payload.Signature` 형식

#### 1. Header (헤더)

**인코딩된 값**:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9
```

**디코딩된 값**:
```json
{
  "alg": "HS256",
  "typ": "JWT"
}
```

**설명**:
- `alg`: 서명 알고리즘 (예: HS256, RS256)
- `typ`: 토큰 타입 (항상 "JWT")
- Base64Url로 인코딩됨

#### 2. Payload (페이로드)

**인코딩된 값**:
```
eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkNvZGUgRmFjdG9yeSIsImlhdCI6MTUxNjIzOTAyMn0
```

**디코딩된 값**:
```json
{
  "sub": "1234567890",
  "name": "Code Factory",
  "iat": 1516239022
}
```

**설명**:
- `sub`: 사용자 ID (subject)
- `name`: 사용자 이름
- `iat`: 토큰 발급 시간 (issued at)
- Base64Url로 인코딩됨
- **주의**: Payload는 암호화되지 않음 (Base64는 인코딩일 뿐)

#### 3. Signature (서명)

**값**:
```
cWDGmiL30VMO-9QZdutjOUaYs4loK97Mj2H9GnC396E
```

**생성 과정**:
```
HMACSHA256(
  base64UrlEncode(header) + "." +
  base64UrlEncode(payload),
  secret
)
```

**설명**:
- Header와 Payload를 점(`.`)으로 연결
- Secret 키를 사용하여 HMAC SHA256 알고리즘으로 서명 생성
- Secret 키는 서버에만 알려진 비밀값
- 토큰의 무결성을 보장

### JWT 검증 과정

1. **Header와 Payload 디코딩**
   - Base64Url 디코딩하여 JSON 객체 추출

2. **Signature 재계산**
   - Header와 Payload를 점으로 연결
   - Secret 키를 사용하여 HMAC SHA256 계산

3. **Signature 비교**
   - 재계산한 Signature와 토큰의 Signature 비교
   - 일치하면 토큰이 유효하고 변조되지 않았음을 확인

4. **만료 시간 확인**
   - Payload의 `exp` 클레임 확인
   - 현재 시간과 비교하여 만료 여부 확인

### JWT의 장점

1. **무상태(Stateless)**
   - 서버에 세션 저장 불필요
   - 확장성 향상

2. **자체 포함적(Self-contained)**
   - 토큰에 필요한 모든 정보 포함
   - 데이터베이스 조회 최소화

3. **표준화**
   - RFC 7519 표준
   - 다양한 언어와 프레임워크에서 지원

4. **분산 시스템에 적합**
   - 여러 서버에서 동일한 Secret으로 검증 가능
   - 마이크로서비스 아키텍처에 적합

### JWT의 단점

1. **토큰 크기**
   - 쿠키보다 큰 크기
   - 매 요청마다 전송되므로 네트워크 부하

2. **토큰 취소 어려움**
   - 만료 시간 전까지 토큰을 무효화하기 어려움
   - 블랙리스트 관리 필요

3. **Secret 키 관리**
   - Secret 키가 노출되면 모든 토큰이 위조 가능
   - 안전한 키 관리 필수

---

## 핵심 개념 정리

### Hashing

1. **일방향 함수**: 원본을 역으로 추출할 수 없음
2. **Salt 사용**: Dictionary Attack 방어
3. **Bcrypt 권장**: 비밀번호 저장 시 사용
4. **보안 효과**: 다른 웹사이트 해킹 시에도 안전

### Token

1. **Basic Token**: 사용자 정보 전송 (보안 수준 낮음)
2. **Access Token**: 프라이빗 리소스 접근 (짧은 수명)
3. **Refresh Token**: Access Token 재발급 (긴 수명)

### JWT

1. **구조**: Header.Payload.Signature
2. **무상태**: 서버에 세션 저장 불필요
3. **자체 포함적**: 토큰에 모든 정보 포함
4. **Signature 검증**: Secret 키로 무결성 보장

---

## 보안 모범 사례

### 비밀번호 저장

1. **Bcrypt 사용**: 느린 해싱 알고리즘
2. **Salt 자동 생성**: Bcrypt가 자동으로 처리
3. **강력한 비밀번호 정책**: 복잡한 비밀번호 강제

### 토큰 관리

1. **Access Token**: 짧은 수명 (15분 ~ 1시간)
2. **Refresh Token**: 긴 수명 (7일 ~ 30일)
3. **안전한 저장**: HttpOnly Cookie 사용 권장
4. **HTTPS 사용**: 토큰 전송 시 암호화

### JWT 사용

1. **Secret 키 보안**: 안전하게 관리
2. **만료 시간 설정**: `exp` 클레임 사용
3. **민감 정보 제외**: Payload에 비밀번호 등 저장 금지
4. **토큰 크기 최소화**: 필요한 정보만 포함

---

## 참고사항

1. **비밀번호는 절대 평문으로 저장하지 않음**: 항상 해싱하여 저장
2. **Salt는 사용자마다 고유하게**: 같은 Salt 사용 금지
3. **Bcrypt는 비밀번호 저장에 최적화**: SHA256보다 보안성 높음
4. **JWT Payload는 암호화되지 않음**: 민감한 정보 저장 금지
5. **토큰은 안전하게 저장**: XSS, CSRF 공격 방어 필요

---

## 참고 자료

- [JWT 공식 사이트](https://jwt.io/)
- [RFC 7519 - JSON Web Token](https://tools.ietf.org/html/rfc7519)
- [OWASP Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)
