# 로그인

## 목차
1. [날것의 로그인 시스템 구현하기](#날것의-로그인-시스템-구현하기)

---

## 날것의 로그인 시스템 구현하기

### 1. login 메서드 구현

**파일**: `src/auth/auth.service.ts`

```typescript
async login(rawToken: string) {
  // 1. Basic Token 파싱
  const { email, password } = this.parseBasicToken(rawToken);

  // 2. 사용자 조회
  const user = await this.userRepository.findOne({ where: { email } });

  if (!user) {
    throw new BadRequestException('User not found');
  }

  // 3. 비밀번호 검증
  const passOk = await bcrypt.compare(password, user.password);

  if (!passOk) {
    throw new BadRequestException('Invalid password');
  }

  // 4. JWT 토큰 발급
  const refreshTokenSecret = this.configService.get<string>(
    'REFRESH_TOKEN_SECRET',
  )!;
  const accessTokenSecret = this.configService.get<string>(
    'ACCESS_TOKEN_SECRET',
  )!;

  return {
    refreshToken: await this.jwtService.signAsync(
      {
        sub: user.id,
        role: user.role,
        type: 'refresh',
      },
      {
        secret: refreshTokenSecret,
        expiresIn: '24h',
      },
    ),
    accessToken: await this.jwtService.signAsync(
      {
        sub: user.id,
        role: user.role,
        type: 'access',
      },
      {
        secret: accessTokenSecret,
        expiresIn: 300,
      },
    ),
  };
}
```

**설명**:

#### 1단계: Basic Token 파싱

```typescript
const { email, password } = this.parseBasicToken(rawToken);
```

- `parseBasicToken()` 메서드로 Basic Token에서 이메일과 비밀번호 추출
- 회원가입과 동일한 방식

#### 2단계: 사용자 조회

```typescript
const user = await this.userRepository.findOne({ where: { email } });

if (!user) {
  throw new BadRequestException('User not found');
}
```

- 데이터베이스에서 이메일로 사용자 조회
- 사용자가 없으면 `BadRequestException` 발생

#### 3단계: 비밀번호 검증

```typescript
const passOk = await bcrypt.compare(password, user.password);

if (!passOk) {
  throw new BadRequestException('Invalid password');
}
```

- `bcrypt.compare()`: 입력된 비밀번호와 저장된 해시값 비교
- 첫 번째 인자: 원본 비밀번호 (평문)
- 두 번째 인자: 해시된 비밀번호 (데이터베이스에 저장된 값)
- 반환값: `true` (일치) 또는 `false` (불일치)
- 비밀번호가 일치하지 않으면 `BadRequestException` 발생

**bcrypt.compare() 동작 원리**:
- 입력된 비밀번호를 해싱하지 않고, 저장된 해시값에서 Salt를 추출
- Salt와 입력 비밀번호를 결합하여 해싱
- 두 해시값을 비교하여 일치 여부 확인

#### 4단계: JWT 토큰 발급

```typescript
const refreshTokenSecret = this.configService.get<string>('REFRESH_TOKEN_SECRET')!;
const accessTokenSecret = this.configService.get<string>('ACCESS_TOKEN_SECRET')!;

return {
  refreshToken: await this.jwtService.signAsync(
    {
      sub: user.id,
      role: user.role,
      type: 'refresh',
    },
    {
      secret: refreshTokenSecret,
      expiresIn: '24h',
    },
  ),
  accessToken: await this.jwtService.signAsync(
    {
      sub: user.id,
      role: user.role,
      type: 'access',
    },
    {
      secret: accessTokenSecret,
      expiresIn: 300,
    },
  ),
};
```

**설명**:

1. **Secret 키 가져오기**:
   - `REFRESH_TOKEN_SECRET`: Refresh Token 서명용 Secret 키
   - `ACCESS_TOKEN_SECRET`: Access Token 서명용 Secret 키
   - 환경 변수에서 가져옴

2. **Refresh Token 발급**:
   - Payload:
     - `sub`: 사용자 ID (subject)
     - `role`: 사용자 역할
     - `type`: 토큰 타입 (`'refresh'`)
   - 만료 시간: `24h` (24시간)
   - Secret: `REFRESH_TOKEN_SECRET`

3. **Access Token 발급**:
   - Payload:
     - `sub`: 사용자 ID (subject)
     - `role`: 사용자 역할
     - `type`: 토큰 타입 (`'access'`)
   - 만료 시간: `300` (300초 = 5분)
   - Secret: `ACCESS_TOKEN_SECRET`

4. **토큰 반환**:
   - 두 토큰을 객체로 반환
   - 클라이언트는 두 토큰을 안전하게 저장

### 2. AuthController에 login 엔드포인트 추가

**파일**: `src/auth/auth.controller.ts`

```typescript
import { Controller, Headers, Post } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  registerUser(@Headers('authorization') token: string) {
    return this.authService.register(token);
  }

  @Post('login')
  loginUser(@Headers('authorization') token: string) {
    return this.authService.login(token);
  }
}
```

**설명**:
- `@Post('login')`: `POST /auth/login` 엔드포인트
- `@Headers('authorization')`: HTTP 헤더에서 `authorization` 값 추출
- `token`: `"Basic dXNlcm5hbWU6cGFzc3dvcmQ="` 형식의 문자열

### 3. JwtModule 설정

**파일**: `src/auth/auth.module.ts`

```typescript
import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    JwtModule.register({}),
  ],
  controllers: [AuthController],
  providers: [AuthService],
})
export class AuthModule {}
```

**설명**:
- `JwtModule.register({})`: JWT 모듈 등록
- `JwtService`를 `AuthService`에서 주입받아 사용 가능
- Secret 키는 `jwtService.signAsync()` 호출 시 직접 전달

---

## 로그인 흐름

### 1. 클라이언트 요청

```http
POST /auth/login
Authorization: Basic ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ=
```

**설명**:
- `Authorization` 헤더에 `Basic` 스키마와 Base64 인코딩된 토큰 전송
- Base64 인코딩 전: `email@example.com:password`
- Base64 인코딩 후: `ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ=`

### 2. 서버 처리 과정

```
1. AuthController.loginUser()
   ↓
2. AuthService.login()
   ↓
3. parseBasicToken() - Base64 디코딩
   ↓
4. userRepository.findOne() - 사용자 조회
   ↓
5. bcrypt.compare() - 비밀번호 검증
   ↓
6. jwtService.signAsync() - Access Token 발급
   ↓
7. jwtService.signAsync() - Refresh Token 발급
   ↓
8. 토큰 반환
```

### 3. 응답

```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsInJvbGUiOjIsInR5cGUiOiJhY2Nlc3MiLCJpYXQiOjE3MDQ4NzIwMDAsImV4cCI6MTcwNDg3MjMwMH0...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsInJvbGUiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzA0ODcyMDAwLCJleHAiOjE3MDQ5NTg0MDB9..."
}
```

**설명**:
- `accessToken`: 5분 후 만료
- `refreshToken`: 24시간 후 만료
- 클라이언트는 두 토큰을 안전하게 저장해야 함

---

## bcrypt.compare() 상세 설명

### bcrypt.compare()란?

`bcrypt.compare()`는 입력된 평문 비밀번호와 저장된 해시값을 비교하는 메서드입니다.

### 사용법

```typescript
const passOk = await bcrypt.compare(plainPassword, hashedPassword);
```

**매개변수**:
- `plainPassword`: 사용자가 입력한 원본 비밀번호 (평문)
- `hashedPassword`: 데이터베이스에 저장된 해시된 비밀번호

**반환값**:
- `true`: 비밀번호 일치
- `false`: 비밀번호 불일치

### 동작 원리

1. **Salt 추출**: 저장된 해시값에서 Salt를 추출합니다.
2. **해싱**: 입력된 비밀번호와 Salt를 결합하여 해싱합니다.
3. **비교**: 새로 생성한 해시값과 저장된 해시값을 비교합니다.

**중요**: 원본 비밀번호를 해싱하지 않고 비교합니다. Bcrypt는 해시값에 Salt가 포함되어 있어서 비교가 가능합니다.

### 예시

```typescript
// 회원가입 시
const password = "mypassword123";
const hash = await bcrypt.hash(password, 10);
// hash = "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy"

// 로그인 시
const inputPassword = "mypassword123";
const isValid = await bcrypt.compare(inputPassword, hash);
// isValid = true

const wrongPassword = "wrongpassword";
const isInvalid = await bcrypt.compare(wrongPassword, hash);
// isInvalid = false
```

---

## JWT 토큰 발급 상세 설명

### JwtService.signAsync()

NestJS의 `JwtService`를 사용하여 JWT 토큰을 생성합니다.

### 사용법

```typescript
const token = await this.jwtService.signAsync(
  payload,
  options,
);
```

**매개변수**:

1. **payload (페이로드)**:
   ```typescript
   {
     sub: user.id,        // 사용자 ID (subject)
     role: user.role,     // 사용자 역할
     type: 'access',      // 토큰 타입
   }
   ```

2. **options (옵션)**:
   ```typescript
   {
     secret: accessTokenSecret,  // 서명용 Secret 키
     expiresIn: 300,              // 만료 시간 (초 단위)
   }
   ```

### Access Token vs Refresh Token

| 구분 | Access Token | Refresh Token |
|------|-------------|---------------|
| **용도** | 프라이빗 리소스 접근 | Access Token 재발급 |
| **만료 시간** | 짧음 (5분) | 김 (24시간) |
| **Secret 키** | `ACCESS_TOKEN_SECRET` | `REFRESH_TOKEN_SECRET` |
| **Payload type** | `'access'` | `'refresh'` |
| **사용 빈도** | 매 요청마다 사용 | Access Token 만료 시만 사용 |

### 토큰 Payload 구조

#### Access Token Payload

```json
{
  "sub": 1,
  "role": 2,
  "type": "access",
  "iat": 1704872000,
  "exp": 1704872300
}
```

**설명**:
- `sub`: 사용자 ID
- `role`: 사용자 역할 (0: admin, 1: paidUser, 2: user)
- `type`: 토큰 타입 (`'access'`)
- `iat`: 토큰 발급 시간 (issued at)
- `exp`: 토큰 만료 시간 (expiration)

#### Refresh Token Payload

```json
{
  "sub": 1,
  "role": 2,
  "type": "refresh",
  "iat": 1704872000,
  "exp": 1704958400
}
```

**설명**:
- `sub`: 사용자 ID
- `role`: 사용자 역할
- `type`: 토큰 타입 (`'refresh'`)
- `iat`: 토큰 발급 시간
- `exp`: 토큰 만료 시간 (24시간 후)

---

## 로그인 프로세스 전체 흐름

### 1. 클라이언트 → 서버 (로그인 요청)

```http
POST /auth/login
Authorization: Basic ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ=
```

### 2. 서버 처리

1. **Basic Token 파싱**: Base64 디코딩하여 이메일과 비밀번호 추출
2. **사용자 조회**: 데이터베이스에서 이메일로 사용자 검색
3. **비밀번호 검증**: `bcrypt.compare()`로 비밀번호 일치 여부 확인
4. **JWT 토큰 발급**: Access Token과 Refresh Token 생성

### 3. 서버 → 클라이언트 (토큰 반환)

```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### 4. 클라이언트 토큰 저장

- **Access Token**: 메모리 또는 세션 스토리지에 저장 (XSS 방어)
- **Refresh Token**: HttpOnly Cookie에 저장 권장 (XSS 방어)

### 5. 이후 요청 (Access Token 사용)

```http
GET /api/movies
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 에러 처리

### 1. 사용자 없음

```typescript
if (!user) {
  throw new BadRequestException('User not found');
}
```

**응답**:
```json
{
  "statusCode": 400,
  "message": "User not found",
  "error": "Bad Request"
}
```

### 2. 비밀번호 불일치

```typescript
if (!passOk) {
  throw new BadRequestException('Invalid password');
}
```

**응답**:
```json
{
  "statusCode": 400,
  "message": "Invalid password",
  "error": "Bad Request"
}
```

### 3. 잘못된 토큰 형식

```typescript
if (basicSplit.length !== 2) {
  throw new BadRequestException('Invalid token');
}
```

**응답**:
```json
{
  "statusCode": 400,
  "message": "Invalid token",
  "error": "Bad Request"
}
```

---

## 보안 고려사항

### 1. 비밀번호 검증

- **bcrypt.compare() 사용**: 해시값과 평문 비밀번호를 안전하게 비교
- **에러 메시지**: "User not found"와 "Invalid password"를 구분하지 않음 (보안상 동일한 메시지 권장)

### 2. 토큰 보안

- **Secret 키 분리**: Access Token과 Refresh Token에 다른 Secret 키 사용
- **만료 시간**: Access Token은 짧게, Refresh Token은 길게 설정
- **HTTPS 필수**: 토큰 전송 시 반드시 HTTPS 사용

### 3. 토큰 저장

- **Access Token**: 메모리 또는 세션 스토리지 (XSS 방어)
- **Refresh Token**: HttpOnly Cookie (XSS 방어)

### 4. 에러 메시지

**보안 모범 사례**:
```typescript
// ❌ 나쁜 예: 구체적인 에러 메시지
if (!user) {
  throw new BadRequestException('User not found');
}
if (!passOk) {
  throw new BadRequestException('Invalid password');
}

// ✅ 좋은 예: 일반적인 에러 메시지
if (!user || !passOk) {
  throw new BadRequestException('Invalid credentials');
}
```

**설명**:
- 구체적인 에러 메시지는 공격자에게 정보를 제공할 수 있음
- "Invalid credentials" 같은 일반적인 메시지 사용 권장

---

## 프로젝트 파일 구조

```
src/
├── auth/
│   ├── auth.service.ts              # login() 메서드
│   ├── auth.controller.ts           # login 엔드포인트
│   └── auth.module.ts               # JwtModule 등록
├── user/
│   └── entities/
│       └── user.entity.ts           # User 엔티티
└── app.module.ts                     # 환경 변수 설정
```

---

## 핵심 개념 정리

### 1. 로그인 프로세스

1. Basic Token 파싱
2. 사용자 조회
3. 비밀번호 검증 (bcrypt.compare)
4. JWT 토큰 발급 (Access Token, Refresh Token)

### 2. bcrypt.compare()

- 입력 비밀번호와 해시값을 비교
- Salt를 자동으로 추출하여 비교
- 비동기 함수이므로 `await` 사용

### 3. JWT 토큰 발급

- `JwtService.signAsync()` 사용
- Payload에 사용자 정보 포함
- Secret 키와 만료 시간 설정

### 4. Access Token vs Refresh Token

- **Access Token**: 짧은 수명, 프라이빗 리소스 접근
- **Refresh Token**: 긴 수명, Access Token 재발급

---

## 참고사항

1. **비밀번호 검증**: `bcrypt.compare()`는 해시값과 평문을 비교합니다.
2. **토큰 Secret**: Access Token과 Refresh Token은 다른 Secret 키를 사용해야 합니다.
3. **만료 시간**: Access Token은 짧게(5분), Refresh Token은 길게(24시간) 설정합니다.
4. **에러 메시지**: 보안을 위해 구체적인 에러 메시지보다 일반적인 메시지를 사용하는 것이 좋습니다.
5. **HTTPS 필수**: Basic Token과 JWT 토큰 전송 시 반드시 HTTPS를 사용해야 합니다.
