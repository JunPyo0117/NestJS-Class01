# Part 18. Interceptor

## 목차
1. [Interceptor 이론](#1-interceptor-이론)
2. [Response Time Interceptor 구현하기](#2-response-time-interceptor-구현하기)
3. [Cache Interceptor 구현하기](#3-cache-interceptor-구현하기)
4. [Transaction Interceptor 구현하기](#4-transaction-interceptor-구현하기)

---

## 1. Interceptor 이론

### 1.1 Interceptor란?

**Interceptor(인터셉터)**는 요청과 응답을 가로채서 변환하거나 추가 처리를 수행할 수 있는 컴포넌트입니다. NestJS의 요청 처리 파이프라인에서 **Guard 이후, Pipe 이전**에 실행됩니다.

#### Interceptor의 특징

1. **요청/응답 변환**: 요청 데이터를 변환하거나 응답 데이터를 가공
2. **로깅**: 요청/응답 로깅 및 성능 측정
3. **캐싱**: 응답 캐싱으로 성능 향상
4. **에러 처리**: 에러 발생 시 추가 처리
5. **트랜잭션 관리**: 데이터베이스 트랜잭션 자동 관리

### 1.2 Interceptor의 실행 순서

Interceptor는 NestJS의 요청 처리 파이프라인에서 **Guard 이후, Pipe 이전**에 실행됩니다.

```
요청 → Middleware → Guard → Interceptor → Pipe → Controller → Service → Repository
                                                      ↑
응답 ← Middleware ← Guard ← Interceptor ← Pipe ← Controller ← Service ← Repository
```

#### 실행 흐름

1. **요청 처리**: Interceptor가 요청을 가로채서 전처리
2. **핸들러 실행**: Controller의 핸들러 실행
3. **응답 처리**: Interceptor가 응답을 가로채서 후처리

### 1.3 NestInterceptor 인터페이스

Interceptor는 `NestInterceptor` 인터페이스를 구현해야 합니다.

```typescript
export interface NestInterceptor<T = any, R = any> {
  intercept(
    context: ExecutionContext,
    next: CallHandler<T>
  ): Observable<R> | Promise<Observable<R>>;
}
```

- `intercept` 메서드를 구현해야 함
- `ExecutionContext`: 현재 실행 컨텍스트
- `CallHandler`: 다음 핸들러를 호출하는 핸들러
- `Observable`: RxJS Observable 반환

### 1.4 RxJS와 Interceptor

NestJS의 Interceptor는 RxJS의 Observable을 기반으로 동작합니다.

#### 주요 RxJS 연산자

- **`tap`**: 사이드 이펙트 수행 (로깅, 측정 등)
- **`map`**: 데이터 변환
- **`catchError`**: 에러 처리
- **`finalize`**: 완료 시 실행 (정리 작업)

---

## 2. Response Time Interceptor 구현하기

### 2.1 Response Time Interceptor 생성

요청 처리 시간을 측정하는 Interceptor를 생성합니다.

```typescript:src/common/interceptor/response-time.imterceptor.ts
import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable, tap } from 'rxjs';

export class ResponseTimeInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const reqTime = Date.now();

    return next.handle().pipe(
      tap(() => {
        const respTime = Date.now();
        const diff = respTime - reqTime;

        console.log(`${req.method} ${req.path} ${diff}ms`);
      }),
    );
  }
}
```

#### 구현 설명

1. **요청 시간 기록**: `Date.now()`로 요청 시작 시간 기록
2. **핸들러 실행**: `next.handle()`로 다음 핸들러 실행
3. **응답 시간 측정**: `tap` 연산자로 응답 완료 시 시간 측정
4. **로깅**: 요청 메서드, 경로, 처리 시간을 콘솔에 출력

### 2.2 전역 Interceptor 등록

`app.module.ts`에서 전역 Interceptor로 등록합니다.

```typescript:src/app.module.ts
import { APP_INTERCEPTOR } from '@nestjs/core';
import { ResponseTimeInterceptor } from './common/interceptor/response-time.imterceptor';

@Module({
  // ... imports
  providers: [
    // ... other providers
    {
      provide: APP_INTERCEPTOR,
      useClass: ResponseTimeInterceptor,
    },
  ],
})
export class AppModule implements NestModule {
  // ...
}
```

#### APP_INTERCEPTOR 사용

- `APP_INTERCEPTOR` 토큰을 사용하여 전역 Interceptor 등록
- 모든 라우트에 자동으로 적용됨
- 개별 컨트롤러나 메서드에서 `@UseInterceptors()`로 제외 가능

### 2.3 사용 예시

모든 요청에 대해 응답 시간이 자동으로 측정되고 로그에 출력됩니다.

```
GET /movie 45ms
POST /movie 123ms
GET /movie?page=1&take=10 67ms
```

---

## 3. Cache Interceptor 구현하기

### 3.1 Cache Interceptor 생성

응답을 캐싱하여 동일한 요청에 대해 빠르게 응답하는 Interceptor를 생성합니다.

```typescript:src/common/interceptor/cache.interceptor.ts
import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable, of, tap } from 'rxjs';

export class CacheInterceptor implements NestInterceptor {
  private cache = new Map<string, any>();

  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<any> | Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest();

    // GET /movie
    const key = `${request.method}-${request.path}`;

    if (this.cache.has(key)) {
      return of(this.cache.get(key));
    }

    return next.handle().pipe(tap((response) => this.cache.set(key, response)));
  }
}
```

#### 구현 설명

1. **캐시 저장소**: `Map`을 사용하여 메모리 캐시 구현
2. **캐시 키 생성**: `메서드-경로` 형식으로 키 생성
3. **캐시 확인**: 캐시에 데이터가 있으면 즉시 반환 (`of()` 사용)
4. **캐시 저장**: 응답을 받으면 캐시에 저장

#### RxJS `of()` 연산자

- `of(value)`: 값을 Observable로 변환
- 캐시된 값을 Observable로 반환하여 핸들러를 실행하지 않음

### 3.2 Controller에서 사용

특정 엔드포인트에만 캐시를 적용합니다.

```typescript:src/movie/movie.controller.ts
import { CacheInterceptor } from 'src/common/interceptor/cache.interceptor';

@Controller('movie')
export class MovieController {
  @Get()
  @UseInterceptors(CacheInterceptor)
  getMovies(@Query() dto: GetMoviesDto) {
    return this.movieService.findAll(dto);
  }
}
```

#### 사용 시나리오

- **첫 요청**: 캐시 없음 → 핸들러 실행 → 응답 캐싱
- **두 번째 요청**: 캐시 있음 → 캐시된 응답 즉시 반환

### 3.3 주의사항

1. **메모리 사용**: 메모리 기반 캐시는 서버 재시작 시 초기화됨
2. **캐시 무효화**: 데이터 변경 시 캐시를 수동으로 무효화해야 함
3. **캐시 키**: 쿼리 파라미터를 고려하지 않아 동일 경로의 다른 요청도 같은 캐시 사용

---

## 4. Transaction Interceptor 구현하기

### 4.1 트랜잭션 관리의 문제점

기존에는 각 Service 메서드에서 트랜잭션을 직접 관리했습니다:

```typescript
// 기존 방식 (Service 내부)
async create(CreateMovieDto: CreateMovieDto) {
  const qr = this.dataSource.createQueryRunner();
  await qr.connect();
  await qr.startTransaction();

  try {
    // 비즈니스 로직
    await qr.commitTransaction();
    return result;
  } catch (e) {
    await qr.rollbackTransaction();
    throw e;
  } finally {
    await qr.release();
  }
}
```

#### 문제점

1. **코드 중복**: 모든 트랜잭션이 필요한 메서드에 동일한 코드 반복
2. **관심사 분리**: 비즈니스 로직과 트랜잭션 관리가 섞여 있음
3. **유지보수 어려움**: 트랜잭션 로직 변경 시 여러 곳 수정 필요

### 4.2 Transaction Interceptor 생성

트랜잭션 관리를 Interceptor로 분리합니다.

```typescript:src/common/interceptor/transaction.interceptor.ts
import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable, catchError, tap } from 'rxjs';
import { DataSource } from 'typeorm';

@Injectable()
export class TransactionInterceptor implements NestInterceptor {
  constructor(private readonly dataSource: DataSource) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const req = context.switchToHttp().getRequest();
    const qr = this.dataSource.createQueryRunner();

    await qr.connect();
    await qr.startTransaction();

    req.queryRunner = qr;

    return next.handle().pipe(
      catchError(async (e) => {
        await qr.rollbackTransaction();
        await qr.release();
        throw e;
      }),
      tap(async () => {
        await qr.commitTransaction();
        await qr.release();
      }),
    );
  }
}
```

#### 구현 설명

1. **QueryRunner 생성**: `DataSource`에서 QueryRunner 생성
2. **트랜잭션 시작**: `connect()` 및 `startTransaction()` 호출
3. **Request에 저장**: `req.queryRunner`에 QueryRunner 저장하여 Service에서 사용
4. **에러 처리**: `catchError`로 에러 발생 시 롤백 및 릴리즈
5. **성공 처리**: `tap`으로 성공 시 커밋 및 릴리즈

### 4.3 Service 메서드 수정

Service 메서드는 QueryRunner를 파라미터로 받아 사용합니다.

```typescript:src/movie/movie.service.ts
async create(CreateMovieDto: CreateMovieDto, qr: QueryRunner) {
  // 트랜잭션 관리 코드 제거
  // const qr = this.dataSource.createQueryRunner();
  // await qr.connect();
  // await qr.startTransaction();

  // try {
  const director = await qr.manager.findOne(Director, {
    where: { id: CreateMovieDto.directorId },
  });

  if (!director) {
    throw new NotFoundException(
      `Director with ID ${CreateMovieDto.directorId} not found`,
    );
  }

  const genres = await qr.manager.find(Genre, {
    where: { id: In(CreateMovieDto.genreIds) },
  });

  if (genres.length !== CreateMovieDto.genreIds.length) {
    throw new NotFoundException(
      `존재하지 않는 장르가 있습니다. 존재하는 장르: ${genres.map((genre) => genre.id).join(', ')}`,
    );
  }

  const movieDetail = await qr.manager
    .createQueryBuilder()
    .insert()
    .into(MovieDetail)
    .values({
      detail: CreateMovieDto.detail,
    })
    .execute();

  const movieDetailId = movieDetail.identifiers[0].id;

  const movie = await qr.manager
    .createQueryBuilder()
    .insert()
    .into(Movie)
    .values({
      title: CreateMovieDto.title,
      detail: {
        id: movieDetailId,
      },
      director: director,
    })
    .execute();

  const movieId = movie.identifiers[0].id;

  await qr.manager
    .createQueryBuilder()
    .relation(Movie, 'genres')
    .of(movieId)
    .add(genres.map((genre) => genre.id));

  // 트랜잭션 관리 코드 제거
  // await qr.commitTransaction();
  // } catch (e) {
  //   await qr.rollbackTransaction();
  //   throw e;
  // } finally {
  //   await qr.release();
  // }

  return qr.manager.findOne(Movie, {
    where: { id: movieId },
    relations: ['detail', 'director', 'genres'],
  });
}
```

#### 변경 사항

- **트랜잭션 관리 코드 제거**: QueryRunner 생성, 트랜잭션 시작/커밋/롤백 코드 제거
- **QueryRunner 파라미터 추가**: Interceptor에서 생성한 QueryRunner를 받아서 사용
- **비즈니스 로직에 집중**: 트랜잭션 관리 없이 순수 비즈니스 로직만 구현

### 4.4 Controller에서 사용

트랜잭션이 필요한 엔드포인트에 Interceptor를 적용합니다.

```typescript:src/movie/movie.controller.ts
import { TransactionInterceptor } from 'src/common/interceptor/transaction.interceptor';

@Controller('movie')
export class MovieController {
  @Post()
  @RBAC(Role.admin)
  @UseInterceptors(TransactionInterceptor)
  createMovie(@Body() body: CreateMovieDto, @Request() req) {
    return this.movieService.create(body, req.queryRunner);
  }
}
```

#### 동작 흐름

1. **Interceptor 실행**: `TransactionInterceptor`가 먼저 실행
2. **QueryRunner 생성**: Interceptor에서 QueryRunner 생성 및 트랜잭션 시작
3. **Request에 저장**: `req.queryRunner`에 QueryRunner 저장
4. **Controller 실행**: Controller에서 `req.queryRunner`를 Service에 전달
5. **Service 실행**: Service에서 QueryRunner를 사용하여 비즈니스 로직 수행
6. **트랜잭션 처리**:
   - 성공 시: `tap`에서 커밋 및 릴리즈
   - 실패 시: `catchError`에서 롤백 및 릴리즈

### 4.5 Interceptor의 장점

#### 관심사 분리

- **Interceptor**: 트랜잭션 관리 (인프라 관심사)
- **Service**: 비즈니스 로직 (도메인 관심사)

#### 코드 재사용

- 여러 엔드포인트에서 동일한 Interceptor 사용 가능
- 트랜잭션 로직 변경 시 한 곳만 수정

#### 유지보수성 향상

- 비즈니스 로직과 트랜잭션 관리가 분리되어 코드 가독성 향상
- 테스트 시 트랜잭션 관리 로직을 모킹하기 쉬움

### 4.6 주의사항

#### RxJS async 함수 제약

`tap`과 `catchError`에서 `async` 함수를 사용하면 타입 오류가 발생할 수 있습니다:

```typescript
// ❌ 타입 오류 발생
tap(async () => {
  await qr.commitTransaction();
})

// ✅ 해결 방법 (현재 코드는 타입 오류가 있지만 동작은 함)
// 실제 프로덕션에서는 finalize를 사용하거나 다른 방법 고려 필요
```

#### 트랜잭션 범위

- Interceptor는 요청 단위로 트랜잭션을 관리
- 여러 Service 메서드를 호출해도 하나의 트랜잭션으로 처리

---

## 정리

### Interceptor의 핵심 개념

1. **요청/응답 가로채기**: 요청과 응답을 중간에서 처리
2. **RxJS 기반**: Observable을 사용하여 비동기 처리
3. **관심사 분리**: 공통 로직을 Interceptor로 분리

### 구현 요약

1. **ResponseTimeInterceptor**: 요청 처리 시간 측정 및 로깅
2. **CacheInterceptor**: 응답 캐싱으로 성능 향상
3. **TransactionInterceptor**: 트랜잭션 자동 관리

### Interceptor vs 다른 컴포넌트

| 구분 | Middleware | Guard | Interceptor | Pipe |
|------|-----------|-------|-------------|------|
| **실행 순서** | 가장 먼저 | Middleware 이후 | Guard 이후 | Interceptor 이후 |
| **주요 역할** | 요청 전처리 | 인가 확인 | 요청/응답 변환 | 데이터 변환/검증 |
| **RxJS 사용** | ❌ | ❌ | ✅ | ❌ |

### 트랜잭션 관리 개선

**기존 방식:**
- Service 메서드마다 트랜잭션 관리 코드 반복
- 비즈니스 로직과 트랜잭션 관리가 섞여 있음

**Interceptor 방식:**
- 트랜잭션 관리를 Interceptor로 분리
- Service는 비즈니스 로직에만 집중
- 코드 재사용성 및 유지보수성 향상

Interceptor는 공통 로직을 중앙에서 관리하여 코드 중복을 줄이고 유지보수성을 향상시키는 강력한 도구입니다.
