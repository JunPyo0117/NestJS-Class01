# Many-to-One Relationship 정리

## 📋 프로젝트 개요

이 챕터에서는 **Many-to-One Relationship**을 학습하고, `Movie`와 `Director` Entity 간의 관계를 구현하여 CRUD 작업을 수행했습니다. 또한 **Unique**와 **Nullable** 제약 조건을 적용했습니다.

## 🎯 핵심 개념

### 1. Many-to-One Relationship이란?

**Many-to-One** 관계는 여러 Entity가 하나의 다른 Entity를 참조하는 관계입니다.

#### 개념

- **Many**: 여러 개의 Entity
- **One**: 하나의 Entity
- **관계**: 여러 Entity가 하나의 Entity를 공유

#### 예시

- **Movies** → **Director**: 여러 영화가 하나의 감독을 가짐
- **Orders** → **Customer**: 여러 주문이 하나의 고객을 가짐
- **Comments** → **Post**: 여러 댓글이 하나의 게시글을 가짐

#### 관계 방향

- **Many-to-One**: 여러 Entity에서 하나의 Entity로 참조
- **One-to-Many**: 하나의 Entity에서 여러 Entity로 참조
- **양방향**: 양쪽에서 서로 참조 가능

---

### 2. Unique Constraint (유니크 제약)

**Unique** 제약은 컬럼의 값이 중복되지 않도록 보장합니다.

#### 특징

- ✅ 중복 값 방지
- ✅ NULL 값은 여러 개 허용 (NULL은 서로 다름)
- ✅ 인덱스 자동 생성 (조회 성능 향상)

---

### 3. Nullable Constraint (널 허용 제약)

**Nullable** 제약은 컬럼이 NULL 값을 허용하는지 결정합니다.

#### 옵션

- `nullable: true`: NULL 허용 (기본값)
- `nullable: false`: NULL 불허용 (필수 필드)

---

## 📝 현재 프로젝트 구조

### 1. Movie Entity (Many-to-One 관계)

**파일 위치:** `src/movie/entity/movie.entity.ts`

```typescript
import { Director } from './../../director/entity/director.entity';
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  OneToOne,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { BaseTable } from '../../common/entity/base-table.entity';
import { MovieDetail } from './movie-detail.entity';

@Entity()
export class Movie extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    unique: true,  // 유니크 제약
  })
  title: string;

  @Column()
  genre: string;

  @OneToOne(() => MovieDetail, (movieDetail) => movieDetail.id, {
    cascade: true,
    nullable: false,  // NULL 불허용
  })
  @JoinColumn()
  detail: MovieDetail;

  @ManyToOne(() => Director, (director) => director.id, {
    cascade: true,
    nullable: false,  // NULL 불허용
  })
  director: Director;
}
```

**주요 특징:**
- `@ManyToOne()`: Many-to-One 관계 정의
- `title`에 `unique: true`: 제목 중복 방지
- `nullable: false`: Director 필수 (NULL 불허용)
- `cascade: true`: 자동 저장/업데이트

---

### 2. Director Entity (One-to-Many 관계)

**파일 위치:** `src/director/entity/director.entity.ts`

```typescript
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { BaseTable } from '../../common/entity/base-table.entity';
import { Movie } from 'src/movie/entity/movie.entity';

@Entity()
export class Director extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  dob: Date;

  @Column()
  nationality: string;

  @OneToMany(() => Movie, (movie) => movie.director)
  movies: Movie[];
}
```

**주요 특징:**
- `@OneToMany()`: One-to-Many 관계 정의 (역방향)
- `movies: Movie[]`: 여러 영화를 가질 수 있음
- 외래 키는 `Movie` 테이블에 생성됨

---

### 3. 생성되는 테이블 구조

```sql
-- director 테이블
CREATE TABLE director (
  id SERIAL PRIMARY KEY,
  name VARCHAR NOT NULL,
  dob DATE NOT NULL,
  nationality VARCHAR NOT NULL,
  "createdAt" TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMP NOT NULL,
  version INTEGER NOT NULL
);

-- movie 테이블
CREATE TABLE movie (
  id SERIAL PRIMARY KEY,
  title VARCHAR NOT NULL UNIQUE,  -- 유니크 제약
  genre VARCHAR NOT NULL,
  "detailId" INTEGER UNIQUE NOT NULL,  -- NULL 불허용
  "directorId" INTEGER NOT NULL,  -- NULL 불허용, 외래 키
  "createdAt" TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMP NOT NULL,
  version INTEGER NOT NULL,
  FOREIGN KEY ("detailId") REFERENCES movie_detail(id),
  FOREIGN KEY ("directorId") REFERENCES director(id)
);
```

**특징:**
- `movie` 테이블에 `directorId` 외래 키 생성
- `title`에 UNIQUE 제약
- `directorId`에 NOT NULL 제약

---

## 🔍 Many-to-One vs One-to-Many

### 관계 설정

#### Many-to-One (Movie → Director)

```typescript
// Movie Entity
@ManyToOne(() => Director, (director) => director.id, {
  cascade: true,
  nullable: false,
})
director: Director;
```

**특징:**
- 외래 키가 `Movie` 테이블에 생성됨
- 여러 Movie가 하나의 Director를 참조
- `@JoinColumn()` 불필요 (자동 생성)

---

#### One-to-Many (Director → Movies)

```typescript
// Director Entity
@OneToMany(() => Movie, (movie) => movie.director)
movies: Movie[];
```

**특징:**
- 외래 키는 `Movie` 테이블에 있음
- 하나의 Director가 여러 Movie를 가짐
- 배열 타입으로 정의

---

## 🔄 CRUD 작업

### 1. Create (생성)

#### Movie 생성 (Director 관계 포함)

**파일 위치:** `src/movie/movie.service.ts`

```typescript
async create(CreateMovieDto: CreateMovieDto) {
  const director = await this.directorRepository.findOne({
    where: { id: CreateMovieDto.directorId },
  });

  if (!director) {
    throw new NotFoundException(
      `Director with ID ${CreateMovieDto.directorId} not found`,
    );
  }

  const movie = await this.movieRepository.save({
    title: CreateMovieDto.title,
    genre: CreateMovieDto.genre,
    detail: {
      detail: CreateMovieDto.detail,
    },
    director: director,
  });

  return movie;
}
```

**특징:**
- Director를 먼저 조회하여 존재 여부 확인
- Movie 저장 시 Director 객체 전달
- `cascade: true`가 있어도 Director는 별도 조회 필요

**요청 예시:**
```json
POST /movie
{
  "title": "인터스텔라",
  "genre": "sci-fi",
  "detail": "우주를 배경으로 한 SF 영화",
  "directorId": 1
}
```

---

#### Director 생성

**파일 위치:** `src/director/director.service.ts`

```typescript
create(createDirectorDto: CreateDirectorDto) {
  return this.directorRepository.save(createDirectorDto);
}
```

**요청 예시:**
```json
POST /director
{
  "name": "크리스토퍼 놀란",
  "dob": "1970-07-30",
  "nationality": "영국"
}
```

---

### 2. Read (조회)

#### Movie 조회 (Director 관계 포함)

```typescript
async findAll(title?: string) {
  if (!title) {
    return [
      await this.movieRepository.find({ relations: ['director'] }),
      await this.movieRepository.count(),
    ];
  }

  if (title) {
    return await this.movieRepository.findAndCount({
      where: { title: Like(`%${title}%`) },
      relations: ['director'],
    });
  }
}

async findOne(id: number) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director'],
  });

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  return movie;
}
```

**특징:**
- `relations: ['director']`: Director 관계도 함께 로드
- 여러 관계: `relations: ['detail', 'director']`
- JOIN 쿼리로 한 번에 조회

**응답 예시:**
```json
{
  "id": 1,
  "title": "인터스텔라",
  "genre": "sci-fi",
  "director": {
    "id": 1,
    "name": "크리스토퍼 놀란",
    "dob": "1970-07-30",
    "nationality": "영국"
  },
  "detail": {
    "id": 1,
    "detail": "우주를 배경으로 한 SF 영화"
  }
}
```

---

#### Director 조회 (Movies 관계 포함)

```typescript
// Director 조회 시 Movies도 함께 로드
const director = await this.directorRepository.findOne({
  where: { id },
  relations: ['movies'],
});
```

**응답 예시:**
```json
{
  "id": 1,
  "name": "크리스토퍼 놀란",
  "dob": "1970-07-30",
  "nationality": "영국",
  "movies": [
    {
      "id": 1,
      "title": "인터스텔라",
      "genre": "sci-fi"
    },
    {
      "id": 2,
      "title": "다크나이트",
      "genre": "action"
    }
  ]
}
```

---

### 3. Update (수정)

#### Movie 수정 (Director 관계 변경)

```typescript
async update(id: number, UpdateMovieDto: UpdateMovieDto) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail'],
  });

  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }

  const { detail, directorId, ...movieRest } = UpdateMovieDto;

  let newDirector;

  if (directorId) {
    const director = await this.directorRepository.findOne({
      where: { id: directorId },
    });

    if (!director) {
      throw new NotFoundException(`Director with ID ${directorId} not found`);
    }

    newDirector = director;
  }

  const movieUpdateFields = {
    ...movieRest,
    ...(newDirector && { director: newDirector }),
  };

  await this.movieRepository.update({ id }, movieUpdateFields);

  if (detail) {
    await this.movieDetailRepository.update(
      { id: movie.detail.id },
      { detail },
    );
  }

  const newMovie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail', 'director'],
  });

  return newMovie;
}
```

**특징:**
- `directorId`가 제공되면 Director 조회 후 업데이트
- 조건부로 `director` 필드 추가
- 업데이트 후 관계 포함하여 다시 조회

**요청 예시:**
```json
PATCH /movie/1
{
  "title": "인터스텔라 (수정)",
  "directorId": 2
}
```

---

### 4. Delete (삭제)

#### Movie 삭제

```typescript
async remove(id: number) {
  const movie = await this.movieRepository.findOne({
    where: { id },
    relations: ['detail'],
  });
  if (!movie) {
    throw new NotFoundException(`Movie with ID ${id} not found`);
  }
  await this.movieRepository.delete(id);
  await this.movieDetailRepository.delete({ id: movie.detail.id });

  return id;
}
```

**특징:**
- Movie 삭제 시 MovieDetail도 함께 삭제
- Director는 삭제되지 않음 (다른 Movie가 참조할 수 있음)

---

## 🔒 Unique & Nullable Constraint

### 1. Unique Constraint

#### @Column() 옵션으로 설정

```typescript
@Column({
  unique: true,
})
title: string;
```

**특징:**
- 컬럼 값이 중복되지 않도록 보장
- 데이터베이스 레벨에서 UNIQUE 제약 생성
- 인덱스 자동 생성 (조회 성능 향상)

**에러 예시:**
```json
// 첫 번째 영화 생성
POST /movie
{
  "title": "인터스텔라",
  "genre": "sci-fi",
  "detail": "...",
  "directorId": 1
}
// ✅ 성공

// 같은 제목으로 다시 생성
POST /movie
{
  "title": "인터스텔라",  // 중복!
  "genre": "action",
  "detail": "...",
  "directorId": 1
}
// ❌ 에러: duplicate key value violates unique constraint
```

---

### 2. Nullable Constraint

#### nullable 옵션

```typescript
@Column({
  nullable: true,   // NULL 허용 (기본값)
})
description?: string;

@Column({
  nullable: false,  // NULL 불허용
})
title: string;
```

#### Relationship에서 nullable

```typescript
@ManyToOne(() => Director, {
  nullable: false,  // Director 필수
})
director: Director;

@OneToOne(() => MovieDetail, {
  nullable: true,   // MovieDetail 선택적
})
detail?: MovieDetail;
```

**특징:**
- `nullable: false`: 필수 필드 (NOT NULL 제약)
- `nullable: true`: 선택적 필드 (NULL 허용)
- Relationship에서도 적용 가능

---

## 📚 Director 엔드포인트

### DirectorController

**파일 위치:** `src/director/director.controller.ts`

```typescript
@Controller('director')
export class DirectorController {
  constructor(private readonly directorService: DirectorService) {}

  @Get()
  findAll() {
    return this.directorService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.directorService.findOne(+id);
  }

  @Post()
  create(@Body() createDirectorDto: CreateDirectorDto) {
    return this.directorService.create(createDirectorDto);
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateDirectorDto: UpdateDirectorDto,
  ) {
    return this.directorService.update(+id, updateDirectorDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.directorService.remove(+id);
  }
}
```

**엔드포인트:**
- `GET /director`: 전체 감독 목록
- `GET /director/:id`: 특정 감독 조회
- `POST /director`: 새 감독 생성
- `PATCH /director/:id`: 감독 정보 수정
- `DELETE /director/:id`: 감독 삭제

---

### DirectorService

**파일 위치:** `src/director/director.service.ts`

```typescript
@Injectable()
export class DirectorService {
  constructor(
    @InjectRepository(Director)
    private readonly directorRepository: Repository<Director>,
  ) {}

  create(createDirectorDto: CreateDirectorDto) {
    return this.directorRepository.save(createDirectorDto);
  }

  findAll() {
    return this.directorRepository.find();
  }

  findOne(id: number) {
    return this.directorRepository.findOne({ where: { id } });
  }

  async update(id: number, updateDirectorDto: UpdateDirectorDto) {
    const director = await this.directorRepository.findOne({
      where: { id },
    });

    if (!director) {
      throw new NotFoundException(`Director with ID ${id} not found`);
    }

    await this.directorRepository.update({ id }, { ...updateDirectorDto });

    const newDirector = await this.directorRepository.findOne({
      where: { id },
    });

    return newDirector;
  }

  async remove(id: number) {
    const director = await this.directorRepository.findOne({
      where: { id },
    });

    if (!director) {
      throw new NotFoundException(`Director with ID ${id} not found`);
    }

    await this.directorRepository.delete(id);

    return id;
  }
}
```

---

### DirectorModule

**파일 위치:** `src/director/director.module.ts`

```typescript
@Module({
  imports: [TypeOrmModule.forFeature([Director])],
  controllers: [DirectorController],
  providers: [DirectorService],
})
export class DirectorModule {}
```

---

## 🔄 Before & After 비교

### Before (관계 없음)

```typescript
@Entity()
export class Movie {
  @Column()
  directorName: string;  // 감독 이름을 직접 저장
}
```

**문제점:**
- ❌ 감독 정보 중복 저장
- ❌ 감독 정보 변경 시 모든 영화 수정 필요
- ❌ 데이터 일관성 문제

---

### After (Many-to-One 관계)

```typescript
@Entity()
export class Movie {
  @ManyToOne(() => Director)
  director: Director;  // Director Entity 참조
}
```

**장점:**
- ✅ 감독 정보 중복 제거
- ✅ 감독 정보 변경 시 자동 반영
- ✅ 데이터 일관성 유지
- ✅ 관계를 통한 효율적인 조회

---

## 🎓 학습한 내용 요약

### 강의 내용 체크리스트

1. ✅ **Many to One Relationship 생성하기**
   - `@ManyToOne()` 데코레이터 사용
   - `@OneToMany()` 데코레이터 사용
   - 양방향 관계 설정

2. ✅ **Director 엔드포인트 완성하기**
   - Director CRUD API 구현
   - DirectorModule 생성
   - DirectorService와 DirectorController 구현

3. ✅ **Movie-Director Create Update 관계 작업 해보기**
   - Movie 생성 시 Director 관계 설정
   - Movie 수정 시 Director 관계 변경
   - Director 존재 여부 검증

4. ✅ **Movie-Director Read 관계 작업 해보기**
   - `relations: ['director']`로 관계 로드
   - JOIN 쿼리로 한 번에 조회
   - 양방향 관계 조회

5. ✅ **Unique & Nullable Constraint 작업 해보기**
   - `unique: true`로 중복 방지
   - `nullable: false`로 필수 필드 설정
   - Relationship에서 nullable 옵션 사용

---

## 🔑 핵심 정리

### Many-to-One vs One-to-Many

| 구분 | Many-to-One | One-to-Many |
|------|-------------|-------------|
| **데코레이터** | `@ManyToOne()` | `@OneToMany()` |
| **외래 키 위치** | Many 쪽 (Movie) | Many 쪽 (Movie) |
| **타입** | 단일 객체 | 배열 |
| **예시** | `director: Director` | `movies: Movie[]` |

### Constraint 옵션

| 옵션 | 용도 | 예시 |
|------|------|------|
| `unique: true` | 중복 방지 | `@Column({ unique: true })` |
| `nullable: false` | 필수 필드 | `@Column({ nullable: false })` |
| `nullable: true` | 선택적 필드 | `@Column({ nullable: true })` |

### 현재 프로젝트 구조

**Movie Entity:**
```typescript
@Column({ unique: true })
title: string;

@ManyToOne(() => Director, {
  cascade: true,
  nullable: false,
})
director: Director;
```

**Director Entity:**
```typescript
@OneToMany(() => Movie, (movie) => movie.director)
movies: Movie[];
```

---

## 🚀 다음 단계

현재 구조의 장점:
- ✅ Many-to-One 관계 구현 완료
- ✅ Unique 제약으로 데이터 무결성 보장
- ✅ Nullable 제약으로 필수 필드 명시
- ✅ Director CRUD API 완성

향후 개선 가능한 부분:
- Many-to-Many 관계 구현 (Movies ↔ Genres)
- 관계 삭제 시 `onDelete` 옵션 활용
- Eager Loading vs Lazy Loading 최적화
- 복합 Unique 제약 (여러 컬럼 조합)

---

## 📌 참고사항

### 프로젝트에서 사용 중인 기능

**Movie Entity:**
```typescript
@Column({ unique: true })
title: string;

@ManyToOne(() => Director, {
  cascade: true,
  nullable: false,
})
director: Director;
```

**MovieService:**
```typescript
// Create
const movie = await this.movieRepository.save({
  director: director,
});

// Read
relations: ['director']

// Update
movieUpdateFields.director = newDirector;
```

### 주의사항

1. **Unique 제약**
   - 중복 값 저장 시 에러 발생
   - NULL 값은 여러 개 허용

2. **Nullable 제약**
   - `nullable: false`인 필드는 반드시 값 필요
   - Relationship에서도 적용 가능

3. **관계 삭제**
   - Movie 삭제 시 Director는 삭제되지 않음
   - Director 삭제 시 참조하는 Movie 처리 필요 (`onDelete` 옵션)
