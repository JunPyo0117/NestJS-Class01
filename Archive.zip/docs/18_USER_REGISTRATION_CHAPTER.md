# 회원가입

## 목차
1. [User Module 작업하기](#user-module-작업하기)
2. [Auth Module 회원가입 작업하기](#auth-module-회원가입-작업하기)

---

## User Module 작업하기

### 1. User Entity 생성

**파일**: `src/user/entities/user.entity.ts`

```typescript
import { Exclude } from 'class-transformer';
import { BaseTable } from 'src/common/entity/base-table.entity';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

enum Role {
  admin,
  paidUser,
  user,
}

@Entity()
export class User extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    unique: true,
  })
  email: string;

  @Column()
  @Exclude({
    toPlainOnly: true, // 플레인 객체로 변환할 때만 제외
  })
  password: string;

  @Column({
    type: 'enum',
    enum: Role,
    default: Role.user,
  })
  role: Role;
}
```

**설명**:

1. **BaseTable 상속**:
   - `createdAt`, `updatedAt`, `version` 컬럼 자동 포함
   - 공통 컬럼을 재사용

2. **email 필드**:
   - `@Column({ unique: true })`: 이메일 중복 방지
   - 데이터베이스 레벨에서 유니크 제약 조건

3. **password 필드**:
   - `@Exclude({ toPlainOnly: true })`: 응답에서 비밀번호 제외
   - `toPlainOnly: true`: 객체를 JSON으로 변환할 때만 제외
   - API 응답에 비밀번호가 포함되지 않도록 보호

4. **role 필드**:
   - `@Column({ type: 'enum', enum: Role })`: Enum 타입 사용
   - `default: Role.user`: 기본값은 일반 사용자
   - 역할: `admin`, `paidUser`, `user`

### 2. UserModule 설정

**파일**: `src/user/user.module.ts`

```typescript
import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User])],
  controllers: [UserController],
  providers: [UserService],
})
export class UserModule {}
```

**설명**:
- `TypeOrmModule.forFeature([User])`: User 엔티티를 UserModule에서 사용할 수 있도록 등록
- UserRepository를 UserService에서 주입받아 사용 가능

### 3. UserService 생성

**파일**: `src/user/user.service.ts`

```typescript
import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  create(createUserDto: CreateUserDto) {
    return this.userRepository.save(createUserDto);
  }

  findAll() {
    return this.userRepository.find();
  }

  async findOne(id: number) {
    const user = await this.userRepository.findOne({ where: { id } });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return user;
  }

  async update(id: number, updateUserDto: UpdateUserDto) {
    const user = await this.userRepository.findOne({ where: { id } });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
    await this.userRepository.update({ id }, updateUserDto);

    return this.userRepository.findOne({ where: { id } });
  }

  async remove(id: number) {
    const user = await this.userRepository.findOne({ where: { id } });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
    await this.userRepository.delete(id);

    return id;
  }
}
```

**설명**:
- 기본 CRUD 작업 구현
- `@Exclude()` 데코레이터로 인해 `findAll()`, `findOne()` 등에서 비밀번호가 자동으로 제외됨

### 4. UserController 생성

**파일**: `src/user/user.controller.ts`

```typescript
import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  ClassSerializerInterceptor,
  UseInterceptors,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Controller('user')
@UseInterceptors(ClassSerializerInterceptor)
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.create(createUserDto);
  }

  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: string) {
    return this.userService.findOne(+id);
  }

  @Patch(':id')
  update(
    @Param('id', ParseIntPipe) id: string,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    return this.userService.update(+id, updateUserDto);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: string) {
    return this.userService.remove(+id);
  }
}
```

**설명**:
- `@UseInterceptors(ClassSerializerInterceptor)`: `@Exclude()` 데코레이터가 작동하도록 설정
- `ClassSerializerInterceptor`가 User 엔티티의 `@Exclude()` 데코레이터를 인식하여 비밀번호를 응답에서 제외

### 5. AppModule에 UserModule 추가

**파일**: `src/app.module.ts`

```typescript
import { UserModule } from './user/user.module';
import { User } from './user/entities/user.entity';

@Module({
  imports: [
    // ...
    TypeOrmModule.forRootAsync({
      // ...
      entities: [Movie, MovieDetail, Director, Genre, User],
      // ...
    }),
    // ...
    UserModule,
  ],
})
export class AppModule {}
```

**설명**:
- `entities` 배열에 `User` 추가: TypeORM이 User 엔티티를 인식하도록 설정
- `UserModule` import: User 관련 기능을 앱에서 사용할 수 있도록 설정

---

## Auth Module 회원가입 작업하기

### 1. AuthModule 생성

**파일**: `src/auth/auth.module.ts`

```typescript
import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    JwtModule.register({}),
  ],
  controllers: [AuthController],
  providers: [AuthService],
})
export class AuthModule {}
```

**설명**:
- `TypeOrmModule.forFeature([User])`: User 엔티티를 AuthModule에서 사용
- `JwtModule.register({})`: JWT 모듈 등록 (로그인 시 사용)

### 2. 환경 변수 설정

**파일**: `src/app.module.ts`

```typescript
ConfigModule.forRoot({
  isGlobal: true,
  validationSchema: Joi.object({
    // ... 기존 설정
    HASH_ROUNDS: Joi.number().required(),
    ACCESS_TOKEN_SECRET: Joi.string().required(),
    REFRESH_TOKEN_SECRET: Joi.string().required(),
  }),
})
```

**설명**:
- `HASH_ROUNDS`: Bcrypt 해싱 라운드 수
- `ACCESS_TOKEN_SECRET`: Access Token 서명용 Secret 키
- `REFRESH_TOKEN_SECRET`: Refresh Token 서명용 Secret 키

### 3. parseBasicToken 메서드 구현

**파일**: `src/auth/auth.service.ts`

```typescript
parseBasicToken(rawToken: string) {
  // 1. 토큰을 ' ' 기준으로 나누기
  const basicSplit = rawToken.split(' ');

  if (basicSplit.length !== 2) {
    throw new BadRequestException('Invalid token');
  }

  const [, token] = basicSplit;

  // 2. 추출한 토큰을 base64 디코딩해서 이메일과 비밀번호로 나눈다
  const decoded = Buffer.from(token, 'base64').toString('utf-8');

  // 3. 이메일과 비밀번호로 나눈다 email:password 형식으로 되어있음
  const tokenSplit = decoded.split(':');

  if (tokenSplit.length !== 2) {
    throw new BadRequestException('Invalid token');
  }

  const [email, password] = tokenSplit;

  return { email, password };
}
```

**설명**:

1. **토큰 분리**:
   - `rawToken`: `"Basic dXNlcm5hbWU6cGFzc3dvcmQ="` 형식
   - `split(' ')`: 공백으로 분리하여 `["Basic", "dXNlcm5hbWU6cGFzc3dvcmQ="]` 생성
   - 두 번째 요소만 추출

2. **Base64 디코딩**:
   - `Buffer.from(token, 'base64')`: Base64 문자열을 Buffer로 변환
   - `.toString('utf-8')`: UTF-8 문자열로 변환
   - 결과: `"email:password"`

3. **이메일과 비밀번호 분리**:
   - `split(':')`: 콜론으로 분리
   - `["email", "password"]` 반환

**예시**:
```typescript
// 입력
rawToken = "Basic ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ="

// 1단계: 분리
basicSplit = ["Basic", "ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ="]
token = "ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ="

// 2단계: Base64 디코딩
decoded = "email@example.com:password"

// 3단계: 분리
tokenSplit = ["email@example.com", "password"]
return { email: "email@example.com", password: "password" }
```

### 4. register 메서드 구현

**파일**: `src/auth/auth.service.ts`

```typescript
async register(rawToken: string) {
  // 1. Basic Token 파싱
  const { email, password } = this.parseBasicToken(rawToken);

  // 2. 이메일 중복 확인
  const user = await this.userRepository.findOne({ where: { email } });

  if (user) {
    throw new BadRequestException('User already exists');
  }

  // 3. 비밀번호 해싱
  const hash = await bcrypt.hash(
    password,
    this.configService.get<number>('HASH_ROUNDS')!,
  );

  // 4. 사용자 저장
  await this.userRepository.save({ email, password: hash });

  // 5. 저장된 사용자 반환 (비밀번호는 @Exclude()로 자동 제외)
  return this.userRepository.findOne({ where: { email } });
}
```

**설명**:

1. **Basic Token 파싱**:
   - `parseBasicToken()`으로 이메일과 비밀번호 추출

2. **이메일 중복 확인**:
   - 데이터베이스에서 동일한 이메일이 있는지 확인
   - 이미 존재하면 `BadRequestException` 발생

3. **비밀번호 해싱**:
   - `bcrypt.hash()`: Bcrypt 알고리즘으로 비밀번호 해싱
   - `HASH_ROUNDS`: 해싱 라운드 수 (보통 10~12)
   - 원본 비밀번호는 저장하지 않고 해시값만 저장

4. **사용자 저장**:
   - 해시된 비밀번호와 함께 사용자 정보 저장
   - `role`은 기본값(`Role.user`)으로 자동 설정

5. **사용자 반환**:
   - 저장된 사용자 정보 반환
   - `@Exclude()` 데코레이터로 인해 비밀번호는 응답에 포함되지 않음

### 5. AuthController에 register 엔드포인트 추가

**파일**: `src/auth/auth.controller.ts`

```typescript
import { Controller, Headers, Post } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  // authorization: Basic <token>
  registerUser(@Headers('authorization') token: string) {
    return this.authService.register(token);
  }
}
```

**설명**:
- `@Headers('authorization')`: HTTP 헤더에서 `authorization` 값 추출
- `@Post('register')`: `POST /auth/register` 엔드포인트
- `token`: `"Basic dXNlcm5hbWU6cGFzc3dvcmQ="` 형식의 문자열

### 6. AppModule에 AuthModule 추가

**파일**: `src/app.module.ts`

```typescript
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    // ...
    AuthModule,
    UserModule,
  ],
})
export class AppModule {}
```

---

## 회원가입 흐름

### 1. 클라이언트 요청

```http
POST /auth/register
Authorization: Basic ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ=
```

**설명**:
- `Authorization` 헤더에 `Basic` 스키마와 Base64 인코딩된 토큰 전송
- Base64 인코딩 전: `email@example.com:password`
- Base64 인코딩 후: `ZW1haWxAZXhhbXBsZS5jb206cGFzc3dvcmQ=`

### 2. 서버 처리 과정

```
1. AuthController.registerUser()
   ↓
2. AuthService.register()
   ↓
3. parseBasicToken() - Base64 디코딩
   ↓
4. 이메일 중복 확인
   ↓
5. bcrypt.hash() - 비밀번호 해싱
   ↓
6. userRepository.save() - 사용자 저장
   ↓
7. 사용자 정보 반환 (비밀번호 제외)
```

### 3. 응답

```json
{
  "id": 1,
  "email": "email@example.com",
  "role": "user",
  "createdAt": "2026-01-12T14:00:00.000Z",
  "updatedAt": "2026-01-12T14:00:00.000Z",
  "version": 1
}
```

**설명**:
- `password` 필드는 `@Exclude()` 데코레이터로 인해 응답에 포함되지 않음

---

## 보안 고려사항

### 1. Base64는 암호화가 아님

**주의사항**:
- Base64는 단순 인코딩이므로 누구나 디코딩 가능
- **HTTPS 필수**: 전송 중 데이터를 암호화해야 함
- Basic Token은 초기 인증에만 사용하고, 이후에는 Access Token 사용

### 2. 비밀번호 해싱

**Bcrypt 사용**:
- 원본 비밀번호는 절대 저장하지 않음
- 해시값만 저장하여 보안 강화
- `HASH_ROUNDS`로 해싱 강도 조절 (보통 10~12)

### 3. 비밀번호 응답 제외

**@Exclude() 데코레이터**:
- API 응답에 비밀번호가 포함되지 않도록 보호
- `toPlainOnly: true`: 객체를 JSON으로 변환할 때만 제외

### 4. 이메일 중복 방지

**데이터베이스 제약 조건**:
- `@Column({ unique: true })`: 데이터베이스 레벨에서 중복 방지
- 애플리케이션 레벨에서도 중복 확인

---

## 프로젝트 파일 구조

```
src/
├── user/
│   ├── entities/
│   │   └── user.entity.ts          # User 엔티티 (@Exclude() 사용)
│   ├── dto/
│   │   ├── create-user.dto.ts
│   │   └── update-user.dto.ts
│   ├── user.service.ts             # User CRUD
│   ├── user.controller.ts           # User API
│   └── user.module.ts               # UserModule
├── auth/
│   ├── auth.service.ts              # parseBasicToken, register
│   ├── auth.controller.ts           # register 엔드포인트
│   └── auth.module.ts               # AuthModule
└── app.module.ts                     # UserModule, AuthModule 등록
```

---

## 핵심 개념 정리

### 1. User Entity

- **BaseTable 상속**: 공통 컬럼 재사용
- **@Exclude()**: 비밀번호 응답 제외
- **unique: true**: 이메일 중복 방지
- **Enum Role**: 사용자 역할 관리

### 2. Basic Token 파싱

- **형식**: `"Basic <base64-encoded-token>"`
- **디코딩**: Base64 → `"email:password"`
- **분리**: 콜론(`:`)으로 이메일과 비밀번호 분리

### 3. 회원가입 프로세스

1. Basic Token 파싱
2. 이메일 중복 확인
3. 비밀번호 해싱 (Bcrypt)
4. 사용자 저장
5. 사용자 정보 반환 (비밀번호 제외)

### 4. 보안

- **HTTPS 필수**: Base64는 암호화가 아니므로 전송 중 암호화 필요
- **비밀번호 해싱**: Bcrypt로 해시값만 저장
- **응답 제외**: `@Exclude()`로 비밀번호 응답 제외

---

## 참고사항

1. **Base64 보안**: Base64는 암호화가 아니므로 HTTPS를 반드시 사용해야 합니다.
2. **비밀번호 해싱**: Bcrypt는 느리지만 보안성이 높아 비밀번호 저장에 적합합니다.
3. **@Exclude()**: `ClassSerializerInterceptor`와 함께 사용해야 작동합니다.
4. **이메일 중복**: 데이터베이스 제약 조건과 애플리케이션 레벨 검증 모두 필요합니다.
5. **환경 변수**: `HASH_ROUNDS`, `ACCESS_TOKEN_SECRET`, `REFRESH_TOKEN_SECRET`을 `.env` 파일에 설정해야 합니다.
