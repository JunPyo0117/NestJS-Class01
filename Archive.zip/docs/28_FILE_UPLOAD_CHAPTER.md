# Part 20. File Upload

## 목차
1. [파일 업로드 이론](#1-파일-업로드-이론)
2. [전통적 파일 업로드 방식 실습](#2-전통적-파일-업로드-방식-실습)
   - [간단 단일 파일 업로드](#21-간단-단일-파일-업로드)
   - [간단 복수 파일 업로드](#22-간단-복수-파일-업로드)
   - [FileFieldsInterceptor 사용해보기](#23-filefieldsinterceptor-사용해보기)
   - [MulterOptions 알아보기](#24-multeroptions-알아보기)
   - [업로드된 파일 정보 변경하기](#25-업로드된-파일-정보-변경하기)
   - [엔티티에 파일 정보 반영하기](#26-엔티티에-파일-정보-반영하기)
   - [스태틱파일 서빙하기](#27-스태틱파일-서빙하기)
3. [파일 선업로드 방식](#3-파일-선업로드-방식)
   - [CommonModule로 파일 업로드 로직 이동하기](#31-commonmodule로-파일-업로드-로직-이동하기)
   - [Movie 엔드포인트 완성하기](#32-movie-엔드포인트-완성하기) *(추가 예정)*

---

## 1. 파일 업로드 이론

### 1.1 파일 업로드란?

**파일 업로드(File Upload)**는 클라이언트에서 서버로 파일을 전송하는 기능입니다. NestJS는 `multer`를 기반으로 파일 업로드를 지원합니다.

#### 파일 업로드의 필요성

1. **미디어 저장**: 이미지, 동영상, 문서 등 다양한 파일 저장
2. **사용자 콘텐츠**: 사용자가 생성한 콘텐츠 업로드
3. **데이터 백업**: 중요한 데이터의 백업 및 복원

### 1.2 파일 업로드 방식

#### 1. 전통적 파일 업로드 방식

- **방식**: 요청과 함께 파일을 업로드
- **예시**: 영화 생성 시 영화 파일도 함께 업로드
- **장점**: 한 번의 요청으로 모든 데이터 처리
- **단점**: 파일 크기가 크면 요청 시간이 길어짐

```
POST /movie
Content-Type: multipart/form-data

title=영화제목&movie=파일&poster=파일
```

#### 2. 파일 선업로드 방식

- **방식**: 파일을 먼저 업로드하고, 이후에 파일 정보를 사용
- **예시**: 파일을 먼저 업로드 → 파일명 받기 → 영화 생성 시 파일명 사용
- **장점**: 파일 업로드와 데이터 처리를 분리하여 유연성 향상
- **단점**: 두 번의 요청 필요

```
1. POST /common/video → { filename: "uuid_timestamp.mp4" }
2. POST /movie { title: "영화제목", movieFileName: "uuid_timestamp.mp4" }
```

### 1.3 Multer

**Multer**는 Node.js의 파일 업로드 미들웨어입니다. NestJS는 `@nestjs/platform-express`를 통해 Multer를 통합합니다.

#### Multer의 주요 기능

1. **파일 저장**: 메모리 또는 디스크에 파일 저장
2. **파일 검증**: 파일 크기, 타입 등 검증
3. **파일명 변경**: 고유한 파일명 생성

---

## 2. 전통적 파일 업로드 방식 실습

### 2.1 간단 단일 파일 업로드

#### MulterModule 등록

먼저 `MovieModule`에 `MulterModule`을 등록합니다.

```typescript:src/movie/movie.module.ts
import { MulterModule } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { join } from 'path';

@Module({
  imports: [
    // ... other imports
    MulterModule.register({
      storage: diskStorage({
        destination: join(process.cwd(), 'public', 'movie'),
      }),
    }),
  ],
  // ...
})
export class MovieModule {}
```

#### FileInterceptor 사용

단일 파일 업로드를 위해 `FileInterceptor`를 사용합니다.

```typescript:src/movie/movie.controller.ts
import { FileInterceptor } from '@nestjs/platform-express';
import { UploadedFile } from '@nestjs/common';

@Post()
@UseInterceptors(FileInterceptor('movie'))
createMovie(
  @Body() body: CreateMovieDto,
  @UploadedFile() movie: Express.Multer.File,
) {
  console.log(movie);
  return this.movieService.create(body);
}
```

#### 파일 정보

`Express.Multer.File` 객체에는 다음 정보가 포함됩니다:

```typescript
{
  fieldname: 'movie',        // 필드명
  originalname: 'video.mp4', // 원본 파일명
  encoding: '7bit',          // 인코딩
  mimetype: 'video/mp4',     // MIME 타입
  size: 1024000,             // 파일 크기 (바이트)
  destination: './public/movie', // 저장 경로
  filename: 'generated.mp4', // 생성된 파일명
  path: './public/movie/generated.mp4', // 전체 경로
  buffer: Buffer,            // 파일 버퍼 (메모리 저장 시)
}
```

### 2.2 간단 복수 파일 업로드

#### FilesInterceptor 사용

여러 파일을 업로드하려면 `FilesInterceptor`를 사용합니다.

```typescript:src/movie/movie.controller.ts
import { FilesInterceptor } from '@nestjs/platform-express';
import { UploadedFiles } from '@nestjs/common';

@Post()
@UseInterceptors(FilesInterceptor('movies', 10)) // 최대 10개
createMovie(
  @Body() body: CreateMovieDto,
  @UploadedFiles() movies: Express.Multer.File[],
) {
  console.log(movies); // 배열
  return this.movieService.create(body);
}
```

#### FilesInterceptor 파라미터

- 첫 번째: 필드명
- 두 번째: 최대 파일 개수 (선택적)

### 2.3 FileFieldsInterceptor 사용해보기

여러 필드에 각각 다른 파일을 업로드하려면 `FileFieldsInterceptor`를 사용합니다.

```typescript:src/movie/movie.controller.ts
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { UploadedFiles } from '@nestjs/common';

@Post()
@UseInterceptors(
  FileFieldsInterceptor([
    { name: 'movie', maxCount: 1 },
    { name: 'poster', maxCount: 1 },
  ]),
)
createMovie(
  @Body() body: CreateMovieDto,
  @UploadedFiles()
  files: {
    movie?: Express.Multer.File[];
    poster?: Express.Multer.File[];
  },
) {
  const movieFile = files.movie?.[0];
  const posterFile = files.poster?.[0];
  return this.movieService.create(body, movieFile, posterFile);
}
```

#### FileFieldsInterceptor 반환 타입

- `@UploadedFiles()` 데코레이터 사용
- 반환 타입: `{ [fieldname: string]: Express.Multer.File[] }`
- 각 필드는 배열이지만 `maxCount: 1`이면 첫 번째 요소만 사용

### 2.4 MulterOptions 알아보기

`MulterOptions`를 사용하여 파일 업로드 옵션을 설정할 수 있습니다.

```typescript:src/movie/movie.controller.ts
@UseInterceptors(
  FileInterceptor('movie', {
    limits: {
      fileSize: 1024 * 1024 * 10, // 10MB
    },
    fileFilter: (req, file, callback) => {
      if (file.mimetype !== 'video/mp4') {
        return callback(
          new BadGatewayException('MP4 파일만 업로드 가능합니다.'),
          false,
        );
      }
      return callback(null, true);
    },
  }),
)
```

#### 주요 옵션

- **limits**: 파일 크기 제한
  - `fileSize`: 최대 파일 크기 (바이트)
- **fileFilter**: 파일 필터링 함수
  - `callback(error, acceptFile)`: `error`가 있으면 거부, `acceptFile`이 `true`면 허용
- **storage**: 파일 저장 방식
  - `diskStorage`: 디스크에 저장
  - `memoryStorage`: 메모리에 저장

### 2.5 업로드된 파일 정보 변경하기

파일 업로드 후 파일 정보를 변경하는 방법은 두 가지가 있습니다:

#### 방법 1: MulterModule에서 파일명 변경

`MulterModule.register()`에서 `filename` 옵션을 사용하여 파일명을 변경할 수 있습니다.

```typescript:src/movie/movie.module.ts
import { v4 } from 'uuid';

MulterModule.register({
  storage: diskStorage({
    destination: join(process.cwd(), 'public', 'movie'),
    filename: (req, file, callback) => {
      const split = file.originalname.split('.');
      let extension = 'mp4';

      if (split.length > 1) {
        extension = split[split.length - 1];
      }

      callback(null, `${v4()}_${Date.now()}.${extension}`);
    },
  }),
})
```

#### 파일명 생성 로직

1. 원본 파일명에서 확장자 추출
2. UUID와 타임스탬프를 조합하여 고유한 파일명 생성
3. 확장자 유지

**예시:**
- 원본: `my-video.mp4`
- 생성: `a1b2c3d4-e5f6-7890-abcd-ef1234567890_1705234567890.mp4`

#### 방법 2: Pipe를 사용한 파일 처리

Pipe를 사용하여 파일 검증 및 파일명 변경을 처리할 수 있습니다.

```typescript:src/movie/pipe/movie-file.pipe.ts
import { BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { v4 } from 'uuid';
import { rename } from 'fs/promises';
import { join } from 'path';

@Injectable()
export class MovieFilePipe implements PipeTransform<
  Express.Multer.File,
  Promise<Express.Multer.File>
> {
  constructor(
    private readonly options: {
      maxSize: number;
      minetype: string;
    },
  ) {}

  async transform(value: Express.Multer.File): Promise<Express.Multer.File> {
    if (!value) {
      throw new BadRequestException('movie file은 필수 입니다.');
    }

    // 파일 크기 검증
    const byteSize = this.options.maxSize * 1000000;
    if (value.size > byteSize) {
      throw new BadRequestException(
        `movie file은 ${this.options.maxSize}MB 이하여야 합니다.`,
      );
    }

    // MIME 타입 검증
    if (value.mimetype !== this.options.minetype) {
      throw new BadRequestException(
        `movie file은 ${this.options.minetype} 형식이어야 합니다.`,
      );
    }

    // 파일명 생성 및 이동
    const split = value.originalname.split('.');
    let extension = 'mp4';
    if (split.length > 1) {
      extension = split[split.length - 1];
    }

    const filename = `${v4()}_${Date.now()}.${extension}`;
    const newPath = join(process.cwd(), 'public', 'movie', filename);

    await rename(value.path, newPath);

    return {
      ...value,
      path: newPath,
      filename,
    };
  }
}
```

#### Pipe 사용 방법

```typescript:src/movie/movie.controller.ts
import { MovieFilePipe } from './pipe/movie-file.pipe';

@Post()
@UseInterceptors(FileInterceptor('movie'))
createMovie(
  @Body() body: CreateMovieDto,
  @UploadedFile(MovieFilePipe, {
    maxSize: 10,
    minetype: 'video/mp4',
  })
  movie: Express.Multer.File,
) {
  return this.movieService.create(body, movie.filename);
}
```

#### Pipe의 장점

1. **검증 로직 분리**: 파일 검증 로직을 Pipe로 분리하여 재사용 가능
2. **파일 이동**: 임시 저장소에서 최종 저장소로 파일 이동 가능
3. **에러 처리**: 검증 실패 시 명확한 에러 메시지 제공
4. **유연성**: 옵션을 통해 다양한 설정 가능

#### MulterModule vs Pipe 비교

| 구분 | MulterModule | Pipe |
|------|-------------|------|
| **파일명 변경** | `filename` 옵션 | `transform` 메서드 |
| **파일 검증** | `fileFilter` 옵션 | `transform` 메서드 |
| **파일 이동** | 불가능 | 가능 (`rename` 사용) |
| **재사용성** | 모듈별 설정 | Pipe로 재사용 가능 |
| **에러 처리** | 제한적 | 자유롭게 처리 가능 |

### 2.6 엔티티에 파일 정보 반영하기

#### Movie Entity에 파일 경로 필드 추가

```typescript:src/movie/entity/movie.entity.ts
@Entity()
export class Movie extends BaseTable {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    unique: true,
  })
  title: string;

  @Column()
  movieFilePath: string;  // 파일 경로 저장

  // ... other fields
}
```

#### Service에서 파일 경로 저장

```typescript:src/movie/movie.service.ts
async create(
  CreateMovieDto: CreateMovieDto,
  movieFileName: string,
  qr: QueryRunner,
) {
  // ... other logic

  const movie = await qr.manager
    .createQueryBuilder()
    .insert()
    .into(Movie)
    .values({
      title: CreateMovieDto.title,
      // ... other fields
      movieFilePath: join(movieFolder, movieFileName),
    })
    .execute();

  // ...
}
```

#### 파일 경로 저장 방식

- **상대 경로**: `movie/uuid_timestamp.mp4`
- **절대 경로**: `/public/movie/uuid_timestamp.mp4`
- **URL 경로**: `/public/movie/uuid_timestamp.mp4` (정적 파일 서빙 시)

### 2.7 스태틱파일 서빙하기

#### ServeStaticModule 등록

업로드된 파일을 HTTP로 제공하려면 `ServeStaticModule`을 사용합니다.

```typescript:src/app.module.ts
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';

@Module({
  imports: [
    // ... other imports
    ServeStaticModule.forRoot({
      rootPath: join(process.cwd(), 'public'),
      serveRoot: '/public',
    }),
  ],
  // ...
})
export class AppModule {}
```

#### 설정 설명

- **rootPath**: 정적 파일이 저장된 디렉토리 경로
- **serveRoot**: URL 경로 접두사

#### 파일 접근

설정 후 다음과 같이 파일에 접근할 수 있습니다:

```
http://localhost:3000/public/movie/uuid_timestamp.mp4
```

#### 파일 경로 저장

엔티티에는 상대 경로를 저장하는 것이 좋습니다:

```typescript
movieFilePath: 'movie/uuid_timestamp.mp4'  // 상대 경로
// 또는
movieFilePath: '/public/movie/uuid_timestamp.mp4'  // URL 경로
```

---

## 3. 파일 선업로드 방식

### 3.1 CommonModule로 파일 업로드 로직 이동하기

#### 문제점: 전통적 방식의 한계

전통적 방식에서는 파일 업로드와 데이터 처리가 하나의 요청에 묶여 있어:
- 파일 크기가 크면 요청 시간이 길어짐
- 파일 업로드 실패 시 전체 요청 실패
- 파일과 데이터를 분리하여 처리하기 어려움

#### 해결책: 파일 선업로드

파일을 먼저 업로드하고, 파일명만 받아서 나중에 사용하는 방식입니다.

#### CommonModule에 MulterModule 등록

```typescript:src/common/common.module.ts
import { MulterModule } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { join } from 'path';
import { v4 } from 'uuid';

@Module({
  imports: [
    MulterModule.register({
      storage: diskStorage({
        destination: join(process.cwd(), 'public', 'temp'),
        filename: (req, file, callback) => {
          const split = file.originalname.split('.');
          let extension = 'mp4';

          if (split.length > 1) {
            extension = split[split.length - 1];
          }

          callback(null, `${v4()}_${Date.now()}.${extension}`);
        },
      }),
    }),
  ],
  controllers: [CommonController],
  providers: [CommonService],
  exports: [CommonService],
})
export class CommonModule {}
```

#### CommonController에 파일 업로드 엔드포인트 생성

```typescript:src/common/common.controller.ts
import {
  BadGatewayException,
  Controller,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';

@Controller('common')
export class CommonController {
  @Post('video')
  @UseInterceptors(
    FileInterceptor('video', {
      limits: {
        fileSize: 1024 * 1024 * 10, // 10MB
      },
      fileFilter: (req, file, callback) => {
        if (file.mimetype !== 'video/mp4') {
          return callback(
            new BadGatewayException('MP4 파일만 업로드 가능합니다.'),
            false,
          );
        }
        return callback(null, true);
      },
    }),
  )
  createVideo(@UploadedFile() movie: Express.Multer.File) {
    return {
      filename: movie.filename,
    };
  }
}
```

#### 동작 방식

1. **파일 업로드**: `POST /common/video`로 파일 업로드
2. **파일명 반환**: 서버에서 고유한 파일명 생성 후 반환
3. **파일명 사용**: 영화 생성 시 파일명만 전달

#### 응답 형식

```json
{
  "filename": "a1b2c3d4-e5f6-7890-abcd-ef1234567890_1705234567890.mp4"
}
```

#### MovieModule에서 MulterModule 제거

파일 업로드 로직이 `CommonModule`로 이동했으므로 `MovieModule`에서는 제거합니다:

```typescript:src/movie/movie.module.ts
@Module({
  imports: [
    // ... other imports
    // MulterModule.register({ ... }), // 제거됨
  ],
  // ...
})
export class MovieModule {}
```

### 3.2 Movie 엔드포인트 완성하기

파일 선업로드 방식을 사용하여 Movie 엔드포인트를 완성합니다. 파일은 이미 `/common/video` 엔드포인트를 통해 업로드되었고, 파일명만 받아서 처리합니다.

#### CreateMovieDto에 파일명 필드 추가

영화 생성 시 파일명을 받기 위해 DTO에 필드를 추가합니다.

```typescript:src/movie/dto/create-movie.dto.ts
export class CreateMovieDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  detail: string;

  @IsNotEmpty()
  @IsNumber()
  directorId: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  @Type(() => Number)
  genreIds: number[];

  @IsString()
  movieFileName: string;  // 파일명 필드 추가
}
```

#### MovieController에서 FileInterceptor 제거

파일은 이미 업로드되었으므로, Controller에서는 파일 인터셉터 없이 DTO만 받습니다.

```typescript:src/movie/movie.controller.ts
@Post()
@RBAC(Role.admin)
@UseInterceptors(TransactionInterceptor)
createMovie(@Body() body: CreateMovieDto, @Request() req) {
  return this.movieService.create(body, req.queryRunner);
}
```

**변경 사항:**
- `FileInterceptor` 제거
- `@UploadedFile()` 데코레이터 제거
- `CreateMovieDto`에서 `movieFileName` 필드로 파일명 받기

#### MovieService에서 파일 이동 처리

업로드된 파일은 `public/temp` 폴더에 임시 저장되어 있습니다. 영화 생성 시 파일을 `public/movie` 폴더로 이동합니다.

```typescript:src/movie/movie.service.ts
import { rename } from 'fs/promises';
import { join } from 'path';

async create(CreateMovieDto: CreateMovieDto, qr: QueryRunner) {
  // ... director, genres 검증 로직 ...

  const movieDetail = await qr.manager
    .createQueryBuilder()
    .insert()
    .into(MovieDetail)
    .values({
      detail: CreateMovieDto.detail,
    })
    .execute();

  const movieDetailId = movieDetail.identifiers[0].id;

  // 파일 이동: temp 폴더 → movie 폴더
  const movieFolder = join('public', 'movie');
  const tempFolder = join('public', 'temp');

  await rename(
    join(process.cwd(), tempFolder, CreateMovieDto.movieFileName),
    join(process.cwd(), movieFolder, CreateMovieDto.movieFileName),
  );

  // 영화 생성 시 파일 경로 저장
  const movie = await qr.manager
    .createQueryBuilder()
    .insert()
    .into(Movie)
    .values({
      title: CreateMovieDto.title,
      detail: {
        id: movieDetailId,
      },
      director,
      movieFilePath: join(movieFolder, CreateMovieDto.movieFileName),
    })
    .execute();

  // ... 나머지 로직 ...
}
```

#### 파일 이동 로직 설명

1. **임시 저장소**: `public/temp` 폴더에 파일이 저장됨
2. **최종 저장소**: `public/movie` 폴더로 파일 이동
3. **파일 경로 저장**: 엔티티에는 상대 경로(`public/movie/filename.mp4`) 저장

**주의사항:**
- `fs/promises`의 `rename` 함수 사용 (Promise 기반)
- 트랜잭션 내에서 파일 이동 수행
- 파일 이동 실패 시 트랜잭션 롤백

#### Movie 엔티티에 URL 변환 추가

응답 시 파일 경로를 URL로 변환하기 위해 `@Transform` 데코레이터를 사용합니다.

```typescript:src/movie/entity/movie.entity.ts
import { Transform } from 'class-transformer';

@Entity()
export class Movie extends BaseTable {
  // ... other fields ...

  @Column()
  @Transform(({ value }) => `http://localhost:3000/${value})`)
  movieFilePath: string;

  // ... other fields ...
}
```

**동작 방식:**
- 데이터베이스에는 상대 경로 저장: `public/movie/uuid_timestamp.mp4`
- 응답 시 자동으로 URL 변환: `http://localhost:3000/public/movie/uuid_timestamp.mp4`

#### 전체 흐름 정리

1. **파일 업로드** (1단계)
   ```
   POST /common/video
   Content-Type: multipart/form-data
   video: [파일]
   
   응답: { "filename": "uuid_timestamp.mp4" }
   ```

2. **영화 생성** (2단계)
   ```
   POST /movie
   {
     "title": "영화 제목",
     "detail": "영화 상세",
     "directorId": 1,
     "genreIds": [1, 2],
     "movieFileName": "uuid_timestamp.mp4"
   }
   ```

3. **내부 처리**
   - `public/temp/uuid_timestamp.mp4` → `public/movie/uuid_timestamp.mp4` 이동
   - 데이터베이스에 파일 경로 저장
   - 응답 시 URL로 변환

#### 장점

1. **요청 분리**: 파일 업로드와 데이터 처리를 분리하여 유연성 향상
2. **에러 처리**: 파일 업로드 실패와 데이터 처리 실패를 분리하여 처리
3. **재사용성**: 파일 업로드 엔드포인트를 여러 곳에서 재사용 가능
4. **트랜잭션 안전성**: 파일 이동도 트랜잭션 내에서 처리하여 일관성 보장

---

## 정리

### 파일 업로드 방식 비교

| 구분 | 전통적 방식 | 선업로드 방식 |
|------|------------|-------------|
| **요청 횟수** | 1번 | 2번 |
| **파일 크기 영향** | 요청 시간 길어짐 | 요청 시간 분리 |
| **에러 처리** | 파일/데이터 모두 실패 | 파일/데이터 분리 처리 |
| **유연성** | 낮음 | 높음 |
| **구현 복잡도** | 간단 | 복잡 |

### Interceptor와 데코레이터 매칭

| Interceptor | 데코레이터 | 반환 타입 |
|------------|-----------|----------|
| `FileInterceptor('field')` | `@UploadedFile()` | `Express.Multer.File` |
| `FilesInterceptor('field', maxCount)` | `@UploadedFiles()` | `Express.Multer.File[]` |
| `FileFieldsInterceptor([...])` | `@UploadedFiles()` | `{ [fieldname: string]: Express.Multer.File[] }` |

### 구현 요약

#### 전통적 방식
1. **MulterModule 등록**: 모듈에 `MulterModule.register()` 추가
2. **FileInterceptor 사용**: Controller에서 `@UseInterceptors(FileInterceptor(...))` 사용
3. **파일 받기**: `@UploadedFile()` 데코레이터로 파일 받기
4. **엔티티에 저장**: 파일 경로를 엔티티 필드에 저장
5. **정적 파일 서빙**: `ServeStaticModule`로 파일 제공

#### 선업로드 방식
1. **CommonModule에 등록**: 파일 업로드 전용 모듈 생성 (`MulterModule`을 `CommonModule`에 등록)
2. **파일 업로드 엔드포인트**: `/common/video` 등으로 파일만 업로드 (임시 저장소 `public/temp`에 저장)
3. **파일명 반환**: 업로드된 파일의 파일명만 반환
4. **DTO에 파일명 필드 추가**: `CreateMovieDto`에 `movieFileName` 필드 추가
5. **Controller에서 FileInterceptor 제거**: 파일은 이미 업로드되었으므로 인터셉터 불필요
6. **Service에서 파일 이동**: `public/temp` → `public/movie` 폴더로 파일 이동
7. **엔티티에 경로 저장**: 상대 경로를 엔티티 필드에 저장
8. **URL 변환**: `@Transform` 데코레이터로 응답 시 URL로 변환

### MulterOptions 주요 설정

```typescript
{
  storage: diskStorage({
    destination: './public/movie',
    filename: (req, file, callback) => {
      // 파일명 생성 로직
    },
  }),
  limits: {
    fileSize: 1024 * 1024 * 10, // 10MB
  },
  fileFilter: (req, file, callback) => {
    // 파일 검증 로직
    callback(null, true); // 허용
    // callback(error, false); // 거부
  },
}
```

### 파일 저장 경로 구조

```
project-root/
  public/
    temp/          # 선업로드 파일 임시 저장
      uuid_timestamp.mp4
    movie/         # 영화 파일 최종 저장
      uuid_timestamp.mp4
```

파일 업로드는 사용자 콘텐츠를 다루는 핵심 기능으로, 프로젝트 요구사항에 맞는 방식을 선택하는 것이 중요합니다.
